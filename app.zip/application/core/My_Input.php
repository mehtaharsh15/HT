<?php defined('BASEPATH') OR exit('No direct script access allowed');
//This class extends the CI_Input class to bypass the XSS Filtering on the specified fields by passing FALSE as the second parameter to the native post() function
class MY_Input extends CI_Input {
    public function __construct() {
        parent::__construct();
    }
    
    public function post($index = null, $xss_clean = TRUE) {
        //echo "ab".$xss_clean."ba<br/>";die;
        return parent::post($index, $xss_clean);
    }
}
?>