<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Customer_model extends CI_Model
{
	/* var $table = 'customer_master';
    var $column_order = array(null, 'customer_firstname','customer_lastname','customer_email','customer_mobile'); //set column field  datatable orderable
    var $column_search = array('customer_firstname','customer_lastname','customer_email','customer_mobile'); //set column field database datatable searchable 
    var $order = array('customer_id' => 'asc'); // default order 
	*/
	
	
	# Constructor
	function Customer_model()
	{
		parent::__construct();

		$this->table		= 'customer_master';
	    $this->column_headers = array(
                                                'First Name'   =>'10%',
                                                'Last Name'    =>'10%',
                                                'Email'        =>'15%',
                                                'Mobile'       =>'10%'
                                              
                                            );
	}

	# it returns total active records count
	function get_customer_count()
	{
			$this->db->where('customer_active', '1');
			return $this->db->count_all_results($this->table);
	}

	# it returns array of active records
	function get_allcustomer()
	{
            $this->db->select('*');
            $this->db->from($this->table);
			$this->db->where('customer_active', '1');
            $query = $this->db->get();
            return $query->result_array();
	  
	}
	
	
	/* function Search_Bycustomer($mobile,$email)
	{
         
		
		    $this->db->select('*');
            $this->db->from($this->table);
			
			$this->db->where('customer_active','1');
			$this->db->where('customer_mobile =', $mobile);
			$this->db->or_where('customer_email =', $email);
			
			$query = $this->db->get(); 
			return $query->result_array();
			 
	} */
	
	

	

        # check for duplicate user name
        function checkExistingemail($email, $customer_id=0)
		{

            if($customer_id > 0)

                $this->db->where(array('customer_email' => $email, 'customer_id !=' => $customer_id));
            else
                $this->db->where(array('customer_email' => $email));
                $row_cnt	= $this->db->count_all_results($this->table);
				//print_r($row_cnt);
            if($row_cnt > 0)
            {
                return TRUE;
            }
            else
            {
                return FALSE;
            }
        }
	/**
	* Insert new customer info
	* @return inserted id (customer id)
	* 
*/
	function Insert($mbl_no, $platform, $device_id, $device_info)
	{
		if(empty($mbl_no)) return FALSE;
		
		//prepare insert data info
		$data = array('customer_firstname'  =>	'',
                      'customer_lastname'	=>	'',
                      'customer_email'   	=>	'',
                      'customer_mobile'  	=>	$mbl_no,
                      //'device_uuid' 		=>	$device_id,
					   'device_uuid' 		=>	'25454',
                      'platform' 	   		=>	$platform,
					  //'device_info' 	   	=>	$device_info,
					   'device_info' 	   	=>	'sdsg',
					  'created_date' 	   	=>	date("Y-m-d H:i:s"),
					  'updated_date' 	   	=>	date("Y-m-d H:i:s"),
					  'customer_active' 	=>	1,
					  'email_verify_flag'	=>	'N'
						);
		
		//insert customer data
		$customer_data	= $this->db->insert($this->table, $data);
		
		//assign inserted id(customer inserted id)
		$PK		= $this->db->insert_id();
		
		//returen customer id
		return $PK;
	}

	# it updates record in table
	function update()
	{
		//$res    = $this->checkExistingmachine($this->input->post('machine_name'), $this->input->post('machine_id'));
		$res2   = $this->checkExistingemail($this->input->post('email'), $this->input->post('customer_id'));
		
		
		if($res2 == FALSE)
		{
			
			$PK	= $this->input->post('customer_id');

			
			$objFuncLib	= new Functions();

			$data = array(
						       'customer_firstname'	=>	$this->input->post('first_name'),
                               'customer_lastname'  =>	$this->input->post('last_name'),
                                 'customer_email' 	=>	$this->input->post('email'),
                               'customer_mobile' 	=>	$this->input->post('mobile'),
                           //  'machine_active' 	=>	$this->input->post('machine_active'),
						);
			
			$customer_updatedata=$this->db->update($this->table, $data, array('customer_id' => $PK));
			
			return $customer_updatedata;
		}
		else
		{
			return FALSE;
		}
	}

	# it returns record of particular id
	function get_customer_edit($customerId)
	{
		$query = $this->db->get_where($this->table, array('customer_id' => $customerId));
		return $query->row_array();
	}

	
	# toggle active status
	function toggle_status($customerId, $astatus)
	{
		if (empty($customerId)) return 0;

		$data = array('customer_active' =>	$astatus,
					);

		$statusupdate	= $this->db->update($this->table, $data, array('customer_id' => $customerId));
		return $statusupdate;
	}
	
	
	
	#datatables at server side
	 private function _get_datatables_query()
    {
         
        $this->db->from($this->table);
 
        $i = 0;
     
        foreach ($this->column_search as $item) // loop column 
        {
            if($_POST['search']['value']) // if datatable send POST for search
            {
                 
                if($i===0) // first loop
                {
                    $this->db->group_start(); // open bracket. query Where with OR clause better with bracket. because maybe can combine with other WHERE with AND.
                    $this->db->like($item, $_POST['search']['value']);
                }
                else
                {
                    $this->db->or_like($item, $_POST['search']['value']);
                }
 
                if(count($this->column_search) - 1 == $i) //last loop
                    $this->db->group_end(); //close bracket
            }
            $i++;
        }
         
        if(isset($_POST['order'])) // here order processing
        {
            $this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        } 
        else if(isset($this->order))
        {
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }
 
    function get_datatables()
    {
        $this->_get_datatables_query();
        if($_POST['length'] != -1)
        $this->db->limit($_POST['length'], $_POST['start']);
        $query = $this->db->get();
        return $query->result();
    }
 
    function count_filtered()
    {
        $this->_get_datatables_query();
        $query = $this->db->get();
        return $query->num_rows();
    }
 
    public function count_all()
    {
        $this->db->from($this->table);
        return $this->db->count_all_results();
    }
 
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	function verify_customer_mobile($mbl_no)
	{
		// check $mbl_no empty or not if empty then return FALSE
		if(empty($mbl_no)) return FALSE;
		
		//get customer info base on mobile number
		$query = $this->db->get_where($this->table, array('customer_mobile' => $mbl_no));
		
		//execute query
		$result = $query->row_array();
		
		if(!empty($result)) {
			return TRUE;
		} else {
			return FALSE;
		}
	}
	/**
	* purpose: check email id change when customer edit profile
	* @param $mbl_no
	* @param $email
	* return true if record found otherwise false
	* 
*/
	function CheckEmailIdexitsBymblno($mbl_no, $email) 
	{
		//check mobile number empty or not
		if(empty($mbl_no)) return FALSE;
		
		$this->db->select('customer_email');
        $this->db->from($this->table);
		$this->db->where('customer_mobile', $mbl_no);
		$this->db->where('customer_email', $email);
		$this->db->where('customer_active', '1');
		$query = $this->db->get();
        $no_record = $query->db->num_rows();
		
		return $no_record;	
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/**
	* purpose: update customer info base on mobile number
	* @param $mbl_no
	* @param $email
	* @param $fname
	* @param $lname
	* return updated record count
	* 
*/
	/*function update_profile($mbl_no, $email, $fname, $lname){
			
		//check mobile number empty or not
		if(empty($mbl_no)) return FALSE;
		
		//prepare data
		$data = array(	'customer_firstname'=>	$fname,	
						'customer_lastname'	=>	$lname,
						'customer_email'	=>	$email,
						'updated_date'		=>	date("Y-m-d H:i:s")
						);
		
		//update customer info base on customer mobile number
		$cust_info = $this->db->update($this->table, $data, array('customer_mobile' => $mbl_no));
		
		//check email id change or not / empty 
		//if emailid change /empty then send email for verify email id 
		//get customer info base on customer mobile no
		$cust_count = $this->CheckEmailIdexitsBymblno($mbl_no, $email);
		
		if($cust_count > 0) {
			return $cust_info;
		} else {
			//send email to customer
			$customer_info = $this->send_email_tocustomer($mbl_no, $email);
			
			//check email send or not
			if($customer_info) {
				return $cust_info;	
			} else{
				return FALSE;
			}
			
		}
	}*/
	/**
	* purpose: get customer name base on mobile id
	* @param $mbl_no
	* @return customer first latter of customer fname and customer lname
*/
	function getcustomer_name($mbl_no)
	{
		// check $mbl_no empty or not if empty then return FALSE
		if(empty($mbl_no)) return FALSE;
		
		//get customer info base on mobile number
		$query = $this->db->get_where($this->table, array('customer_mobile' => $mbl_no));
		
		//execute query
		$result = $query->row_array();
		
		echo '<pre>';
		print_r($result);
		//return $result;
	}
	
	/**
	* purpose: send email to customer for verify email id
	* @param $mbl_no
	* @param $email_id
	* @return true if email send to customer
	*/
	/*function send_email_tocustomer($mbl_no, $email_id)
	{
		$this->load->library('email');
        $this->email->clear();

        $config['mailtype'] = 'html';
        $data['messages_email_template'] =  '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
                                            <html xmlns="http://www.w3.org/1999/xhtml">
                                            <head>
                                            <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
                                            <title>HitechMoney: Verify EmailId</title>
                                            </head>
                                            <body>';
        $data['messages_email_template'] .= "<p>Your profile has been updated. Please verify email id by clicking below link:</p>";
        $data['messages_email_template'] .= "<p><a href=''>Click Here</a></p>";
        $data['messages_email_template'] .= '</body></html>';
        $this->email->initialize($config);
        $this->email->from($this->system->company_email, $this->system->marketing_site_name);
        $this->email->to($email_id);
        $this->email->bcc($this->system->debug_email_address);
        $this->email->subject('HitechMoney: Verify EmailId');
        $this->email->message($data['messages_email_template']);
        $this->email->send();

        return TRUE;	
	}*/
}
?>