<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Customer_model extends CI_Model
{

	# Constructor
	function Customer_model()
	{
		parent::__construct();

		$this->table		= 'customer_master';
	    $this->column_headers = array(
                                                'First Name'   =>'10%',
                                                'Last Name'    =>'10%',
                                                'Email'        =>'10%',
                                                'Mobile'       =>'10%',
                                                'Wallet - Balnce ( Rs. ) '       =>'10%'
                                              
                                            );
											
	   $this->column_search = array('customer_firstname','customer_lastname','customer_email','customer_mobile'); 									
	}
	 
	
	#Serch Customer Data
	#dataTables server side scripting 
	private function _get_Customer_serach()
    {
      $this->db->where('customer_active', '1');
	  $this->db->order_by("customer_firstname", "asc");   
      $this->db->select('*')->from('customer_master c');
		
 
        $i = 0;
        
        foreach ($this->column_search as $item) // loop column 
        {
             $search=$this->input->post('[search][value]');
			//$search= $_POST['search']['value'];
		    if($search) // if datatable send POST for search
            {
                 
                if($i===0) // first loop
                {
                    $this->db->group_start();
                    $this->db->like($item, $search);
                }
                else
                {
                    $this->db->or_like($item, $search);//$_POST['search']['value']
                }
 
                if(count($this->column_search) - 1 == $i) //last loop
                    $this->db->group_end(); //close bracket
            }
            $i++;
        }
    }
 
    # Get all active Customer Data With Wallet balabce Using SubQuery
    function get_allCustomer()
    {
        $checkLength=$this->input->post('length');
        $start=$this->input->post('start');
	    $this->_get_Customer_serach();
        if($checkLength != -1)
			
																				/*select c.*,(select sum(txn_paid)-sum(txn_buy)
																				from cust_transaction
																				where customer_id=c.customer_id ) as balance
																				from customer_master as c*/
		$sub = $this->subquery->start_subquery('select');
		$sub->select('sum(txn_paid)-sum(txn_buy)')->from('cust_transaction')->where('customer_id=c.customer_id');
		$this->subquery->end_subquery('balance');  

        $this->db->limit($checkLength, $start);
	    $query = $this->db->get();
        return $query->result(); 
   
    }
    
   #filter customer data for pagination
   function customer_count_filtered()
    {
        $this->_get_Customer_serach();
        $query = $this->db->get();
        return $query->num_rows();
    }
 
    
	#count all customer
	public function count_all()
    {
       $this->db->where('customer_active', '1');
	   return $this->db->count_all_results($this->table);
    }
	
	 # check for duplicate user name
    function checkExistingemail($email, $customer_id=0)
	{
        if($customer_id > 0)

         $this->db->where(array('customer_email' => $email, 'customer_id !=' => $customer_id));
         else
          $this->db->where(array('customer_email' => $email));
         $row_cnt	= $this->db->count_all_results($this->table);
				//print_r($row_cnt);
         if($row_cnt > 0)
          {
                return TRUE;
          }
          else
          {
                return FALSE;
          }
      }
	
	
	/**
	* Insert new customer info
	* @return inserted id (customer id)
	* 
*/
	function Insert($mbl_no, $platform, $device_id, $device_info)
	{
		if(empty($mbl_no)) return FALSE;
		
		//prepare insert data info
		$data = array('customer_firstname'  =>	'',
                      'customer_lastname'	=>	'',
                      'customer_email'   	=>	'',
                      'customer_mobile'  	=>	$mbl_no,
                      'device_uuid' 		=>	$device_id,
					  //'device_uuid' 		=>	'24454544',
                      'platform' 	   		=>	$platform,
					  'device_info' 	   	=>	$device_info,
					  //'device_info' 	   	=>	'sfsdg',
					  'created_date' 	   	=>	date("Y-m-d H:i:s"),
					  'updated_date' 	   	=>	date("Y-m-d H:i:s"),
					  'customer_active' 	=>	1,
					  'email_verify_flag'	=>	'N'
						);
		
		//insert customer data
		$customer_data	= $this->db->insert($this->table, $data);
		
		//assign inserted id(customer inserted id)
		$PK		= $this->db->insert_id();
		
		//returen customer id
		return $PK;
	}

	# it updates record in table
	function update()
	{
		//$res    = $this->checkExistingmachine($this->input->post('machine_name'), $this->input->post('machine_id'));
		$res2   = $this->checkExistingemail($this->input->post('email'), $this->input->post('customer_id'));
		
		
		if($res2 == FALSE)
		{
			
			$PK	= $this->input->post('customer_id');

			
			$objFuncLib	= new Functions();

			$data = array(
						       'customer_firstname'	=>	$this->input->post('first_name'),
                               'customer_lastname'  =>	$this->input->post('last_name'),
                                 'customer_email' 	=>	$this->input->post('email'),
                               'customer_mobile' 	=>	$this->input->post('mobile'),
                           //  'machine_active' 	=>	$this->input->post('machine_active'),
						);
			
			$customer_updatedata=$this->db->update($this->table, $data, array('customer_id' => $PK));
			
			return $customer_updatedata;
		}
		else
		{
			return FALSE;
		}
	}

	# it returns record of particular id
	function get_customer_edit($customerId)
	{
		$query = $this->db->get_where($this->table, array('customer_id' => $customerId));
		return $query->row_array();
	}

	
	# toggle active status
	function toggle_status($customerId, $astatus)
	{
		if (empty($customerId)) return 0;

		$data = array('customer_active' =>	$astatus,
					);

		$statusupdate	= $this->db->update($this->table, $data, array('customer_id' => $customerId));
		return $statusupdate;
	}
	
	function verify_customer_mobile($mbl_no)
	{
		// check $mbl_no empty or not if empty then return FALSE
		if(empty($mbl_no)) return FALSE;
		
		//get customer info base on mobile number
		$query = $this->db->get_where($this->table, array('customer_mobile' => $mbl_no));
		
		//execute query
		$result = $query->row_array();
		
		if(!empty($result) && is_array($result)) {
			return $result;
		} else {
			return FALSE;
		}
	}
	/**
	* purpose: check email id change when customer edit profile
	* @param $mbl_no
	* @param $email
	* return true if record found otherwise false
	* 
*/
	function CheckEmailIdexitsBymblno($mbl_no, $email) 
	{
		//check mobile number empty or not
		if(empty($mbl_no)) return FALSE;
		
		$this->db->select('customer_email');
        $this->db->from($this->table);
		$this->db->where('customer_mobile', $mbl_no);
		$this->db->where('customer_email', $email);
		$this->db->where('customer_active', '1');
		$query = $this->db->get();
        $no_record = $query->num_rows();
		
		return $no_record;	
	}
	/**
	* purpose: update customer info base on mobile number
	* @param $mbl_no
	* @param $email
	* @param $fname
	* @param $lname
	* return updated record count
	* 
*/
	function update_profile($mbl_no, $email, $fname, $lname){
			
		//check mobile number empty or not
		if(empty($mbl_no)) return FALSE;
		
		//prepare data
		$data = array(	'customer_firstname'=>	$fname,	
						'customer_lastname'	=>	$lname,
						'customer_email'	=>	$email,
						'updated_date'		=>	date("Y-m-d H:i:s")
						);
		
		
		
		//check email id change or not / empty 
		//if emailid change /empty then send email for verify email id 
		//get customer info base on customer mobile no
		$cust_count = $this->CheckEmailIdexitsBymblno($mbl_no, $email);
		//echo $cust_count;
		if($cust_count > 0) {
			//update customer info base on customer mobile number
		$ret = $this->db->update($this->table, $data, array('customer_mobile' => $mbl_no));
			return $ret;
		} else {
			//update customer info base on customer mobile number
			$ret = $this->db->update($this->table, $data, array('customer_mobile' => $mbl_no));
		
			//get customer info base on mobile number
			$cust_info = $this->getcustomerinfo($mbl_no);
		
			//send email to customer
			$customer_info = $this->send_email_tocustomer($mbl_no, $cust_info['customer_email'], $cust_info['customer_id']);
			
			//check email send or not
			if($customer_info) {
				return $ret;	
			} else{
				return FALSE;
			}
			
		}
	}
	/**
	* purpose: get wallet total amount base on sell and added buy
	* @param $cust_id
	* @return customer info
	* 
*/
	function getwalletcountbycustId($cust_id, $limit)
	{
		$this->load->library('subquery');
		$this->db->where('customer_id', $cust_id);
		$this->db->where('customer_active', '1');
		$this->db->order_by("customer_firstname", "asc");   
		$this->db->select('*')->from('customer_master c');
		$sub = $this->subquery->start_subquery('select');
		$sub->select('sum(txn_paid)-sum(txn_buy)')->from('cust_transaction')->where('customer_id=c.customer_id');
		$this->subquery->end_subquery('balance');  
		$this->db->limit($limit, 0);
		$query = $this->db->get();

		return $query->result(); 
	}
	
	/**
	* purpose: get customer name base on mobile id
	* @param $mbl_no
	* @return customer first latter of customer fname and customer lname
*/
	function getcustomerinfo($mbl_no)
	{
		// check $mbl_no empty or not if empty then return FALSE
		if(empty($mbl_no)) return FALSE;
		
		//get customer info base on mobile number
		$query = $this->db->get_where($this->table, array('customer_mobile' => $mbl_no));
		
		//execute query
		$result = $query->row_array();
		
		if(!empty($result)) {
			$result['fullname']	=	$result['customer_firstname'].' '.$result['customer_lastname'];
			$result['shortname']	=	strtoupper($result['customer_firstname'][0].''.$result['customer_lastname'][0]);
			
			return $result;
		} else{
			return FALSE;
		}
	}
	
	/**
	* purpose update email veriofication flag
	* @param $email
	* @param $id
	* 
*/
	function update_emailverification_flag($email, $id)
	{
		if (empty($id)) return FALSE;

		$data = array('email_verify_flag' =>'Y');

		$this->db->where('customer_email', trim($email));
		$this->db->where('customer_id', trim($id));
		$this->db->update($this->table, $data);
		
		$affected_row =  $this->db->affected_rows();
	//	echo 'flag::'.$affected_row;die;
		if($affected_row > 0) {
			return $statusupdate;	
		} else {
			return FALSE;
		}		
		
	}
	
	/**
	* purpose: send email to customer for verify email id
	* @param $mbl_no
	* @param $email_id
	* @return true if email send to customer
	*/
	function send_email_tocustomer($mbl_no, $email_id, $cust_id)
	{
		
		//encode customer info string
		$cust_info = base64_encode(json_encode(array("email" =>$email_id, "cust_id" =>$cust_id)));
		
		$headers = "MIME-Version: 1.0" . "\r\n";
		$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

        $subject = "Hi-Tech Money: Verify your Email Address";

        $message = '<html>
<head>
  <title></title>
</head>
<body>
 <p>Your profile has been updated. Please verify email id by clicking below link:</p><p><a href="'.base_url().'emailverify/index/'.$cust_info.'">Click Here</a></p>
</body>
</html>';
// send mail
        mail("mansi.gajjar@augustinfotechteam.com",$subject,$message,$headers);
		/*$this->load->library('email');
        $this->email->clear();
		
	    $config['mailtype'] = 'html';
        $data['messages_email_template'] =  '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
                                            <html xmlns="http://www.w3.org/1999/xhtml">
                                            <head>
                                            <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
                                            <title>HitechMoney: Verify EmailId</title>
                                            </head>
                                            <body>';
        $data['messages_email_template'] .= "<p>Your profile has been updated. Please verify email id by clicking below link:</p>";
        $data['messages_email_template'] .= "<p><a href=''>Click Here</a></p>";
        $data['messages_email_template'] .= '</body></html>';
        $this->email->initialize($config);
        $this->email->from($this->system->company_email, $this->system->marketing_site_name);
		$this->email->to('mansi.gajjar@augustinfotechteam.com');
		$this->email->bcc('mansi.gajjar@augustinfotechteam.com');
        //$this->email->to($email_id);
        //$this->email->bcc($this->system->debug_email_address);
        $this->email->subject('HitechMoney: Verify EmailId');
        $this->email->message($data['messages_email_template']);
        $this->email->send();*/

        return TRUE;	
	}
}
?>