<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class UserGroup_Model extends CI_Model
{
    function UserGroup_Model()
    {
        parent::__construct();
        $this->table="user_groups";
        $this->column_headers = array(
                                        "User Group"=>""
                                );
    }

    function get_usergroup_count()
    {
        return $this->db->count_all($this->table);	
    }

    function get_usergroup($exceptAdmin = 0)
    {
        $this->db->select('*');
        $this->db->where('user_group_active', '1');
        if($exceptAdmin)
            $this->db->where('user_group_id !=', '1');
        if($this->session->userdata('user_group_id') == 1 && $this->session->userdata('id') != 1)
            $this->db->where('user_group_id !=', '1');
        if($this->session->userdata('user_group_id') == 2)
        {
            $this->db->where('user_group_id !=', '1');
            $this->db->where('user_group_id !=', '2');
        }
        $query = $this->db->get($this->table);
        return $query->result_array();
    }

    function getCheckUserGroup($ugname)
    {
        $this->db->select('*');
        $query = $this->db->get_where($this->table, array('user_group_name' => $ugname));
        return $query->result_array();
    }

    function getCheckUserGroupEdit($ugname,$ugid)
    {
        $this->db->select('*');
        $query = $this->db->get_where($this->table, array('user_group_id' => $ugid));
        $result=$query->result_array();

        if($result[0]['user_group_name']==$ugname)
        {}
        else
        {
            $this->db->select('*');
            $query = $this->db->get_where($this->table, array('user_group_name' => $ugname));
            return $query->result_array();
        }
    }

    function insert()
    {
        $res=$this->getCheckUserGroup($this->input->post('usergroup_name'));
        if($res == NULL)
        {
            $data = array(
                            'user_group_name'       => $this->input->post('usergroup_name'),
                            'user_group_privileges' => json_encode($_POST),
                            'user_group_active'     => $this->input->post('user_group_active')
                    );

            $usergroup_data=$this->db->insert($this->table, $data);
            return TRUE;
        }
        else
        {
            return FALSE;	
        }
    }

    function update()
    {
        $res=$this->getCheckUserGroupEdit($this->input->post('usergroup_name'),$this->input->post('usergroup_id'));
        if($res == NULL)
        {
            $ids=$this->input->post('usergroup_id');
            $data = array(
                            'user_group_name'       =>  $this->input->post('usergroup_name'),
                            'user_group_privileges' =>  json_encode($_POST),
                            'user_group_active'     =>  $this->input->post('user_group_active')
                        );

            $usergroup_updatedata=$this->db->update($this->table, $data,array('user_group_id' => $ids));
            return $usergroup_updatedata;
        }
        else
        {
            return FALSE;	
        }
    }

    function get_usergroup_edit($groupid)
    {
        $query = $this->db->get_where($this->table, array('user_group_id' => $groupid));
        return $query->row_array();	
    }

    function deleteselected()
    {
        $this->db->where_in('user_group_id', $this->input->post('group_list'));

        if($query = $this->db->delete($this->table)) 
            return TRUE;
        else
            return FALSE;
    }

    function delete()
    {
        $this->db->where('user_group_id', $this->input->post('usergroupid'));
        if($query = $this->db->delete($this->table)) 
            return TRUE;
        else
            return FALSE;
    }

    # toggle active status
    function toggle_status($userId, $astatus)
    {
        if (empty($userId)) return 0;

        $data = array('user_group_active' =>	$astatus,
                                );

        $statusupdate	= $this->db->update($this->table, $data, array('user_group_id' => $userId));
        return $statusupdate;
    }
}
?>