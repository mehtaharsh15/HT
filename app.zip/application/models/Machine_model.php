<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Machine_model extends CI_Model
{
	# Constructor
	function Machine_model()
	{
		parent::__construct();

		$this->table		= 'machine_master';
	    $this->column_headers = array(
                                                'Machine Name'      =>'10%',
                                                'Machine Code'      =>'10%',
                                                 'Machine Latitude' =>'10%',
                                                'Machine Longitude' =>'10%'
                                              
                                            );
	}

	# it returns total active records count
	function get_machine_count()
	{
			$this->db->where('machine_active', '1');
			return $this->db->count_all_results($this->table);
	}

	# it returns array of active records
	function get_allmachine()
	{
            $this->db->select('*');
            $this->db->from($this->table);
			$this->db->where('machine_active', '1');
            $query = $this->db->get();
            return $query->result_array();
	  
	}

	# it checks for duplicate name
	function checkExistingmachine($machine_name, $id=0)
	{
		if($id > 0)
                    $this->db->where(array('machine_name' => $machine_name, 'machine_id !=' => $id));
				
		else
                    $this->db->where(array('machine_name' => $machine_name));
					$row_cnt	= $this->db->count_all_results($this->table);
		
		if($row_cnt > 0)
		{
                    return TRUE;
		}
		else
		{
                    return FALSE;
		}
	}

	

        # check for duplicate user name
        function checkMachineCode($code, $machine_id=0)
		{

            if($machine_id > 0)

                $this->db->where(array('machine_code' => $code, 'machine_id !=' => $machine_id));
            else
                $this->db->where(array('machine_code' => $code));
            $row_cnt	= $this->db->count_all_results($this->table);
				//print_r($row_cnt);
            if($row_cnt > 0)
            {
                return TRUE;
            }
            else
            {
                return FALSE;
            }
        }

        # it inserts record in table
	function insert()
	{
		
		$res1 = $this->checkExistingmachine($this->input->post('machine_name'));
		$res2 = $this->checkMachineCode($this->input->post('machine_code'));
		if($res1 == FALSE && $res2 == FALSE)
		{
			$objFuncLib	= new Functions();
			$api="http://maps.googleapis.com/maps/api/geocode/json?latlng=".$this->input->post('machine_latitude').",".$this->input->post('machine_longitude');
		
			$ch = curl_init();

			curl_setopt($ch, CURLOPT_URL,$api);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER,true);			

			$server_output = curl_exec ($ch);			
			curl_close ($ch);		
			$machine_output=json_decode($server_output);
			
			
			$resultArray = json_decode(json_encode($machine_output),TRUE);
			if(is_array($resultArray['results']['0']['address_components']['3']) && !empty ($resultArray['results']['0']['address_components']['3']['long_name']))
			{
				$machine_city = $resultArray['results']['0']['address_components']['3']['long_name'];
			}
			else{
				$machine_city= '';
			}
			
		
			$data = array(
							  'machine_name'       =>	$this->input->post('machine_name'),
                              'machine_code'       =>	$this->input->post('machine_code'),
                              'machine_latitude'   =>	$this->input->post('machine_latitude'),
                              'machine_longitude'  =>	$this->input->post('machine_longitude'),
                              'machine_city'  	   =>	$machine_city,
                              'machine_active' 	   =>	$this->input->post('machine_active'),
                              'machine_qrcode' 	   =>	'',
						);

			$partner_data	= $this->db->insert($this->table, $data);
			$PK		= $this->db->insert_id();
			return $PK;
		}
		else
			return FALSE;
	}

	# it updates record in table
	function update()
	{
		$res    = $this->checkExistingmachine($this->input->post('machine_name'), $this->input->post('machine_id'));
		$res2   = $this->checkMachineCode($this->input->post('machine_code'), $this->input->post('machine_id'));
		
		
		if($res == FALSE && $res2 == FALSE)
		{
			
			$PK	= $this->input->post('machine_id');

			
			$objFuncLib	= new Functions();

			$data = array(
						       'machine_name'	    =>	$this->input->post('machine_name'),
                               'machine_code'       =>	$this->input->post('machine_code'),
                               'machine_latitude' 	=>	$this->input->post('machine_latitude'),
                               'machine_longitude' 	=>	$this->input->post('machine_longitude'),
                           //  'machine_active' 	=>	$this->input->post('machine_active'),
						);
			
			$machine_updatedata=$this->db->update($this->table, $data, array('machine_id' => $PK));
			
			return $machine_updatedata;
		}
		else
		{
			return FALSE;
		}
	}

	# it returns record of particular id
	function get_machine_edit($machineId)
	{
		$query = $this->db->get_where($this->table, array('machine_id' => $machineId));
		return $query->row_array();
	}

	
	# toggle active status
	function toggle_status($machineId, $astatus)
	{
		if (empty($machineId)) return 0;

		$data = array('machine_active' =>	$astatus,
					);

		$statusupdate	= $this->db->update($this->table, $data, array('machine_id' => $machineId));
		return $statusupdate;
	}
	 function change_machineqr($machine_id,$machine_qr)
      {
			$this->db->where('machine_id', $machine_id);
			$this->db->set('machine_qrcode',$machine_qr);
			$this->db->update($this->table);
			
     }
	function getMachineinfoById($id)
    {
        $this->db->where('machine_id', $id);
        $result = $this->db->get($this->table);
        return $result->row();
    }

}
?>