<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Userlog_Model extends CI_Model
{
    function Userlog_Model()
    {
        parent::__construct();

        $this->table		= 'user_log';
     
    }

   function insertUserLog()
    {
        $data = array(
                        'user_log_user_id'          =>	$this->session->userdata('id'),
                        'user_log_ip'               =>	$this->functions->encrypt($this->input->ip_address()),
                        'user_log_login_time'       =>	time(),
                        'user_log_browser_agent'    =>	$this->input->user_agent()
                    );

        $user_log_data	= $this->db->insert('user_log', $data);
    }
}
?>