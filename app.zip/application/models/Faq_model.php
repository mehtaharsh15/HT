<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Faq_model extends CI_Model
{
	# Constructor
	function Faq_model()
	{
		parent::__construct();

		$this->table		= 'faq_master';
	    $this->column_headers = array(
                                               'FAQ Question'     =>'10%',
                                                'FAQ Answer'      =>'22%',
                                              
                                            );
	}

	# it returns total active records count
	function get_faq_count()
	{
			$this->db->where('faq_active', '1');
			return $this->db->count_all_results($this->table);
	}

	# it returns array of active records
	function get_allfaq()
	{
            $this->db->select('*');
            $this->db->from($this->table);
			$this->db->where('faq_active', '1');
            $query = $this->db->get();
            return $query->result_array();
	  
	}

	
    # it inserts record in table
	function insert()
	{
		
		$objFuncLib	= new Functions();

			$data = array(
							    'faq_question'	=>	$this->input->post('faq_question'),
                                'faq_answer'     =>	$this->input->post('faq_answer'),
                               'faq_active' 	=>	$this->input->post('faq_active'),
						);

			$partner_data	= $this->db->insert($this->table, $data);
			$PK		= $this->db->insert_id();
			return $PK;
		
	}

	# it updates record in table
	function update()
	{
		
		$PK	= $this->input->post('faq_id');

			
		$objFuncLib	= new Functions();

		$data = array(
				   'faq_question'	=>	$this->input->post('faq_question'),
                   'faq_answer'     =>	$this->input->post('faq_answer'),
                      );
			
		$faq_updatedata=$this->db->update($this->table, $data, array('faq_id' => $PK));
			
			return $faq_updatedata;
		
	}

	# it returns record of particular id
	function get_faq_edit($faqId)
	{
		$query = $this->db->get_where($this->table, array('faq_id' => $faqId));
		return $query->row_array();
	}

	
	# toggle active status
	function toggle_status($faqId, $astatus)
	{
		if (empty($faqId)) return 0;

		$data = array('faq_active' =>	$astatus,
					);

		$statusupdate	= $this->db->update($this->table, $data, array('faq_id' => $faqId));
		return $statusupdate;
	}
	
}
?>