<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Users_Model extends CI_Model
{
    function Users_Model()
    {
        parent::__construct();

        $this->table		= 'user_master';
        $this->column_headers	= array(
                                            'Username'	=>'10%',
                                            'User Group'=>'10%',
                                            'Name'	=>'10%',
                                            'Email'	=>'15%',
                                           
                                            'Client'	=>'15%'
                                        );
    }

    function get_users_count()
    {
        $userDetails = $this->common->getUserDetail($this->session->userdata('id'));
        $this->db->where('user_active', '1');
        if($userDetails[0]['user_client_id'] != 0)
            $this->db->where('user_client_id',$userDetails[0]['user_client_id']);
        return $this->db->count_all_results($this->table);
    }

    function get_users()
    {
        $userDetails = $this->common->getUserDetail($this->session->userdata('id'));

        $this->db->select('user_id,user_name,user_allowed_practice_id,user_allowed_group_id,user_allowed_physician_id,user_client_id,user_master.user_group_id,user_password,user_groups.user_group_name,user_active,user_last_login,user_firstname,user_lastname,user_email,user_contact');

        $this->db->from($this->table);
        $this->db->join('user_groups', 'user_master.user_group_id =user_groups.user_group_id');
        $this->db->where('user_active', '1');
        //if ($this->user->id != 1) $this->db->where('user_id', $this->user->id);
        if ($this->user->id != 1)
        {
            /*if($userDetails[0]['user_allowed_practice_id'] != 0)
                $this->db->where('user_allowed_practice_id', $userDetails[0]['user_allowed_practice_id']);
            if($userDetails[0]['user_allowed_group_id'] != 0)
                $this->db->where('user_allowed_group_id', $userDetails[0]['user_allowed_group_id']);
            if($userDetails[0]['user_allowed_physician_id'] != 0)
                $this->db->where('user_allowed_physician_id', $userDetails[0]['user_allowed_physician_id']);*/
            if($userDetails[0]['user_client_id'] != 0)
                $this->db->where('user_client_id',$userDetails[0]['user_client_id']);
        }
        $query = $this->db->get();
        /*echo "<pre>";
        print_r($query->result_array());*/
        return $query->result_array();
    }

    # check for duplicate user name
    function getCheckUser($uname, $id=0)
    {
        if($id > 0)
            $this->db->where(array('user_name' => $uname, 'user_id !=' => $id));
        else
            $this->db->where(array('user_name' => $uname));
        $row_cnt	= $this->db->count_all_results($this->table);

        if($row_cnt > 0)
        {
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }

    # create new user profile
    function insert()
    {
        $res	= $this->getCheckUser($this->input->post('user_username'));

        if($res == FALSE)
        {
            $data = array(
                            'user_name' 		=>	$this->input->post('user_username'),
                            'user_password' 		=>	md5($this->input->post('user_password')),
                            'user_password_last_changed'=>      time(),
                            'user_group_id' 		=>	$this->input->post('user_group_id'),
                            'user_last_login' 		=>	date('Y-m-d H:m:s'),
                            'user_active' 		=>	$this->input->post('is_active'),
                            'user_firstname' 		=>	$this->input->post('user_firstname'),
                            'user_lastname' 		=>	$this->input->post('user_lastname'),
                            'user_email' 		=>	$this->input->post('user_email'),
                            'user_contact' 		=>	$this->input->post('user_contactno')?$this->input->post('user_contactno'):'',
                            /*'user_allowed_practice_id' 	=>	$this->input->post('user_allowed_practice_id'),
                            'user_allowed_group_id' 	=>	$this->input->post('user_allowed_group_id'),
                            'user_allowed_physician_id' =>	$this->input->post('user_allowed_physician_id')*/
                            'user_client_id'            =>	$this->input->post('user_client_id')
                        );

            $user_data	= $this->db->insert($this->table, $data);
            $PK			= $this->db->insert_id();
            $this->sendEmail();

            return $PK;
        }
        else
        {
            return FALSE;
        }
    }

    # update user info
    function update()
    {
        $res	= $this->getCheckUser($this->input->post('user_username'), $this->input->post('usersid'));

        if($res == FALSE)
        {
            $PK	= $this->input->post('usersid');

            $data 	= array(
                            'user_name' 				=>	$this->input->post('user_username'),
                            //'user_password' 			=>	$pass,
                            'user_password_last_changed'=>  time(),
                            'user_group_id' 			=>	$this->input->post('user_group_id'),
                            'user_last_login' 			=>	date('Y-m-d H:m:s'),
                            //'user_active' 			=>	$this->input->post('is_active'),
                            'user_firstname' 			=>	$this->input->post('user_firstname'),
                            'user_lastname' 			=>	$this->input->post('user_lastname'),
                            'user_email' 				=>	$this->input->post('user_email'),
                            'user_contact' 				=>	$this->input->post('user_contactno')?$this->input->post('user_contactno'):'',
                            /*'user_allowed_practice_id'=>	$this->input->post('user_allowed_practice_id'),
                            'user_allowed_group_id' 	=>	$this->input->post('user_allowed_group_id'),
                            'user_allowed_physician_id' =>	$this->input->post('user_allowed_physician_id')*/
                            'user_client_id'            =>	$this->input->post('user_client_id')
                        );

            if($this->input->post('user_password') != '')
            {
                $pass	= md5($this->input->post('user_password'));
                $data	= array_merge($data, array('user_password'	=> $pass));
                if($PK != $this->user->id)
                        $this->sendEmail(TRUE);
            }
            $user_updatedata	= $this->db->update($this->table, $data, array('user_id' => $PK));
            return $user_updatedata;
        }
        else
        {
            return FALSE;
        }
    }

    function sendEmail($isPasswordChanged = FALSE)
    {
        /*
        $to = $this->input->post('user_email');
        $subject = 'Cicms';

        $headers = "From: " .$this->system->company_email. "\r\n";
        $headers .= "Reply-To: ". $this->input->post('user_email'). "\r\n";
        $headers .= "CC: ".$this->system->company_email."\r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
        */

        $message = "<p>Hello ".$this->input->post('user_firstname').",</p>";
        $message .= "<table rules='all' style='border-color: #666;' cellpadding='10'>";

        # Set the content according to the password change flag
        /*if($isPasswordChanged)
                $message .= "<tr><td colspan='2'>Your login password has been changed. Please find the new login details below:</td></tr>";
        else
                $message .= "<tr><td colspan='2'>Please find the login details below:</td></tr>";*/
        if($isPasswordChanged)
                $message .= "<tr><td colspan='2'>Your login password has been changed. Please find the details below:</td></tr>";
        else
                $message .= "<tr><td colspan='2'>Please find the details below:</td></tr>";

        $message .= "<tr><td><strong>Link:</strong></td><td><a href='".base_url()."index.php/admin/login.html' target='_blank'>".base_url()."index.php/admin/login.html</a></td></tr>";
        $message .= "<tr style='background: #eee;'><td><strong>User Name:</strong></td><td>".$this->input->post('user_username')."</td></tr>";
        //$message .= "<tr><td><strong>Password:</strong></td><td>".$this->input->post('user_password')."</td></tr>";
        $message .= "</table>";
        //mail($to, $subject, $message, $headers);

        $this->load->library('email');
        $this->email->clear();

        $config['mailtype'] = 'html';

        $this->email->initialize($config);
        $this->email->from($this->system->company_email, 'rockhopperZSG');
        $this->email->to($this->input->post('user_email'));
        $this->email->bcc($this->system->debug_email_address);

        # Set the subject according to the password change flag
        if($isPasswordChanged)
            $this->email->subject('rockhopperZSG: The password has been changed.');
        else
            $this->email->subject('Welcome to rockhopperZSG');

        $this->email->message($message);

        $this->email->send();
        //$this->email->print_debugger();die;
        //echo $message;die;
        return TRUE;
    }
    function get_users_edit($userid)
    {
        $query = $this->db->get_where($this->table, array('user_id' => $userid));
        return $query->row_array();
    }

    function deleteselected()
    {
        $this->db->where_in('user_id', $this->input->post('users_list'));
        if($query = $this->db->delete($this->table))
            return TRUE;
        else
            return FALSE;
    }

    function delete()
    {
        $this->db->where('user_id', $this->input->post('userid'));
        if($query = $this->db->delete($this->table))
            return TRUE;
        else
            return FALSE;
    }

    # toggle active status
    function toggle_status($userId, $astatus)
    {
        if (empty($userId)) return 0;

        $data = array('user_active' =>	$astatus,
                        );

        $statusupdate   = $this->db->update($this->table, $data, array('user_id' => $userId));
        return $statusupdate;
    }

    function changeVisibleStatus()
    {
        $this->db->set('user_active', $this->input->post('publish'));
        $this->db->where('user_id', $this->input->post('userid'));
        $this->db->update($this->table);
        return TRUE;
    }
}
?>