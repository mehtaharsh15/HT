<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Common_Model extends CI_Model {
    # Constructor
    function Common_Model()
    {
        parent::__construct();
        $this->table = 'user_groups';
    }

    # check for website user permission
    function permission($rolename)
    {
        $groupid	= $this->session->userdata('user_group_id');

        # Administrator
        if($groupid == 1)
        {
            return TRUE;
        }
        # Other users
        else
        {
            $this->db->where(array("user_group_id" => $groupid));
            $groups	= $this->db->get($this->table);
            $ans	= $groups->row_array();

            $result	= json_decode($ans['user_group_privileges']);
            if($result->{$rolename} == 1)
            {
                return TRUE;
            }
            else
            {
                redirect('admin/noaccess/index');
            }
        }
    }

    # check for website admin user permission
    function admin_permission($rolename, $module, $submodule = '', $returnBoolean = FALSE)
    {
        $groupid	= $this->session->userdata('user_group_id');	
        //echo $groupid;die;
        # Administrator
        if($groupid == 1)
        {
            return TRUE;
        }
        # Sub-Admin
        else//if($groupid == 2)
        {
            $this->db->where(array("user_group_id"=>$groupid));
            $groups	= $this->db->get($this->table);
            $ans	= $groups->row_array();
            $result	= json_decode($ans['user_group_privileges'],TRUE);
           
            if(!empty($submodule))
            {
                if(is_array($result['user_group_privileges'][$module][$submodule]['permissions']) && array_key_exists($rolename, $result['user_group_privileges'][$module][$submodule]['permissions']))
                {
                    return TRUE;
                }
                else
                {
                    if($returnBoolean)
                        return FALSE;
                    else
                        redirect('admin/noaccess/index');
                }
            }
            elseif(empty($submodule) && $module == 'Settings')
            {
                if(is_array($result['user_group_privileges'][$module]))
                {
                    return TRUE;
                }
                else
                {
                    if($returnBoolean)
                        return FALSE;
                    else
                        redirect('admin/noaccess/index');
                }
            }
            else
            {
                if(is_array($result['user_group_privileges'][$module]['permissions']) && array_key_exists($rolename, $result['user_group_privileges'][$module]['permissions']))
                {
                    return TRUE;
                }
                else
                {
                    if($returnBoolean)
                        return FALSE;
                    else
                        redirect('admin/noaccess/index');
                }
            }
        }
       
    }

    function getUserDetail($user_id)
    {
        $this->db->select('*');
        $this->db->where(array("user_id"=>$user_id));
        $query=$this->db->get('user_master');
       
        return $query->result_array();
    }

    function getUserGroupDetail($user_group)
    {
        $this->db->select('*');
        $this->db->where(array("user_group_id"=>$user_group));
        $query=$this->db->get($this->table);

        return $query->result_array();
    }
}
?>