<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Sell_model extends CI_Model
{
	# Constructor
	function Sell_model()
	{
		parent::__construct();

		$this->table		= 'sell_master';
	    $this->column_headers = array(
                                                'Txn-No'     	 =>'10%',
                                                'Date'      	 =>'10%',
                                                'UOM'      		 =>'10%',
                                                'Customer Name'  =>'10%',
												'Machine Code'   =>'10%',
                                                'Amount' 		 =>'10%',
                                                'Qunatity' 		 =>'10%'
                                                
                                              
                                            );
	}
	
	
	# it returns array of active records
	function get_allsell($admin_flag=true, $cust_id, $limit='')
	{
			//for website section check custmer id blank or not
            if($admin_flag != true) {
				if(empty($cust_id)) return FALSE;
			}
						
			$this->db->select('sell_id,sell_date,sell_uom,sell_txn_no,customer_firstname,customer_lastname,machine_code,machine_latitude, machine_longitude, sell_amount,sell_qty');    
			$this->db->from('sell_master');
			$this->db->join('customer_master', 'sell_master.sell_customer_id = customer_master.customer_id');
			$this->db->join('machine_master', 'sell_master.sell_machine_id = machine_master.machine_id');
			$this->db->join('cust_transaction', 'sell_master.sell_txn_id = cust_transaction.txn_id');
			
			if($admin_flag != true) {
				$this->db->where('sell_customer_id', $cust_id);
			}	
			
			$this->db->where('sell_active', '1');
			$this->db->order_by("sell_id","desc");
			if($limit > 0) {
				$this->db->limit($limit,0);
			}
			
			$query = $this->db->get();
			return $query->result_array();
	
	}
	
	# toggle active status
	function toggle_status($sellId, $astatus)
	{
		if (empty($sellId)) return 0;

		$data = array('sell_active' =>	$astatus,
					);

		$statusupdate	= $this->db->update($this->table, $data, array('sell_id' => $sellId));
		return $statusupdate;
	}
	

	
	
	/* # it returns total active records count
	function get_machine_count()
	{
			$this->db->where('machine_active', '1');
			return $this->db->count_all_results($this->table);
	}

	
	# it inserts record in table
	function insert()
	{
		
		$res1 = $this->checkExistingmachine($this->input->post('machine_name'));
		$res2 = $this->checkMachineCode($this->input->post('machine_code'));
		if($res1 == FALSE && $res2 == FALSE)
		{
		
			$objFuncLib	= new Functions();

			$data = array(
							  'machine_name'       =>	$this->input->post('machine_name'),
                              'machine_code'       =>	$this->input->post('machine_code'),
                              'machine_latitude'   =>	$this->input->post('machine_latitude'),
                              'machine_longitude'  =>	$this->input->post('machine_longitude'),
                              'machine_active' 	   =>	$this->input->post('machine_active'),
                              'machine_qrcode' 	   =>	'',
						);

			$partner_data	= $this->db->insert($this->table, $data);
			$PK		= $this->db->insert_id();
			return $PK;
		}
		else
			return FALSE;
	} */

	# it updates record in table
	function update()
	{
		$res    = $this->checkExistingmachine($this->input->post('machine_name'), $this->input->post('machine_id'));
		$res2   = $this->checkMachineCode($this->input->post('machine_code'), $this->input->post('machine_id'));
		
		
		if($res == FALSE && $res2 == FALSE)
		{
			
			$PK	= $this->input->post('machine_id');

			
			$objFuncLib	= new Functions();

			$data = array(
						       'machine_name'	    =>	$this->input->post('machine_name'),
                               'machine_code'       =>	$this->input->post('machine_code'),
                               'machine_latitude' 	=>	$this->input->post('machine_latitude'),
                               'machine_longitude' 	=>	$this->input->post('machine_longitude'),
                           //  'machine_active' 	=>	$this->input->post('machine_active'),
						);
			
			$machine_updatedata=$this->db->update($this->table, $data, array('machine_id' => $PK));
			
			return $machine_updatedata;
		}
		else
		{
			return FALSE;
		}
	}

	# it returns record of particular id
	function getsellInfobyId($sellId)
	{
		    $this->db->select('sell_id,sell_date,sell_uom,sell_txn_no,customer_firstname,customer_lastname,machine_code,machine_latitude, machine_longitude, sell_amount,sell_qty');    
			$this->db->from('sell_master');
			$this->db->join('customer_master', 'sell_master.sell_customer_id = customer_master.customer_id');
			$this->db->join('machine_master', 'sell_master.sell_machine_id = machine_master.machine_id');
			$this->db->join('cust_transaction', 'sell_master.sell_txn_id = cust_transaction.txn_id');
			$this->db->where('sell_id' , $sellId);
			$query = $this->db->get();
			return $query->result_array();
	}
	/**
	* purpose: Get last txn year,month
	* @param $cust_id
	* @return month,year
*/
	function getMonthYearOfSellByCustId($cust_id)
	{
		if(empty($cust_id)) return FALSE;
		
		$this->db->select('sell_date');    
		$this->db->from('sell_master');
		$this->db->where('sell_customer_id', $cust_id);
		$this->db->where('sell_active', '1');
		$this->db->order_by("sell_id","desc");

		$this->db->limit(1,0);
		$query = $this->db->get();
		
		$info = $query->result_array();
		
		if(!empty($info))
		{
			$datearray =  explode("-",$info[0]['sell_date']);
		
			$dateyeararray = array('month'=> $datearray[1],
							   'year' => $datearray[0]
							);
			
			return $dateyeararray;				
		}
		else {
			return FALSE;			
		}
	}
	
	function get_allsellinfo($cust_id, $limit='')
	{
		//for website section check custmer id blank or not
		if(empty($cust_id)) return FALSE;
		
		//get last txn year month 
		$yearmontharray =  $this->getMonthYearOfSellByCustId($cust_id);
		
		$this->db->select('sell_id, sell_date, sell_uom, sell_txn_no, customer_firstname, customer_lastname, machine_code, machine_city, sell_amount, sell_qty');    
		$this->db->from('sell_master');
		$this->db->join('customer_master', 'sell_master.sell_customer_id = customer_master.customer_id');
		$this->db->join('machine_master', 'sell_master.sell_machine_id = machine_master.machine_id');
		$this->db->join('cust_transaction', 'sell_master.sell_txn_id = cust_transaction.txn_id');
		$this->db->where('sell_customer_id', $cust_id);
		
		//check last month date info exits or not
		if(!empty($yearmontharray)) {
			$this->db->where('Year(sell_date)', $yearmontharray['year']);
			$this->db->where('Month(sell_date)', $yearmontharray['month']);
		}
		
		$this->db->where('sell_active', '1');
		$this->db->order_by("sell_id","desc");

		if(!empty($limit))
			$this->db->limit($limit,0);

		$query = $this->db->get();
		
		$sell_info = $query->result_array();
		
		$rsrecord = array('dateinfo' => $yearmontharray,
						  'sellinfo'	=>	$sell_info,
						);
		
		return $rsrecord;
	} 

}
?>