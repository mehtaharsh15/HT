<?php  
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class HttpsHook
{
    var $obj;

    //--------------------------------------------------
    //constructor
    function HttpsHook()
    {
        $this->obj =& get_instance();
    }
    function is_https_on()
    {
        if ( ! isset($_SERVER['HTTPS']) || $_SERVER['HTTPS'] != 'on' )
        {
            return FALSE;
        }

        return TRUE;
    }

    function force_ssl()
    {
        $url = $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];

        if ( ! $this->is_https_on() && $_SERVER['SERVER_PORT'] != '1010')
        {
            redirect('https://' . $url, 'location', 301 );
            exit;
        }
    }
}
?>