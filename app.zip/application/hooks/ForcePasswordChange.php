<?php  
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class ForcePasswordChange
{
    var $obj;

    //--------------------------------------------------
    //constructor
    function ForcePasswordChange()
    {
        $this->obj =& get_instance();
    }
    function checkpasswordchange()
    {
        //echo "hook";
		//die;
        $forcepasswordchange= $this->obj->session->userdata('forcepasswordchange');
        //echo $this->obj->input->post('forcepasswordchange');die;
        if($forcepasswordchange && !$this->obj->input->post('forcepasswordchange'))
        //if($forcepasswordchange)
        {
            //echo "aa";die;
            redirect('admin/login/dologin/');
            //redirect('admin/login/');
        }
       
    }
}
?>