<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');$this->load->view('admin/header');?>
<!--<link href="<?php echo base_url().$this->config->item('stylesheet_path');?>css.css" media="screen" rel="stylesheet" type="text/css" />-->
<div id="content" class="span12 section-body">
	<?php //if ($this->session->flashdata('usermsg')): 
		if (isset($usererrormsg) && !empty($usererrormsg)):?>
      <div class="alert alert-error">
          <a class="close" data-dismiss="alert" href="#">×</a>
          <?php //echo $this->session->flashdata('usermsg');?> <?php /*echo $this->session->flashdata('usermsg');*/?>
          <?php echo $usererrormsg;?>
      </div>
    <?php endif; ?>
  <div id="section-body" class="tabbable"> <!-- Only required for left/right tabs -->
    <ul class="nav nav-tabs">
      <li><a href="<?php echo base_url()?>admin/users/index">User Listing</a></li>
      <li  <?php if($Action == 'Add'):?>class="active"<?php endif;?>>
          <a href="<?php echo base_url()?>admin/users/insert">Add New User</a></li>
      <?php if($Action == 'Edit'):?>
      <li class="active"><a href="#tab1" data-toggle="tab"><?php echo "Edit User"; ?></a></li>
      <?php endif; ?>
    </ul>
    <div class="tab-content">
      <div class="tab-pane active" id="tab1">
        <div class="row-fluid"> 
          <!--Tabs2-->
          <div class="span12">
            <div id="accordion1" class="accordion">
              <div class="accordion-group">
                <div class="accordion-heading">
                    <a class="accordion-toggle" data-toggle="collapse" href="#notification" data-original-title=""> <i class="icon-user icon-white"></i> <span class="divider-vertical"></span>
                        <?php if($Action == 'Edit'): echo "Edit User"; else: echo "Add New User"; endif;?>
                        <i class="icon-chevron-down icon-white pull-right"></i>
                    </a>
                </div>
                <div id="notification" class="accordion-body collapse in">
                  <div class="accordion-inner paddind">
                    <div class="mandatory-note">
                      Fields marked with * are mandatory.
                      <br/>
                    </div>
                    <form name="frmusers" id="form" action="<?php if($Action == 'Add'): ?><?php echo base_url();?>admin/users/insert<?php else: ?><?php echo base_url();?>admin/users/edit<?php endif; ?>" method="post" enctype="multipart/form-data">
                      <table  class="table table-bordered table-striped pull-left">
                        <tbody>
                          <tr class="control-group">
                            <td class="control-label"><span class="fieldlabel"><span class="mandatory-star">*</span>First Name:</span></td>
                            <td class="controls"><input type="text" class="required" required name="user_firstname" maxlength="30" id="user_firstname" value="<?php echo $users_edit_entry['user_firstname']; ?><?php if($duplicate['user_firstname']): echo $duplicate['user_firstname'] ;endif;?>"></td>
                          </tr>
                          <tr class="control-group">
                            <td class="control-label"><span class="fieldlabel"><span class="mandatory-star">*</span>Last Name:</span></td>
                            <td class="controls"><input type="text" class="required" required name="user_lastname" id="user_lastname" maxlength="30" value="<?php echo $users_edit_entry['user_lastname']; ?><?php if($duplicate['user_lastname']): echo $duplicate['user_lastname'] ;endif;?>"></td>
                          </tr>
                          <tr class="control-group">
                            <td class="control-label" ><span class="fieldlabel"><span class="mandatory-star">*</span>Email:</span></td>
                            <td class="controls"><input type="text" class="required email" required name="user_email" id="user_email" maxlength="60" value="<?php echo $users_edit_entry['user_email']; ?><?php if($duplicate['user_email']): echo $duplicate['user_email'] ;endif;?>"></td>
                          </tr>
                          <!--<tr class="control-group">
                            <td class="control-label"><span class="fieldlabel"><span class="mandatory-star">*</span>Contact No:</span></td>
                            <td class="controls"><input type="text" class="required phone" required minlength="7" maxlength="14" name="user_contactno" id="user_contactno" value="<?php echo $users_edit_entry['user_contact']; ?><?php if($duplicate['user_contact']): echo $duplicate['user_contact'] ;endif;?>"></td>
                          </tr>-->
                          <tr>
                            <td><span class="fieldlabel"><span class="mandatory-star">*</span>User Group:</span></td>
                            <td>
                              <?php /*if($users_edit_entry['user_id'] == 1 || $this->user->user_group_id != 1):?>
                                <?php foreach($usergroups as $key => $val): ?>
                                    <?php if($val['user_group_id'] == $users_edit_entry['user_group_id']): ?>
                                    <input type="hidden" name="user_group_id" id="user_group_id" value="<?php echo $users_edit_entry['user_group_id'];?>" />
                                    <?php echo $val['user_group_name'];?>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                              <?php else:*/?>
                                <select id="user_group_id" name="user_group_id" class="required" required>
                                    <option></option>
                                    <?php foreach($usergroups as $key => $val): ?>
                                    <?php if($val['user_group_id'] == $users_edit_entry['user_group_id']): ?>
                                    <option value="<?php echo $val['user_group_id']?>" selected="selected"><?php echo $val['user_group_name'];?></option>
                                    <?php else: ?>
                                    <option value="<?php echo $val['user_group_id']?>"><?php echo $val['user_group_name'];?></option>
                                    <?php endif; ?>
                                    <?php endforeach; ?>
                                </select>
                              <?php //endif;?>
                            </td>
                          </tr>
                          <tr>
                            <td><span class="fieldlabel"><span class="mandatory-star">*</span>Client:</span></td>
                            <td>
                              <?php /*if($users_edit_entry['user_id'] == 1 || $this->user->user_group_id != 1):?>
                                <?php foreach($usergroups as $key => $val): ?>
                                    <?php if($val['user_client_id'] == $users_edit_entry['user_client_id']): ?>
                                    <input type="hidden" name="user_client_id" id="user_client_id" value="<?php echo $users_edit_entry['user_client_id'];?>" />
                                    <?php echo $val['user_client_name'];?>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                              <?php else:*/
                                    /*echo "<pre>";
                                    print_r($userclients);*/
                                ?>
                                <select id="user_client_id" name="user_client_id" class="required" required>
                                    <option></option>
                                    <?php foreach($userclients as $key => $val): ?>
                                    <?php if($val['client_id'] == $users_edit_entry['user_client_id']): ?>
                                    <option value="<?php echo $val['client_id']?>" selected="selected"><?php echo $val['client_company_name'];?></option>
                                    <?php else: ?>
                                    <option value="<?php echo $val['client_id']?>"><?php echo $val['client_company_name'];?></option>
                                    <?php endif; ?>
                                    <?php endforeach; ?>
                                </select>
                              <?php //endif;?>
                            </td>
                          </tr>
                          <tr class="control-group">
                            <td class="control-label"><span class="fieldlabel"><span class="mandatory-star">*</span>Username:</span></td>
                            <td class="controls">
                            <?php //if($users_edit_entry['user_id'] == 1 || $Action == 'Edit'):?>
                                <input type="text" class="required" required name="user_username" id="user_username" value="<?php echo $users_edit_entry['user_name']; ?>" <?php if($users_edit_entry['user_id'] == 1 || $Action == 'Edit') echo 'readonly'; ?>/>
                              <?php //else:?>
                                <!--<input type="text" class="required" required minlength="6" maxlength="20" name="user_username" id="user_username" value="<?php echo $users_edit_entry['user_name']; ?><?php if($duplicate['user_name']): echo $duplicate['user_name'] ;endif;?>">-->
                              <?php //endif;?>
                              <!--<div id="Info" style="display:block;float:left;margin-left:244px;margin-top:-66px;"></div>-->
                            </td>
                          </tr>
                          <tr class="control-group">
                            <td class="control-label"><span class="fieldlabel"><?php if($Action == 'Add'):?><span class="mandatory-star">*</span><?php endif;?>Password:</span></td>
                            <td class="controls"><input type="password" <?php if($Action == 'Add'):?>class="required" required minlength="6"  <?php endif;?> name="user_password" value="" id="password" maxlength="20" >
                              <input type="hidden" name="oldpassword" value="<?php echo $users_edit_entry['user_password']; ?>">
                              <?php if($Action == 'Edit'):?>
	                              <div class="redText">Please leave this field blank if you do not want to update the password.</div>
                                <?php endif;?>
                            </td>
                          </tr>
                          <tr class="control-group">
                            <td class="control-label"><span class="fieldlabel"><?php if($Action == 'Add'):?><span class="mandatory-star">*</span><?php endif;?>Verify Password:</span></td>
                            <td class="controls"><input type="password" <?php if($Action == 'Add'):?>class="required" required  minlength="6"<?php endif;?> equalto="#password"  name="user_vpassword"  id="user_vpassword" value=""></td>
                          </tr>
                        <?php
                        if($this->uri->segment(3) != 'edit')
                        {
                        ?>
                          <tr>
                            <td><span class="fieldlabel"><span class="mandatory-star">*</span>Status:</span></td>
                            <td>
                              <?php global $asset; ?>
                                  <select id="is_active" name="is_active"<?php if($users_edit_entry['user_id'] == 1) echo 'disabled';?>>
                                    <?php foreach($asset['SD_Active'] as $key => $val): ?>
                                    <?php if(isset($users_edit_entry['user_active']))
                                          {
                                              if($key == $users_edit_entry['user_active'])
                                              {
                                    ?>
                                                <option value="<?php echo $key?>" selected="selected"><?php echo $val?></option>
                                    <?php     }
                                              else
                                              {
                                    ?>
                                                <option value="<?php echo $key?>"><?php echo $val?></option>
                                    <?php 
                                              }
                                          }
                                          else
                                          {
                                              if($key == 1)
                                              {
                                    ?>
                                                <option value="<?php echo $key?>" selected="selected"><?php echo $val?></option>
                                    <?php     }
                                              else
                                              {
                                    ?>
                                                <option value="<?php echo $key?>"><?php echo $val?></option>
                                    <?php 
                                              }
                                          }
                                    ?>
                                    <?php endforeach; ?>
                                  </select>
                          	</td>
                          </tr>
                        <?php
                        }
                        ?>
                          <tr>
                          	<td>&nbsp;</td>
                            <td class="stdLabel" style="text-align:left;"><input type="submit" name="submit" class="btn btn-primary" value="<?php if($Action == 'Add'): ?>Save<?php else: ?>Update<?php endif; ?>" />
                              &nbsp;&nbsp;
                              <input type="button" name="cancel" class="btn" value="Cancel"  onclick="location.href='<?php echo base_url();?>admin/users/index/'"/></td>
                          </tr>
                        </tbody>
                      </table>
                      <input type="hidden" name="Action" id="Action" value="<?php echo $Action;?>" />
                      <input type="hidden" name="usersid" id="usersid" value="<?php echo $users_edit_entry['user_id'];?>" />
                    </form>
                    <br />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $this->load->view('admin/footer');?>
<script>
$(".phone").mask("(999) 999-9999");
</script>