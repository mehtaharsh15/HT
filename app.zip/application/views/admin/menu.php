<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
global $asset;

if($this->uri->segment(2)=='home')
{
    $activeClassHome = 'class="active"';
}

elseif($this->uri->segment(2)=='practice')
{
    $activeClassModules = ' active';
    $activeClassManagement = ' active';
    $subPractice = 'class="submenu-active"';
}
elseif($this->uri->segment(2)=='group')
{
    $activeClassModules = ' active';
    $activeClassManagement = ' active';
    $subGroup = 'class="submenu-active"';
}
elseif($this->uri->segment(2)=='physician')
{
    $activeClassModules = ' active';
    $activeClassManagement = ' active';
    $subPhysician = 'class="submenu-active"';
}
elseif($this->uri->segment(2)=='client')
{
    $activeClassModules = ' active';
    $activeClassManagement = ' active';
    $subClient = 'class="submenu-active"';
}
elseif($this->uri->segment(2)=='partner')
{
    $activeClassModules = ' active';
    $activeClassManagement = ' active';
    $subPartner = 'class="submenu-active"';
}

elseif($this->uri->segment(2)=='clientmessages')
{
    $activeClassModules = ' active';
    $activeClassManagement = ' active';
    $subMessages = 'class="submenu-active"';
}
elseif($this->uri->segment(2)=='users')
{
    $activeClassUsers = ' active';
    $activeClassManage_Users = ' active';
    $subUsers = 'class="submenu-active"';
}
elseif($this->uri->segment(2)=='usergroup')
{
    $activeClassUsers = ' active';
    $activeClassManage_Users = ' active';
    $subUserGroups = 'class="submenu-active"';
}
elseif($this->uri->segment(2)=='settings')
{
    $activeClassSettings = 'class="active"';
}
$isPracticeModuleAllowed = FALSE;
$isPracticeModuleAllowed = $this->common->admin_permission('Practice_View','Management','Practice',TRUE) || $this->common->admin_permission('Practice_Add','Management','Practice',TRUE) || $this->common->admin_permission('Practice_Edit','Management','Practice',TRUE) || $this->common->admin_permission('Practice_Delete','Management','Practice',TRUE);
$isGroupModuleAllowed = FALSE;
$isGroupModuleAllowed = $this->common->admin_permission('Group_View','Management','Group',TRUE) || $this->common->admin_permission('Group_Add','Management','Group',TRUE) || $this->common->admin_permission('Group_Edit','Management','Group',TRUE) || $this->common->admin_permission('Group_Delete','Management','Group',TRUE);
$isPhysicianModuleAllowed = FALSE;
$isPhysicianModuleAllowed = $this->common->admin_permission('Physician_View','Management','Physician',TRUE) || $this->common->admin_permission('Physician_Add','Management','Physician',TRUE) || $this->common->admin_permission('Physician_Edit','Management','Physician',TRUE) || $this->common->admin_permission('Physician_Delete','Management','Physician',TRUE);
$isClientModuleAllowed = FALSE;
$isClientModuleAllowed = $this->common->admin_permission('Client_View','Management','Client',TRUE) || $this->common->admin_permission('Client_Add','Management','Client',TRUE) || $this->common->admin_permission('Client_Edit','Management','Client',TRUE) || $this->common->admin_permission('Client_Delete','Management','Client',TRUE);
$isPartnerModuleAllowed = FALSE;
$isPartnerModuleAllowed = $this->common->admin_permission('Partner_View','Management','Partner',TRUE) || $this->common->admin_permission('Partner_Add','Management','Partner',TRUE) || $this->common->admin_permission('Partner_Edit','Management','Partner',TRUE) || $this->common->admin_permission('Partner_Delete','Management','Partner',TRUE);
$isClientMsgModuleAllowed = FALSE;
$isClientMsgModuleAllowed = $this->common->admin_permission('Client_Messages_View','Management','Client_Messages',TRUE) || $this->common->admin_permission('Client_Messages_Add','Management','Client_Messages',TRUE) || $this->common->admin_permission('Client_Messages_Edit','Management','Client_Messages',TRUE) || $this->common->admin_permission('Client_Messages_Delete','Management','Client_Messages',TRUE);

$groupid	= $this->session->userdata('user_group_id');
$this->db->where(array("user_group_id"=>$groupid));
$groups	= $this->db->get('user_groups');
$ans	= $groups->row_array();
$result	= json_decode($ans['user_group_privileges'],TRUE);
?>
<div class="container-fluid menu">
    <div class="mainmenu">
      <ul id="adminmenu" class="nav">
            <?php
                foreach ($asset['SD_UserGroup_Permissions'] as $key => $value):
                   
                    if((is_array($result['user_group_privileges'][$key]) && !empty($result['user_group_privileges'][$key])) || $groupid == 1)
                    {
				
                        if(is_array($value['Submenu']))
                        {
                           
            ?>
                            <li class="dropdown ">
                                <a href="javascript:;" class="dropdown-toggle menuLink" data-toggle="dropdown">
                                    <i class="<?php echo $value['Icon']; if(!isset($$parentActive))echo ' icon-white';?>"></i>
                                    <span><?php echo $value['Title']; ?></span>
                                    <b class="caret"></b>
                                </a>
                                <ul id="menu<?php echo $value['Title']; ?>" class="dropdown-menu" role="menu" aria-labelledby="menuLink">
                                    <?php
                                        foreach ($value['Submenu'] as $keySub => $valueSub):
                                            if((is_array($result['user_group_privileges'][$key][$keySub]) && !empty($result['user_group_privileges'][$key][$keySub])) || $groupid == 1)
                                            {
                                    ?>
                                                <li>
                                                    <a href="<?php echo base_url().'admin/'.$valueSub['Link'].'/index/'; ?>" <?php  if($valueSub['Link'] == $this->uri->segment(2))echo 'class="submenu-active"';?>><?php echo $valueSub['Title']; ?></a>
                                                </li>
                                    <?php
                                            }
                                        endforeach;
                                    ?>
                                </ul>
                            </li>
            <?php
                        }
                        else
                        {
            ?>
                            <li <?php if($value['Link'] == $this->uri->segment(2))echo 'class="active"';/*echo $activeClassHome;*/ ?>>
                                <a href="<?php echo base_url().'admin/'.$value['Link'].'/index/';?>" <?php echo $home;?>>
                                    <i class="<?php echo $value['Icon']; if($value['Link'] != $this->uri->segment(2))echo ' icon-white';?>"></i>
                                    <span><?php echo $value['Title']; ?></span>
                                </a>
                            </li>
            <?php
                        }
                    }
                endforeach;
            ?>
          <?php
          if($this->common->admin_permission('Dashboard_View_Active', 'Dashboard', '', TRUE) || $this->common->admin_permission('Dashboard_View_Archived', 'Dashboard', '', TRUE))
         
          ?>
    </ul>
<?php

?>
  </div>
</div>
<?php

?>
