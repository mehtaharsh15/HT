
<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');$this->load->view('admin/header');
global $asset; 
?>

<div id="content" class="span12 section-body">
  <?php if ($this->session->flashdata('notification')): ?>
  <div class="alert alert-success"> <a class="close" data-dismiss="alert" href="#">×</a>
    <?php echo $this->session->flashdata('notification');?> </div>
  <?php endif; ?>
  
   
  <div id="section-body" class="tabbable"> <!-- Only required for left/right tabs -->

    <ul class="nav nav-tabs">
      <li class="active"><a href="#tab1" data-toggle="tab">Customer Listing</a></li>
      
    </ul>
    <div class="tab-content">
      <div class="tab-pane active" id="tab1">
        <div class="row-fluid">
          <!--Tabs2-->
          <div class="span12">
            <div id="accordion1" class="accordion">
              <div class="accordion-partner">
                <div class="accordion-heading"> <a class="accordion-toggle" data-toggle="collapse" href="#notification" data-original-title="">
				<i class="icon-user icon-white"></i> <span class="divider-vertical"></span>Customer<i class="icon-chevron-down icon-white pull-right"></i> </a> </div>
                  <div id="notification" class="accordion-body collapse in">
					  <div class="accordion-inner paddind">
						<form name="frmPartnerList" method="post" action="<?php echo base_url();?>admin/customer">
						<table id="table" class="table table-bordered table-striped pull-left" cellspacing="0" width="100%">
						
						<thead>
						<tr>
						  <?php foreach ($this->customer->column_headers as $key => $val): ?>
								<th width="<?php echo $val;?>"><?php echo $key;?></th>
								<?php endforeach;?>
								<th width="5%">Action</th>
							   
							</tr>
						  </thead>
						  <tbody>
						  
						  </tbody>
						  <tfoot>
						  <tr>
						<?php foreach ($this->customer->column_headers as $key => $val): ?>
                            <th><?php echo $key;?></th>
                            <?php endforeach;?>
                            <th>Action</th>
                    
					  </tr>
					  </tfoot>
					  </table>
					  <input type="hidden" name="action"/>
                      <input type="hidden" name="customerid"/>
                      </form>
                      <br/>
                     </div>
                   </div>
                </div>
             </div>
           </div>
         </div>
       </div>
     </div>
   </div>
</div>
    
<script type="text/javascript" charset="utf-8">
 
var table;
 
$(document).ready(function() {
 
    //datatables
    table = $('#table').DataTable({ 
 
        "processing": true, //Feature control the processing indicator.
        "serverSide": true, //Feature control DataTables' server-side processing mode.
       
        // Load data for the table's content from an Ajax source
        "ajax": {
              
			"url": "<?php echo base_url().'index.php/admin/Customer/customer_ajax_list/'; ?>",
			//"url": "<?php echo site_url('Test/ajax_list')?>",
            "type": "POST"
        },
 
 
    });
 
});


function customer_delete(field_value,status_value){
    $.ajax({
        url:"<?php echo base_url().'index.php/admin/customer/changeactivestatus/1/';?>",
        type:"POST",
		dataType: "JSON",
        beforeSend: function(){
            var conform=confirm("Are you sure to delete this customer?");
            if(!conform){
                return false;
            }
        },
        data:{customer_id:field_value, customer_active:status_value},
        success:function(data){
          //  alert(data);
				
             reload_table();
			
        }
    });
}

function reload_table()
{
    table.ajax.reload(null,false); //reload datatable ajax 
}



</script>
 
<?php $this->load->view('admin/footer');?>