<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
$this->load->view('admin/header');
global $asset;
?>
<div id="content" class="span12 section-body">
  <?php if ($this->session->flashdata('notification')): ?>
  <div class="alert alert-success"> <a class="close" data-dismiss="alert" href="#">×</a>
    <?php echo $this->session->flashdata('notification');?> </div>
  <?php endif; ?>
  <div id="section-body" class="tabbable"> <!-- Only required for left/right tabs -->
    <ul class="nav nav-tabs">
      <li class="active"><a href="#tab1" data-toggle="tab">User Listing</a></li>
    <?php
        if($this->common->admin_permission('Users_Add','Manage_Users','Users',TRUE))
        {
    ?>
      <li><a href="<?php echo base_url()?>admin/users/insert" >Add New User</a></li>
    <?php
        }
    ?>
    </ul>
    <div class="tab-content">
      <div class="tab-pane active" id="tab1">
        <div class="row-fluid"> 
          <!--Tabs2-->
          <div class="span12">
            <div id="accordion1" class="accordion">
              <div class="accordion-group">
                <div class="accordion-heading"> <a class="accordion-toggle" data-toggle="collapse" href="#notification" data-original-title=""> <i class="icon-user icon-white"></i> <span class="divider-vertical"></span>User Listing<i class="icon-chevron-down icon-white pull-right"></i> </a> </div>
                <div id="notification" class="accordion-body collapse in">
                  <div class="accordion-inner paddind">
                    <form name="frmuserlist" method="post" action="<?php echo base_url()?>admin/users">
                      <table class="table table-bordered table-striped pull-left" id="example">
                        <thead>
                          <tr>
                            <!--th align="left" width="5%"><input type="checkbox" onclick="CheckUncheckAll();" title="Select or unselect all records" name="toggleAll"/></th-->
                            <?php foreach ($this->users->column_headers as $key => $val): ?>
                            <th width="<?php echo $val ?>"><?php echo $key?></th>
                            <?php endforeach;?>
                            <th width="15%">Action</th>
                          </tr>
                        </thead>
                        <tbody>
                          <?php
                          /*echo "<pre>";
                          print_r($rsClients);*/
                          if($users_count == 0): ?>
                          <tr>
                            <td colspan="5" align="center">No users found.</td>
                          </tr>
                          <?php else: ?>
                          <?php foreach($users_entry as $userentry):
                                //if ($this->user->id == $userentry['user_id'] || $this->user->user_group_id == 1):
                                if ($this->user->id == $userentry['user_id'] || $this->user->user_group_id == 1 || $this->user->user_group_id == 2):
                            ?>
                          <tr class="delete-<?php echo $userentry['user_id'];?>">
                            <!--td><?php if($userentry['user_id']!=1):?><input type="checkbox" name="users_list[]" id="users_list[]" value="<?php echo $userentry['user_id'];?>"><?php endif;?></td-->
                            <td><?php echo $userentry['user_name'];?></td>
                            <td><?php echo $userentry['user_group_name'];?></td>
                            <td><?php echo $userentry['user_firstname'],"&nbsp",$userentry['user_lastname'];?></td>
                            <td>
                                <?php 
                                    //echo $userentry['user_email'];
                                    echo '<a href="mailto:'.$userentry['user_email'].'" target="_top">'.$userentry['user_email'].'</a>';
                                ?>
                            </td>
                            <!--<td><?php echo $userentry['user_allowed_practice_id']?$rsPractice[$userentry['user_allowed_practice_id']]:"All Practices";;?></td>
                            <td><?php echo $userentry['user_allowed_group_id']?$rsGroup[$userentry['user_allowed_group_id']]:"All Groups";?></td>
                            <td><?php echo $userentry['user_allowed_physician_id']?$rsPhysician[$userentry['user_allowed_physician_id']]:"All Physicians";?></td>-->
                            <td><?php echo $userentry['user_client_id']?$rsClients[$userentry['user_client_id']]:"All Clients";?></td>
                            <td align="center" width="15%">
                                <div>
                                    <input type="hidden" name="user_id" value="<?php echo $userentry['user_id'];?>">
                                    <a data-toggle="modal" href="#myModal<?php echo $userentry['user_id'];?>" class="tooltip-top btn" data-original-title="View"  > <i class="icon-eye-open" ></i></a>&nbsp;
                                    <?php //if($this->user->id == 1 || $this->user->user_group_id == 1 || $this->user->user_group_id == 2)
                                    if($this->user->id == 1 || (($this->user->user_group_id == 1 || $this->user->user_group_id == 2) && $userentry['user_id'] != 1))
                                    {
                                    ?>
                                        <a data-original-title="Edit" href="<?php echo base_url()?>admin/users/edit/<?php echo $userentry['user_id']?>" class="tooltip-top btn"><i class="icon-edit" ></i></a>&nbsp;
                                        <?php
                                        if($userentry['user_id']!=1 && $userentry['user_id'] != $this->user->id)
                                        {
                                        ?>
                                            <a class="tooltip-top btn" data-original-title="Delete" onClick="fun_delete('<?php echo $userentry['user_id']; ?>','<?php echo $userentry['user_active']?0:$userentry['user_active'];?>');"><i class="icon-trash" style="cursor: pointer" ></i></a>
                                    <?php
                                        }
                                    }
                                    else
                                    {
                                        if($userentry['user_id'] == $this->user->id)
                                        {
                                        ?>
                                            <a data-original-title="Edit" href="<?php echo base_url()?>admin/users/edit/<?php echo $userentry['user_id']?>" class="tooltip-top btn"><i class="icon-edit" ></i></a>&nbsp;
                                        <?php
                                        }
                                    }
                                    /*else
                                    {
                                        if($this->common->admin_permission('Manage_Users_Edit','Manage_Users','Users',TRUE))
                                        {
                                            if($userentry['user_id']!=1 && $userentry['user_group_id'] != 1)
                                            {
                                        ?>
                                                <a data-original-title="Edit" href="<?php echo base_url()?>admin/users/edit/<?php echo $userentry['user_id']?>" class="tooltip-top btn"><i class="icon-edit" ></i></a>&nbsp;
                                        <?php
                                            }
                                        }
                                        if($this->common->admin_permission('Manage_Users_Delete','Manage_Users','Users',TRUE))
                                        {
                                            if($userentry['user_id']!=1 && $userentry['user_group_id'] != 1 && $userentry['user_id'] != $this->user->id)
                                            {
                                        ?>
                                                <a class="tooltip-top btn" data-original-title="Delete" onClick="fun_delete('<?php echo $userentry['user_id']; ?>','<?php echo $userentry['user_active']?0:$userentry['user_active'];?>');"><i class="icon-trash" style="cursor: pointer" ></i></a>
                                        <?php
                                            }
                                        }
                                     }*/
                                    ?>
                                </div>
                              <div id="myModal<?php echo $userentry['user_id'];?>" class="modal hide fade">
                                <div class="modal-header">
                                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                                  <h3>User</h3>
                                </div>
                                <div class="modal-body" id="result">
                                  <div id="accordion2" class="accordion">
                                    <div class="accordion-heading">
                                        <a href="#widget-tabs<?php echo $userentry['user_id'];?>" data-toggle="collapse" class="accordion-toggle in"> <i class="icon-user icon-white"></i> <span class="divider-vertical"></span> <?php echo $userentry['user_firstname'],"&nbsp;",$userentry['user_lastname'];?><i class="icon-chevron-down icon-white pull-right"></i></a>
                                    </div>
                                    <div class="accordion-body collapse in" id="widget-tabs<?php echo $userentry['user_id'];?>">
                                      <div class="accordion-inner">
                                        <table class="table table-striped" width="90%">
                                          <tbody>
                                            <tr>
                                              <td><b>Username:</b></td>
                                              <td><?php echo $userentry['user_name'];?></td>
                                            </tr>
                                            <tr>
                                              <td><b>User Group:</b></td>
                                              <td><?php echo $userentry['user_group_name'];?></td>
                                            </tr>
                                            <!--<tr>
                                              <td><b>Allowed Practice:</b></td>
                                              <td><?php echo $userentry['user_allowed_practice_id']?$rsPractice[$userentry['user_allowed_practice_id']]:"All Practices";?></td>
                                            </tr>
                                            <tr>
                                              <td><b>Allowed Group:</b></td>
                                              <td><?php echo $userentry['user_allowed_group_id']?$rsGroup[$userentry['user_allowed_group_id']]:"All Groups";?></td>
                                            </tr>
                                            <tr>
                                              <td><b>Allowed Physician:</b></td>
                                              <td><?php echo $userentry['user_allowed_physician_id']?$rsPhysician[$userentry['user_allowed_physician_id']]:"All Physicians";?></td>
                                            </tr>-->
                                            <tr>
                                              <td><b>Client:</b></td>
                                              <td><?php echo $userentry['user_client_id']?$rsClients[$userentry['user_client_id']]:"All Clients";?></td>
                                            </tr>
                                            <tr>
                                              <td><b>First Name:</b></td>
                                              <td><?php echo $userentry['user_firstname'];?></td>
                                            </tr>
                                            <tr>
                                              <td><b>Last Name:</b></td>
                                              <td><?php echo $userentry['user_lastname'];?></td>
                                            </tr>
                                            <tr>
                                              <td><b>Email:</b></td>
                                              <td>
                                                  <?php 
                                                      //echo $userentry['user_email'];
                                                        echo '<a href="mailto:'.$userentry['user_email'].'" target="_top">'.$userentry['user_email'].'</a>';
                                                  ?>
                                              </td>
                                            </tr>
                                            <tr>
                                              <td><b>Contact No:</b></td>
                                              <td><?php echo $userentry['user_contact'];?></td>
                                            </tr>
                                            <tr>
                                              <td><b>Status:</b></td>
                                              <td><?php echo $asset['SD_Active'][$userentry['user_active']];?></td>
                                            </tr>
                                          </tbody>
                                        </table>
                                      </div>
                                    </div>
                                  </div>
                                  <div class="modal-footer">
                                    <?php if($this->user->id == 1 || (($userentry['user_id'] == $this->user->id || $this->user->user_group_id == 1 || $this->user->user_group_id == 2) && $userentry['user_id'] != 1))
                                    {
                                    ?>
                                            <a href="<?php echo base_url()?>admin/users/edit/<?php echo $userentry['user_id']?>" class="btn">Edit</a>
                                    <?php
                                    }
                                    /*else
                                    {
                                        if($userentry['user_id'] == $this->user->id)
                                        {
                                        ?>
                                            <a href="<?php echo base_url()?>admin/users/edit/<?php echo $userentry['user_id']?>" class="btn">Edit</a>
                                        <?php
                                        }
                                    }*/
                                    ?>
                                    <?php
                                        /*if($this->common->admin_permission('Manage_Users_Edit','Manage_Users','Users',TRUE))
                                        {
                                    ?>
                                        <?php if($userentry['user_id']!=1 && $userentry['user_group_id'] != 1 && $userentry['user_id'] != $this->user->id):?>
                                                <a href="<?php echo base_url()?>admin/users/edit/<?php echo $userentry['user_id']?>" class="btn">Edit</a>
                                        <?php endif;
                                        }*/
                                    ?>
                                  <a href="#" class="btn" data-dismiss="modal" >Close</a> </div>
                                </div>
                              </div></td>
                          </tr>
                          <?php endif; endforeach;
                          endif; ?>
                        </tbody>
                        <tfoot>
                          <tr>
                            <!--th align="left"><input type="checkbox" onclick="CheckUncheckAll();" title="Select or unselect all records" name="toggleAll"/></th-->
                            <?php foreach ($this->users->column_headers as $key => $val): ?>
                            <th><?php echo $key?></th>
                            <?php endforeach;?>
                            <th>Action</th>
                          </tr>
                          <!--tr>
                            <td colspan="8">&nbsp;&nbsp;&nbsp;&nbsp;<img src="<?php echo base_url().$this->config->item('image_path');?>admin/arrow_ltr.png" />&nbsp;With selected:&nbsp;<i class="icon-trash"  title="Delete" style="cursor: pointer" onClick="return confirmDeleteUserlist(document.frmuserlist)"></i></td>
                          </tr-->
                        </tfoot>
                      </table>
                      <input type="hidden" name="action"/>
                      <input type="hidden" name="userid"/>
                      <input type="hidden" name="publish"/>
                    </form>
                    <br />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<style type="text/css">
.control-group.error td{color:#b94a48;}
.control-group.success td{color:#468847;}
.control-group.success label.valid 
{
    background: url('../img/valid.png') center center no-repeat;
    display: inline-block;
    text-indent: 45px;
}
</style>
<script type="text/javascript" charset="utf-8">
function fun_delete(field_value, status_value){
    $.ajax({
        url:"<?php echo base_url().'index.php/admin/users/changeactivestatus/1/';?>",
        type:"POST",
        beforeSend: function(){
            var conform=confirm("Are you sure to delete this user?");
            if(!conform){
                    return false;
            }
        },
        data:{user_id:field_value, user_active:status_value},
        success:function(data){
                    $('.delete-'+field_value).fadeOut('slow');
        }
    });
}
</script>
<?php $this->load->view('admin/footer');?>