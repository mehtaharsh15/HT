<?php if (!defined('BASEPATH')) exit('No direct script access allowed'); $this->load->view('admin/header');
global $asset;
?>
<!--<link href="<?php echo base_url() . $this->config->item('stylesheet_path'); ?>css.css" media="screen" rel="stylesheet" type="text/css" />-->
<div id="content" class="span12 section-body">
	<?php if (isset($usergroupmsg) && !empty($usergroupmsg)): ?>
    <?php //if ($this->session->flashdata('notification')): ?>
        <div class="alert alert-error"> 
        	<a class="close" data-dismiss="alert" href="#">×</a>
            <?php //echo $this->session->flashdata('notification'); ?>
            <?php echo $usergroupmsg;?> </div>
    <?php endif; ?>
    <div id="section-body" class="tabbable"> <!-- Only required for left/right tabs -->
        <ul class="nav nav-tabs">
            <li><a href="<?php echo base_url() ?>admin/usergroup/index" >User Group Manager</a></li>
            <li <?php if ($Action == 'Add'): ?> class="active"<?php endif; ?>><a href="<?php echo base_url() ?>admin/usergroup/insert">Add New User Group</a></li>
            <?php if ($Action == 'Edit'): ?>
                <li class="active">
                    <a href="#tab1" data-toggle="tab">
                        <?php echo "Edit User Group"; ?>
                    </a>
                </li>
            <?php endif; ?>
        </ul>
        <div class="tab-content">
            <div class="tab-pane active" id="tab1">
                <div class="row-fluid"> 
                    <!--Tabs2-->
                    <div class="span12">
                        <div id="accordion1" class="accordion">
                            <div class="accordion-group">
                                <div class="accordion-heading">
                                    <a class="accordion-toggle" data-toggle="collapse" href="#notification" data-original-title=""><i class="icon-th icon-white"></i><span class="divider-vertical"></span>
                                        <?php
                                        if ($Action == 'Edit'): echo "Edit User Group";
                                        else: echo "Add New User Group";
                                        endif;
                                        ?>
                                        <i class="icon-chevron-down icon-white pull-right"></i>
                                    </a>
                                </div>
                                <div id="notification" class="accordion-body collapse in">
                                    <div class="accordion-inner paddind">
                                        <div class="mandatory-note">
                                            Fields marked with * are mandatory.
                                            <br/>
                                        </div>
                                        <form name="frmusergroup" id="form" action="<?php if ($Action == 'Add'): ?><?php echo base_url(); ?>admin/usergroup/insert<?php else: ?><?php echo base_url(); ?>admin/usergroup/edit<?php endif; ?>" method="post" enctype="multipart/form-data">
                                            <table class="table table-bordered table-striped pull-left">
                                                <tbody>
                                                    <tr>
                                                        <?php
                                                        if ($usergroup_edit_entry['user_group_name'] == 'Administrator')
                                                        {
                                                            $chk = 'disabled="disabled"';
                                                        }
                                                        else
                                                        {
                                                            $chk = '';
                                                        }
                                                        ?>
                                                        <td><span class="fieldlabel"><span class="mandatory-star">*</span>Group Name:</span></td>
                                                        <td>
                                                            <?php if ($usergroup_edit_entry['user_group_name'] == 'Administrator'): ?>
                                                                <?php echo $usergroup_edit_entry['user_group_name']; ?>
                                                                <input type="hidden" id="usergroup_name" name="usergroup_name" size="42" value="<?php echo $usergroup_edit_entry['user_group_name']; ?>">
                                                            <?php else: ?>
                                                                <input type="text" id="usergroup_name" name="usergroup_name" size="42" class="required" value="<?php
                                                            if ($group_duplicate['user_group_name']): echo $group_duplicate['user_group_name'];
                                                            else: echo $usergroup_edit_entry['user_group_name'];
                                                            endif;
                                                                ?>" required <?php if ($usergroup_edit_entry['user_group_default']) echo "readonly"; ?>>
                                                                   <?php endif; ?>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td><span class="fieldlabel">Management:</span></td>
                                                        <td><table class="table table-striped table-bordered table-condensed">
                                                                <?php
                                                                //echo $usergroup_edit_entry['user_group_privileges'];
                                                                //echo "<pre>";
                                                                //print_r(json_decode($usergroup_edit_entry['user_group_privileges']));
                                                                //print_r($usergroup_edit_entry['user_group_privileges']);
                                                                //echo "<pre>";
                                                                //die;
                                                                $obj = json_decode($usergroup_edit_entry['user_group_privileges']);
                                                                //$group_obj = json_decode($group_duplicate['user_group_privileges']);
                                                                /*echo "<pre>";
                                                                print_r($obj);
                                                                echo "<pre>";*/
                                                                ?>
                                                                <tr>
                                                                    <th width="30%">Module</th>
                                                                    <th>Actions</th>
                                                                </tr>
                                                                    <?php
                                                                        foreach ($asset['SD_UserGroup_Permissions'] as $key => $value):
                                                                    ?>
                                                                    <tr>
                                                                        <td width="30%">
                                                                            <label class="checkbox">
                                                                                <input type="checkbox" id="user_group_privileges[<?php echo $key; ?>][module]" name="user_group_privileges[<?php echo $key; ?>][module]" size="42" value="<?php echo $key; ?>" <?php if ($obj->user_group_privileges->$key) echo "checked"; ?> onclick="Check_UncheckClick(this,'<?php echo $key; ?>','','',<?php echo count($value)-1; ?>);"/>
                                                                                <?php echo $value['Title']; ?>
                                                                            </label>
                                                                        </td>
                                                                        <td>
                                                                            <?php
                                                                            if (is_array($value/*['Submenu']*/) && $key != 'Submenu') {
                                                                                foreach ($value/*['Submenu']*/ as $k => $v) {
                                                                                    if (is_array($v/*['Submenu']*/) && $k != 'Submenu') {
                                                                                        ?>
                                                                                    </td>
                                                                                </tr>
                                                                                <tr>
                                                                                    <td>
                                                                                        <label class="checkbox ">
                                                                                            <input type="checkbox" id="user_group_privileges[<?php echo $key; ?>][<?php echo $k; ?>][module]" name="user_group_privileges[<?php echo $key; ?>][<?php echo $k; ?>][module]" size="42" value="<?php echo $k; ?>" <?php if ($obj->user_group_privileges->$key->$k) echo "checked"; ?> onclick="Check_UncheckClick(this,'<?php echo $k; ?>','<?php echo $key; ?>','',<?php echo count($v)-1; ?>);"/>
                                                                                            &nbsp;&nbsp;&nbsp;&nbsp;|---
                                                                                            <?php echo $v['Title']; ?>
                                                                                        </label>
                                                                                    </td>
                                                                                    <td>
                                                                                        <?php
                                                                                        foreach ($v/*['Submenu']*/ as $k1 => $v1) {
                                                                                            if (is_array($v1/*['Submenu']*/) && $k1 != 'Submenu') {
                                                                                                ?>
                                                                                            </td>
                                                                                        </tr>
                                                                                        <tr>
                                                                                            <td>
                                                                                                <label class="checkbox">
                                                                                                    <input type="checkbox" id="user_group_privileges[<?php echo $key; ?>][<?php echo $k; ?>][<?php echo $k1; ?>]" name="user_group_privileges[<?php echo $key; ?>][<?php echo $k; ?>][<?php echo $k1; ?>]" size="42" value="<?php echo $k1; ?>" <?php if ($obj->user_group_privileges->$key->$k->$k1) echo "checked"; ?> onclick="Check_UncheckClick(this,'<?php echo $k1; ?>','<?php echo $k; ?>','<?php echo $key; ?>',<?php echo count($value)-1; ?>);"/>
                                                                                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|---
                                                                                                    <?php echo $k1; ?>
                                                                                                </label>
                                                                                            </td>
                                                                                            <td>
                                                                                                <?php
                                                                                                foreach ($v1/*['Submenu']*/ as $k2 => $v2) {
                                                                                                    if ($k2 != 'Title' && $k2 != 'Link' && $k2 != 'Icon' && $key != 'Submenu') {
                                                                                                        ?>
                                                                                                        <label class="checkbox permissionRadio">
                                                                                                            <input type="checkbox" id="user_group_privileges[<?php echo $key; ?>][<?php echo $k; ?>][<?php echo $k1; ?>][permissions][<?php echo $k2; ?>]" name="user_group_privileges[<?php echo $key; ?>][<?php echo $k; ?>][<?php echo $k1; ?>][permissions][<?php echo $k2; ?>]" size="42" value="<?php echo $k2; ?>" <?php if ($obj->user_group_privileges->$key->$k->$k1->permissions->$k2) echo "checked"; ?>/>
                                                                                                            <?php echo $v2;/*print_r($v2);*/ ?>
                                                                                                        </label>
                                                                                                        <?php
                                                                                                    }
                                                                                                }
                                                                                            }
                                                                                            elseif ($k1 != 'Title' && $k1 != 'Link' && $k1 != 'Icon' && $key != 'Submenu') {
                                                                                                ?>
                                                                                                <label class="checkbox permissionRadio">
                                                                                                    <input type="checkbox" id="user_group_privileges[<?php echo $key; ?>][<?php echo $k; ?>][permissions][<?php echo $k1; ?>]" name="user_group_privileges[<?php echo $key; ?>][<?php echo $k; ?>][permissions][<?php echo $k1; ?>]" size="42" value="<?php echo $v1; ?>" <?php if ($obj->user_group_privileges->$key->$k->permissions->$k1) echo "checked"; ?> />
                                                                                                    <?php echo $v1;/*print_r($v1);*/ ?>
                                                                                                </label>
                                                                                                <?php
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                    elseif ($k != 'Title' && $k != 'Link' && $k != 'Icon' && $k != 'Submenu') {
                                                                                        ?>
                                                                                        <label class="checkbox permissionRadio">
                                                                                            <input type="checkbox" id="user_group_privileges[<?php echo $key; ?>][permissions][<?php echo $k; ?>]" name="user_group_privileges[<?php echo $key; ?>][permissions][<?php echo $k; ?>]" size="42" value="<?php echo $v; ?>" <?php if ($obj->user_group_privileges->$key->permissions->$k) echo "checked"; ?>>
                                                                                            <?php echo $v;/*print_r($v);*/ ?>
                                                                                        </label>
                                                                                        <?php
                                                                                    }
                                                                                }
                                                                            }
                                                                            elseif ($key != 'Title' && $key != 'Link' && $key != 'Icon' && $key != 'Submenu') {
                                                                                ?>
                                                                                <label class="checkbox permissionRadio">
                                                                                    <input type="checkbox" id="user_group_privileges[<?php echo $key; ?>][permissions]" name="user_group_privileges[<?php echo $key; ?>][permissions]" size="42" value="<?php echo $value; ?>" <?php if ($obj->user_group_privileges->$key) echo "checked"; ?> />
                                                                                    <?php echo $value;/*print_r($value);*/ ?>
                                                                                </label>
                                                                                <?php
                                                                            }
                                                                            ?>
                                                                        </td>
                                                                    </tr>
                                                                <?php endforeach; ?>
                                                            </table></td>
                                                    </tr>
                                                    <tr>
                                                        <td><span class="fieldlabel"><span class="mandatory-star">*</span>Status:</span></td>
                                                        <td>
                                                            <?php if($usergroup_edit_entry['user_group_default'])
                                                            {
                                                            ?>
                                                                <input type="hidden" id="user_group_active" name="user_group_active" size="42" value="<?php echo $usergroup_edit_entry['user_group_active']; ?>">
                                                            <?php
                                                            }
                                                            ?>
                                                            <select id="user_group_active" name="user_group_active" <?php if($usergroup_edit_entry['user_group_default']) echo 'disabled';?>>
                                                                <?php foreach($asset['SD_Active'] as $key => $val): ?>
                                                                <?php if(isset($usergroup_edit_entry['user_group_active']))
                                                                    {
                                                                        if($key == $usergroup_edit_entry['user_group_active'])
                                                                        {
                                                                ?>
                                                                            <option value="<?php echo $key?>" selected="selected"><?php echo $val?></option>
                                                                <?php 	}
                                                                        else
                                                                        {
                                                                ?>
                                                                            <option value="<?php echo $key?>"><?php echo $val?></option>
                                                                <?php 
                                                                        }
                                                                    }
                                                                    else
                                                                    {
                                                                        if($key == 1)
                                                                        {
                                                                ?>
                                                                            <option value="<?php echo $key?>" selected="selected"><?php echo $val?></option>
                                                                <?php 	  }
                                                                        else
                                                                        {
                                                                ?>
                                                                            <option value="<?php echo $key?>"><?php echo $val?></option>
                                                                <?php 
                                                                        }
                                                                    }
                                                                ?>
                                                                <?php endforeach; ?>
                                                            </select>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp;</td>
                                                        <td class="stdLabel" style="text-align:left;">
                                                            <input type="submit" name="submit" class="btn btn-primary" value="<?php if ($Action == 'Add'): ?>Save<?php else: ?>Update<?php endif; ?>" />
                                                            &nbsp;&nbsp;
                                                            <input type="button" name="cancel" class="btn" value="Cancel" onclick="location.href='<?php echo base_url(); ?>admin/usergroup/index/'" />
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                            <?php if ($Action == 'Edit'): ?>
                                                <input type="hidden" name="usergroup_id" id="usergroup_id" value="<?php echo $usergroup_edit_entry['user_group_id']; ?>" />
                                            <?php endif; ?>
                                        </form>
                                        <br />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $this->load->view('admin/footer'); ?>