<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');$this->load->view('admin/header');
global $asset;
?>
<!--<link href="<?php echo base_url().$this->config->item('stylesheet_path');?>css.css" media="screen" rel="stylesheet" type="text/css" />-->
<div id="content" class="span12 section-body">
	<?php if (isset($faqMsg) && !empty($faqMsg)): ?>
      <div class="alert alert-error">
          <a class="close" data-dismiss="alert" href="#">×</a>
          <?php //echo $this->session->flashdata('notification');?> <?php echo $faqMsg;?>
      </div>
    <?php endif; ?>
  <div id="section-body" class="tabbable"> <!-- Only required for left/right tabs -->
    <ul class="nav nav-tabs">
      <li><a href="<?php echo base_url()?>admin/faq/index" >FAQ Listing</a></li>
      <li  <?php if($this->uri->segment(3) == 'insert'):?>class="active"<?php  endif;?>
><a href="<?php echo base_url()?>admin/faq/insert" >Add New FAQ</a></li>
      <?php if($this->uri->segment(3) == 'edit'):?>
      <li class="active"><a href="#tab1" data-toggle="tab" >Edit FAQ</a></li>
      <?php endif;?>
    </ul>
    <div class="tab-content">
      <div class="tab-pane active" id="tab1">
        <div class="row-fluid"> 
          <!--Tabs2-->
          <div class="span12">
            <div id="accordion1" class="accordion">
              <div class="accordion-partner">
                <div class="accordion-heading"> <a class="accordion-toggle" data-toggle="collapse" href="#notification" data-original-title=""> <i class="icon-user icon-white"></i> <span class="divider-vertical"></span>
                  <?php if($this->uri->segment(3) == 'edit'): echo "Edit FAQ"; else: echo "Add New FAQ"; endif;?>
                  <i class="icon-chevron-down icon-white pull-right"></i> </a> </div>
                <div id="notification" class="accordion-body collapse in">
                  <div class="accordion-inner paddind">
                    <div class="mandatory-note">
                      Fields marked with * are mandatory.
                      <br/>
                    </div>
                    <form name="frmpartner" id="form" action="<?php if($this->uri->segment(3) == 'insert'): ?><?php echo base_url();?>admin/faq/insert<?php else: ?><?php echo base_url();?>admin/faq/edit<?php endif; ?>" method="post" enctype="multipart/form-data">
                      <table class="table table-bordered table-striped pull-left">
                        <tbody>
                          <tr class="control-partner">
                            <td class="control-label"><span class="fieldlabel"><span class="mandatory-star">*</span>FAQ Question:</span></td>
                            <td class="controls">
                              <input type="text" class="required" required maxlength="150" name="faq_question" id="faq_question" 
							  value="<?php echo $faq_edit_entry['faq_question'];?>" />
                            </td>
                          </tr>
                          <tr class="control-partner">
                            <td class="control-label"><span class="fieldlabel"><span class="mandatory-star">*</span>FAQ Answer:</span></td>
                            <td class="controls">
							<textarea name="faq_answer" class="required" required id="faq_answer">
							 <?php echo $faq_edit_entry['faq_answer'];?>
							</textarea>
                             <!--  <input type="text" class="required" required maxlength="255" name="faq_answer" id="faq_answer"
							 value="<?php //echo $faq_edit_entry['faq_answer'];?>" /> -->
                            </td>
                          </tr>
                        
                        
                        <?php
                        if($this->uri->segment(3) != 'edit')
                        {
                        ?>
                          <tr>
                            <td><span class="fieldlabel"><span class="mandatory-star">*</span>FAQ Status:</span></td>
                            <td>
                              <select id="faq_active" name="faq_active">
                                <?php foreach($asset['SD_Active'] as $key => $val): ?>
                                <?php if(isset($faq_edit_entry['faq_active']))
									  {
										  if($key == $faq_edit_entry['faq_active'])
										  {
								?>
	                                        <option value="<?php echo $key?>" selected="selected"><?php echo $val?></option>
			                    <?php 	  }
										  else
										  {
								?>
			                                <option value="<?php echo $key?>"><?php echo $val?></option>
                                <?php 
										  }
									  }
									  else
									  {
										  if($key == 1)
										  {
								?>
	                                        <option value="<?php echo $key?>" selected="selected"><?php echo $val?></option>
			                    <?php 	  }
										  else
										  {
								?>
			                                <option value="<?php echo $key?>"><?php echo $val?></option>
                                <?php 
										  }
									  }
								?>
                                <?php endforeach; ?>
                              </select>
                            </td>
                          </tr>
                        <?php
                        }
                        ?>
                          <tr>
                          	<td>&nbsp;</td>
                            <td class="stdLabel" style="text-align:left;">
							<input type="submit" name="submit" class="btn btn-primary" 
							value="<?php if($this->uri->segment(3) == 'insert'): ?>Save<?php else: ?>Update<?php endif; ?>" />
                              &nbsp;&nbsp;
                              <input type="button" name="cancel" class="btn" value="Cancel"  onclick="location.href='<?php echo base_url();?>admin/faq/index/'"/></td>
                          </tr>
                        </tbody>
                      </table>
                      <input type="hidden" name="faq_id" id="faq_id" value="<?php echo $faq_edit_entry['faq_id'];?>" />
                    </form>
                    <br/>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<?php $this->load->view('admin/footer');?>
