<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>
<head>


<script type="text/javascript">
  window.print();
</script>
<style type="text/css">
@media print {
    #qrcodePrint {
        display :  none;
    }
}
.notbold{
    font-weight:normal
}​
</style>
</head>
    
 <div id="QRModal<?php echo $machineEntry['machine_id'];?>" class="modal hide fade">
     <div class="modal-header">
           <!-- <button type="button" class="close" data-dismiss="modal">&times;</button>-->
        <h3 align="center"> <img src="<?php echo base_url().$this->config->item('image_path');?>admin/share.png" height="20px" width="20px" 
		style="padding-top:15px;" />
               To Pay user name</h3>
               <h4 align="center" class='notbold' >Scan this Machine Code</h4>
     </div>
								
          <div class="modal-body" id="result">
              <div id="accordion2" class="accordion">
              <div class="accordion-heading"><a href="#widget-tabs<?php echo $machineEntry['machine_id'];?>" data-toggle="collapse" class="accordion-toggle in"><i class="icon-user icon-white"></i><span class="divider-vertical"></span><?php echo $machineEntry['machine_name'];?><i class="icon-chevron-down icon-white pull-right"></i></a></div>
                 <div class="accordion-body collapse in" id="widget-tabs<?php echo $machineEntry['machine_id'];?>">
                     <div class="accordion-inner">
                       <table class="table table-striped" width="90%">
						<tbody>
							<tr>
								<center><a href="<?php echo base_url()?>admin/machine/machineprint_qr/<?php echo $machine_id?>"  rel="group"  
								  onclick="window.print();" id="qrcodePrint"></a>
								 </center>
								<center><img src="<?php echo $qr_code;?>" align="middle" /></center>
						        <h4  align="center" class='notbold' >Or enter Machine Code.</b></span></h4>
                                <h4  align="center"><span class="qrcode"><b><?php echo $machine_code;?></b></span></h4>
                            </tr>
                         </tbody>
                       </table>
                     </div>
					</div>
				</div>
			<div class="modal-footer">
		</div>
      </div>
   </div>                      
							  
							  
	