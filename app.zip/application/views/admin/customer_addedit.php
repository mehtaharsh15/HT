
<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');$this->load->view('admin/header');
global $asset;
?>
<!--<link href="<?php echo base_url().$this->config->item('stylesheet_path');?>css.css" media="screen" rel="stylesheet" type="text/css" />-->
<div id="content" class="span12 section-body">
	<?php if (isset($customerMsg) && !empty($customerMsg)): ?>
      <div class="alert alert-error">
          <a class="close" data-dismiss="alert" href="#">×</a>
          <?php //echo $this->session->flashdata('notification');?> <?php echo $customerMsg;?>
      </div>
    <?php endif; ?>
  <div id="section-body" class="tabbable"> <!-- Only required for left/right tabs -->
    <ul class="nav nav-tabs">
      <li><a href="<?php echo base_url()?>admin/customer/index" >Customer Listing</a></li>
      <li  <?php if($this->uri->segment(3) == 'insert'):?>class="active"<?php  endif;?>>
	 
      <?php if($this->uri->segment(3) == 'edit'):?>
      <li class="active"><a href="#tab1" data-toggle="tab" >Edit Customer</a></li>
      <?php endif;?>
    </ul>
    <div class="tab-content">
      <div class="tab-pane active" id="tab1">
        <div class="row-fluid"> 
          <!--Tabs2-->
          <div class="span12">
            <div id="accordion1" class="accordion">
              <div class="accordion-partner">
                <div class="accordion-heading"> <a class="accordion-toggle" data-toggle="collapse" href="#notification" data-original-title=""> <i class="icon-user icon-white"></i> <span class="divider-vertical"></span>
                  <?php if($this->uri->segment(3) == 'edit'): echo "Edit Customer"; else: echo "Add New Customer"; endif;?>
                  <i class="icon-chevron-down icon-white pull-right"></i> </a> </div>
                <div id="notification" class="accordion-body collapse in">
                  <div class="accordion-inner paddind">
                    <div class="mandatory-note">
                      Fields marked with * are mandatory.
                      <br/>
                    </div>
                    <form name="frmcustomer" id="form" action="<?php if($this->uri->segment(3) == 'insert'): ?><?php echo base_url();?>admin/customer/insert<?php else: ?><?php echo base_url();?>admin/customer/edit<?php endif; ?>" method="post" enctype="multipart/form-data">
                      <table class="table table-bordered table-striped pull-left">
                        <tbody>
                          <tr class="control-partner">
                            <td class="control-label"><span class="fieldlabel"><span class="mandatory-star">*</span>First Name:</span></td>
                            <td class="controls">
                              <input type="text" class="required" required maxlength="150" name="first_name" id="first_name" value="<?php echo $customer_edit_entry['customer_firstname'];?>" />
                            </td>
                          </tr>
                          <tr class="control-partner">
                            <td class="control-label"><span class="fieldlabel"><span class="mandatory-star">*</span>Last Name:</span></td>
                            <td class="controls">
                              <input type="text" class="required" required maxlength="15" name="last_name" id="last_name" value="<?php echo $customer_edit_entry['customer_lastname'];?>" />
                            </td>
                          </tr>
                        
                        
                          <tr class="control-partner">
                            <td class="control-label"><span class="fieldlabel"><span class="mandatory-star">*</span>Customer Email:</span></td>
                            <td class="controls"><input type="text" class="required" required maxlength="20" name="email" id="email" value="<?php echo $customer_edit_entry['customer_email']; ?>"></td>
                          </tr>
                        
                          <tr class="control-partner">
                            <td class="control-label"><span class="fieldlabel"><span class="mandatory-star">*</span>Customer Mobile:</span></td>
                            <td class="controls"><input type="text" class="required" required maxlength="20" name="mobile" id="mobile" value="<?php echo $customer_edit_entry['customer_mobile']; ?>"></td>
                          </tr>
                        
                        
                          
                         
                        <?php
                        if($this->uri->segment(3) != 'edit')
                        {
                        ?>
                          <tr>
                            <td><span class="fieldlabel"><span class="mandatory-star">*</span>Customer Status:</span></td>
                            <td>
                              <select id="customer_active" name="customer_active">
                                <?php foreach($asset['SD_Active'] as $key => $val): ?>
                                <?php if(isset($customer_edit_entry['customer_active']))
									  {
										  if($key == $customer_edit_entry['customer_active'])
										  {
								?>
	                                        <option value="<?php echo $key?>" selected="selected"><?php echo $val?></option>
			                    <?php 	  }
										  else
										  {
								?>
			                                <option value="<?php echo $key?>"><?php echo $val?></option>
                                <?php 
										  }
									  }
									  else
									  {
										  if($key == 1)
										  {
								?>
	                                        <option value="<?php echo $key?>" selected="selected"><?php echo $val?></option>
			                    <?php 	  }
										  else
										  {
								?>
			                                <option value="<?php echo $key?>"><?php echo $val?></option>
                                <?php 
										  }
									  }
								?>
                                <?php endforeach; ?>
                              </select>
                            </td>
                          </tr>
                        <?php
                        }
                        ?>
                          <tr>
                          	<td>&nbsp;</td>
                            <td class="stdLabel" style="text-align:left;"><input type="submit" name="submit" class="btn btn-primary" value="<?php if($this->uri->segment(3) == 'insert'): ?>Save<?php else: ?>Update<?php endif; ?>" />
                              &nbsp;&nbsp;
                              <input type="button" name="cancel" class="btn" value="Cancel"  onclick="location.href='<?php echo base_url();?>admin/customer/index/'"/></td>
                          </tr>
                        </tbody>
                      </table>
                      <input type="hidden" name="customer_id" id="customer_id" value="<?php echo $customer_edit_entry['customer_id'];?>" />
                    </form>
                    <br />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript">
/* 
$(function() {
 
  $("form[name='frmcustomer']").validate({
 
    rules: {
       email: {
		 required: true,
        
        email: true
		}
	   },
	    messages: {
		email: "Please enter a valid email address "
		},
		  submitHandler: function(form) {
      form.submit();
    }
  });
});
    */
</script>
<?php $this->load->view('admin/footer');?>
