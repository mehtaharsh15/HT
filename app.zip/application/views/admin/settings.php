<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); $this->load->view('admin/header');?>
<div id="content" class="span12 section-body">
  <?php if ($this->session->flashdata('notification')): ?>
  <div class="alert alert-success"> <a class="close" data-dismiss="alert" href="#">×</a>
    <?php echo $this->session->flashdata('notification'); ?> </div>
  <?php endif; ?>
  <?php 
  if ($this->session->flashdata('current_tab'))
  {
	  $tabs=$this->session->flashdata('current_tab');
  }
  else
  {
    $tabs[1]='Company_Profile';
  }
  ?>
  <div id="section-body" class="tabbable"> <!-- Only required for left/right tabs -->
    <ul class="nav nav-tabs">
      <li class="active"><a href="#tab1" data-toggle="tab">Website Settings</a></li>
      <?php /*?><li><a href="<?php echo base_url()?>admin/dashboard/index" >Dashboard Settings</a></li><?php */?>
    </ul>
    <div class="tab-content">
      <div class="tab-pane active" id="tab1">
        <div class="row-fluid"> 
          <!--Tabs2-->
          <div class="span12">
            <div id="accordion1" class="accordion">
              <div class="accordion-group">
                <div class="accordion-heading"> <a href="#latest" data-toggle="collapse" class="accordion-toggle"> <i class="icon-wrench icon-white"></i> <span class="divider-vertical"></span>Website Settings<i class="icon-chevron-down icon-white pull-right"></i> </a> </div>
                <div class="accordion-body collapse in" id="latest">
                  <div class="accordion-inner">
                    <div class="tabbable"> <!-- Only required for left/right tabs -->
                      <form name="frmsettings" id="form" action="<?php echo base_url();?>admin/settings/update" method="post" enctype="multipart/form-data">
                        <input type="hidden" name="unique_id" value="<?php if($tabs): echo $tabs[0].'#'.$tabs[1]; else: echo base_url().'admin/settings/index#Company_Profile'; endif;?>" id="targets"/>
                        <ul class="nav nav-tabs">
                          <li <?php if($tabs[1]=='Company_Profile'): echo 'class="active"  ';  endif;?>><a href="#Company_Profile" data-toggle="tab">Company Profile</a></li>
                          <li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown">Site Information<b class="caret"></b></a>
                            <ul class="dropdown-menu">
                              <li <?php if($tabs[1]=='Site_Information'): echo 'class="active"  '; endif;?>><a href="#Site_Information" data-toggle="tab">Site Information</a></li>
                              <li <?php if($tabs[1]=='Google_Map_Information'): echo 'class="active" '; endif;?>><a  href="#Google_Map_Information" data-toggle="tab">Google Map Information</a></li>
                            </ul>
                          </li>
                          <li <?php if($tabs[1]=='Email_Information'): echo 'class="active" '; endif;?>><a href="#Email_Information" data-toggle="tab" >Email Information</a></li>
                          <li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown">SEO Settings<b class="caret"></b></a>
                            <ul class="dropdown-menu">
                              <!--<li <?php if($tabs[1]=='Google_Analytic_Code'): echo 'class="active"  '; endif;?>><a href="#Google_Analytic_Code" data-toggle="tab">Google Analytic Code</a></li>-->
                              <li <?php if($tabs[1]=='Google_Analytic_Code'): echo 'class="active"  '; endif;?>><a href="#Google_Analytic_Code" data-toggle="tab">Analytics Code</a></li>
                              <li <?php if($tabs[1]=='Meta_Tags'): echo 'class="active"'; endif;?>><a  href="#Meta_Tags" data-toggle="tab">Meta Information</a></li>
                            </ul>
                          </li>
                          <li <?php if($tabs[1]=='Emergency_ShutDown_Information'): echo 'class="active"  '; endif;?>><a href="#Emergency_ShutDown_Information" data-toggle="tab">Emergency ShutDown</a></li>
                          <li <?php if($tabs[1]=='Site_Authentication'): echo 'class="active" '; endif;?>><a href="#Site_Authentication" data-toggle="tab">Authentication Information</a></li>
                        </ul>
                        <div class="tab-content">
                          <div class="tab-pane <?php if($tabs[1]=='Company_Profile'): echo 'active'; endif;?>" id="Company_Profile">
                            <table width="100%" align="center" cellspacing="1" cellpadding="4" class="table table-bordered table-striped">
                              <thead>
                                <tr>
                                  <th colspan="2" style="text-align:center">Company Profile</th>
                                </tr>
                              </thead>
                              <tbody>
                                <tr>
                                  <td><span class="fieldlabel">Company Name :</span></td>
                                  <td><input type="text" name="company_name" id="company_name" size="42" value="<?php echo $this->system->company_name?>" /></td>
                                </tr>
                                <tr>
                                  <td><span class="fieldlabel">Company Address :</span></td>
                                  <td><textarea name="company_address" id="company_address" rows="4" ><?php echo $this->system->company_address?></textarea></td>
                                </tr>
                                <tr>
                                  <td><span class="fieldlabel">Company Contact # :</span></td>
                                  <td>
                                    <input type="text" name="company_mobile" id="company_mobile" size="20" class="phone" maxlength="14" value="<?php echo $this->system->company_mobile?>" /></td>
                                </tr>
                                <tr>
                                  <td><span class="fieldlabel">Company Email :</span></td>
                                  <td><input type="text" name="company_email" id="company_email" size="42" value="<?php echo $this->system->company_email?>" class="required email" required /></td>
                                </tr>
                              </tbody>
                            </table>
                          </div>
                          <div class="tab-pane <?php if($tabs[1]=='Site_Information'): echo 'active'; endif;?>" id="Site_Information">
                            <table width="100%" align="center" cellspacing="1" cellpadding="4" class="table table-bordered table-striped">
                              <thead>
                                <tr>
                                  <th colspan="2" style="text-align:center">Site Information</th>
                                </tr>
                              </thead>
                              <tbody>
                                <tr>
                                  <td><span class="fieldlabel">Admin Site Name :</span></td>
                                  <td><input type="text" name="site_name" id="site_name" size="42" value="<?php echo $this->system->site_name?>" /></td>
                                </tr>
                                <!--<tr>
                                  <td><span class="fieldlabel">Admin Site Icon :</span></td>
                                  <td><input type="file" name="site_icon" id="site_icn" size="42" value="<?php echo $this->system->site_icon?>" />
                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="<?php echo base_url();?>uploads/<?php echo $this->system->site_icon?>" />
                                    <input type="hidden" name="old_icon" id="old_icon" size="42" value="<?php echo $this->system->site_icon?>" /></td>
                                </tr>-->
                                <tr>
                                  <td><span class="fieldlabel">Marketing Site Name :</span></td>
                                  <td><input type="text" name="marketing_site_name" id="marketing_site_name" size="42" value="<?php echo $this->system->marketing_site_name?>" /></td>
                                </tr>
                                <!--<tr>
                                  <td><span class="fieldlabel">Marketing Site Icon :</span></td>
                                  <td><input type="file" name="marketing_site_icon" id="marketing_site_icn" size="42" value="<?php echo $this->system->marketing_site_icon?>" />
                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="<?php echo base_url();?>uploads/<?php echo $this->system->marketing_site_icon?>" />
                                    <input type="hidden" name="old_icon" id="old_icon" size="42" value="<?php echo $this->system->site_icon?>" /></td>
                                </tr>-->
                                <tr>
                                  <td><span class="fieldlabel">Copyright Text :</span></td>
                                  <td><textarea name="company_copyright" id="company_copyright" rows="4" ><?php echo $this->system->company_copyright?></textarea></td>
                                </tr>
                                <tr>
                                  <td><span class="fieldlabel">Default Page Size :</span></td>
                                  <td><?php global $asset; ?>
                                    <select id="page_size" name="page_size">
                                      <?php foreach($asset['SD_PageSize'] as $key => $val): ?>
                                      <?php if($val == $this->system->page_size): ?>
                                      <option value="<?php echo $key?>" selected="selected"><?php echo $val?></option>
                                      <?php else: ?>
                                      <option value="<?php echo $key?>"><?php echo $val?></option>
                                      <?php endif; ?>
                                      <?php endforeach; ?>
                                    </select></td>
                                </tr>
                                <tr>
                                  <td><span class="fieldlabel">Site Administrator Email Address :</span></td>
                                  <td><input type="text" name="from_email_address" id="from_email_address" size="42" value="<?php echo $this->system->from_email_address?>" class="email"/></td>
                                </tr>
                                <tr>
                                  <td><span class="fieldlabel">Powered By :</span></td>
                                  <td><textarea name="company_powerby" id="company_powerby" rows="4" ><?php echo $this->system->company_powerby ?></textarea></td>
                                </tr>
                                <tr>
                                  <td><span class="fieldlabel">Dashboard Listing Lock Expiration Time :</span></td>
                                  <td><input type="text" name="lock_expiration_time" id="lock_expiration_time" size="3" value="<?php echo $this->system->lock_expiration_time?>" class="email" maxlength="5"/> minutes (greater than zero)</td>
                                </tr>
                                <tr>
                                  <td><span class="fieldlabel">Force Password Change :</span></td>
                                  <td><input type="text" name="force_password_changes" id="force_password_changes" size="3" value="<?php echo $this->system->force_password_changes?>" class="email" maxlength="5" /> days (greater than zero)</td>
                                </tr>
                                <!--tr>
                                  <td><span class="fieldlabel">Facebook URL:</span></td>
                                  <td><input type="text" name="from_facebookurl" id="from_facebookurl" size="42" value="<?php echo $this->system->from_facebookurl ?>" class="url"/></td>
                                </tr>
                                <tr>
                                  <td><span class="fieldlabel">Flicker URL:</span></td>
                                  <td><input type="text" name="from_flickerurl" id="from_flickerurl" size="42" value="<?php echo $this->system->from_flickerurl?>" class="url"/></td>
                                </tr>
                                <tr>
                                  <td><span class="fieldlabel">Twitter URL:</span></td>
                                  <td><input type="text" name="from_twitterurl" id="from_twitterurl" size="42" value="<?php echo $this->system->from_twitterurl ?>" class="url"/></td>
                                </tr>
                                <tr>
                                  <td><span class="fieldlabel">Youtube URL:</span></td>
                                  <td><input type="text" name="from_youtubeurl" id="from_youtubeurl" size="42" value="<?php echo $this->system->from_youtubeurl ?>" class="url" /></td>
                                </tr-->
                              </tbody>
                            </table>
                          </div>
                          <div class="tab-pane <?php if($tabs[1]=='Email_Information'): echo 'active'; endif;?>" id="Email_Information" >
                            <table width="100%" align="center" cellspacing="1" cellpadding="4" class="table table-bordered table-striped">
                              <thead>
                                <tr>
                                  <th colspan="2" style="text-align:center">Email Information</th>
                                </tr>
                              </thead>
                              <tbody>
                                <tr>
                                  <td><span class="fieldlabel">Admin Email :</span></td>
                                  <td><input type="text" name="admin_email_address" id="admin_email_address" size="42" value="<?php echo $this->system->admin_email_address?>"  class="email"/></td>
                                </tr>
                                <tr>
                                  <td><span class="fieldlabel">Report Email :</span></td>
                                  <!--<td><input type="text" name="report_email" id="report_email" size="42" value="<?php echo $this->system->report_email?>" class="required email" required /></td>-->
                                  <td><textarea id="report_email" name="report_email" rows="5" cols="40"><?php echo $this->system->report_email;?></textarea>
                                    <br>
                                        <i>
                                            Enter multiple emails separated with a comma ','
                                        </i>
                                  </td>
                                </tr>
                                <tr>
                                  <td><span class="fieldlabel">Email Signature :</span></td>
                                  <td><textarea id="admin_email_signature" name="admin_email_signature" rows="4" cols="40"><?php echo $this->system->admin_email_signature?></textarea></td>
                                </tr>
                                <tr>
                                  <td><span class="fieldlabel">Email Footer :</span></td>
                                  <td>
                                      <textarea id="admin_email_footer" name="admin_email_footer" rows="4" cols="40"><?php echo $this->system->admin_email_footer ?></textarea>
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                          </div>
                          <!--<div class="tab-pane <?php if($tabs[1]=='Google_Analytic_Code'): echo 'active'; endif;?>" id="Google_Analytic_Code">
                            <table width="100%" align="center" cellspacing="1" cellpadding="4" class="table table-bordered table-striped">
                              <thead>
                                <tr>
                                  <th colspan="2" style="text-align:center">Google Analytic</th>
                                </tr>
                              </thead>
                              <tbody>
                                <tr>
                                  <td><span class="fieldlabel">Google Analytic Email :</span></td>
                                  <td><input type="text" name="ga_email" id="ga_email" size="42" value="<?php echo $this->system->ga_email;?>"  class="email"/></td>
                                </tr>
                                <tr>
                                  <td><span class="fieldlabel">Google Analytic Password :</span></td>
                                  <td><input type="password" name="ga_password" id="ga_password" size="42" value="<?php echo $this->system->ga_password?>"  /></td>
                                </tr>
                                <tr>
                                  <td><span class="fieldlabel">Google Analytic Profile Id :</span></td>
                                  <td><input type="password" name="ga_profile_id" id="ga_profile_id" size="42" value="<?php echo $this->system->ga_profile_id?>"   /></td>
                                </tr>
                                <tr>
                                  <td><span class="fieldlabel">Google Analytic Code :</span></td>
                                  <td><textarea id="admin_gooole_analytic_code" name="admin_gooole_analytic_code" rows="4" ><?php echo $this->system->admin_gooole_analytic_code ?></textarea></td>
                                </tr>
                              </tbody>
                            </table>
                          </div>-->
                          <div class="tab-pane <?php if($tabs[1]=='Google_Analytic_Code'): echo 'active'; endif;?>" id="Google_Analytic_Code">
                            <table width="100%" align="center" cellspacing="1" cellpadding="4" class="table table-bordered table-striped">
                              <thead>
                                <tr>
                                  <th colspan="2" style="text-align:center">Analytics</th>
                                </tr>
                              </thead>
                              <tbody>
                                <!--<tr>
                                  <td><span class="fieldlabel">Google Analytic Email :</span></td>
                                  <td><input type="text" name="ga_email" id="ga_email" size="42" value="<?php echo $this->system->ga_email;?>"  class="email"/></td>
                                </tr>
                                <tr>
                                  <td><span class="fieldlabel">Google Analytic Password :</span></td>
                                  <td><input type="password" name="ga_password" id="ga_password" size="42" value="<?php echo $this->system->ga_password?>"  /></td>
                                </tr>
                                <tr>
                                  <td><span class="fieldlabel">Google Analytic Profile Id :</span></td>
                                  <td><input type="password" name="ga_profile_id" id="ga_profile_id" size="42" value="<?php echo $this->system->ga_profile_id?>"   /></td>
                                </tr>
                                <tr>-->
                                  <td><span class="fieldlabel">Analytics Code :</span></td>
                                  <td><textarea id="admin_gooole_analytic_code" name="admin_gooole_analytic_code" rows="4" ><?php echo $this->system->admin_gooole_analytic_code ?></textarea>
                                  <br>
                                    <i>
                                        Without starting and closing 'script' tags
                                    </i>
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                          </div>
                          <div class="tab-pane <?php if($tabs[1]=='Google_Map_Information'): echo 'active'; endif;?>" id="Google_Map_Information">
                            <table width="100%" align="center" cellspacing="1" cellpadding="4" class="table table-bordered table-striped">
                              <thead>
                                <tr>
                                  <th colspan="2" style="text-align:center">Google Map Information</th>
                                </tr>
                              </thead>
                              <tbody>
                                <tr>
                                  <td><span class="fieldlabel">Google Map URL:</span></td>
                                  <td><input type="text" name="admin_gooole_map_url" id="admin_gooole_map_url" size="42" value="<?php echo $this->system->admin_gooole_map_url?>" /></td>
                                </tr>
                                <tr>
                                  <td><span class="fieldlabel">Google Map Address :</span></td>
                                  <td><input type="text" name="admin_gooole_map_address" id="admin_gooole_map_address" size="42" value="<?php echo $this->system->admin_gooole_map_address?>" /></td>
                                </tr>
                                <tr>
                                  <td><span class="fieldlabel">Google Map Key:</span></td>
                                  <td><input type="text" name="admin_gooole_map_key" id="admin_gooole_map_key" size="42" value="<?php echo $this->system->admin_gooole_map_key?>" /></td>
                                </tr>
                              </tbody>
                            </table>
                          </div>
                          <div class="tab-pane <?php if($tabs[1]=='Emergency_ShutDown_Information'): echo 'active'; endif;?>" id="Emergency_ShutDown_Information">
                            <table width="100%" align="center" cellspacing="1" cellpadding="4" class="table table-bordered table-striped">
                              <thead>
                                <tr>
                                  <th colspan="2" style="text-align:center">Emergency ShutDown</th>
                                </tr>
                              </thead>
                              <tbody>
                                <tr>
                                  <td><span class="fieldlabel">Is Emergency Shut down required?</span></td>
                                  <td><select id="admin_shutdown" name="admin_shutdown">
                                      <?php foreach($asset['SD_YesNo']  as $key => $val): ?>
                                      <?php if($val == $this->system->admin_shutdown): ?>
                                      <option value="<?php echo $key?>" selected="selected"><?php echo $val?></option>
                                      <?php else: ?>
                                      <option value="<?php echo $key?>"><?php echo $val?></option>
                                      <?php endif; ?>
                                      <?php endforeach; ?>
                                    </select></td>
                                </tr>
                                <tr>
                                  <td><span class="fieldlabel">Message:</span></td>
                                  <td><textarea id="admin_shutdown_message" name="admin_shutdown_message" ><?php echo $this->system->admin_shutdown_message ?></textarea></td>
                                </tr>
                              </tbody>
                            </table>
                          </div>
                          <div class="tab-pane <?php if($tabs[1]=='Meta_Tags'): echo 'active'; endif;?>" id="Meta_Tags">
                            <table width="100%" align="center" cellspacing="1" cellpadding="4" class="table table-bordered table-striped">
                              <thead>
                                <tr>
                                  <th colspan="2" style="text-align:center">Meta Tags</th>
                                </tr>
                              </thead>
                              <tbody>
                                <tr>
                                  <td><span class="fieldlabel">Meta Description :</span></td>
                                  <td><textarea id="admin_meta_description" name="admin_meta_description" rows="4" ><?php echo $this->system->admin_meta_description ?></textarea></td>
                                </tr>
                                <tr>
                                  <td><span class="fieldlabel">Meta Keyword  :</span></td>
                                  <td><textarea id="admin_meta_keyword" name="admin_meta_keyword" rows="4" ><?php echo $this->system->admin_meta_keyword ?></textarea></td>
                                </tr>
                                <tr>
                                  <td><span class="fieldlabel">Additional Meta Tag 	:</span></td>
                                  <td><textarea id="admin_additional_meta_tag" name="admin_additional_meta_tag" rows="4" ><?php echo $this->system->admin_additional_meta_tag ?></textarea></td>
                                </tr>
                                <tr>
                                  <td><span class="fieldlabel">Global Meta Tag 	:</span></td>
                                  <td>
                                  <?php if($this->system->admin_global_meta_tag=='Yes'):
								  	$yes='checked="checked"';
								  else:
								  $no='checked="checked"';
								  endif;
								  ?>
                                  <input type="radio" name="admin_global_meta_tag" id="admin_global_meta_tag_yes" value="Yes" <?php echo $yes;?>/> Yes<br/>
                                  <input type="radio" name="admin_global_meta_tag" id="admin_global_meta_tag_no" value="No" <?php echo $no;?>/>   No
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                          </div>
                          <div class="tab-pane <?php if($tabs[1]=='Site_Authentication'): echo 'active'; endif;?>" id="Site_Authentication">
                            <table width="100%" align="center" cellspacing="1" cellpadding="4" class="table table-bordered table-striped">
                              <thead>
                                <tr>
                                  <th colspan="2" style="text-align:center">Site Authentication</th>
                                </tr>
                              </thead>
                              <tbody>
                                <tr height="25">
                                  <td><span class="fieldlabel">Is Site Authentication required?</span></td>
                                  <td><select id="auth_required" name="auth_required">
                                      <?php
                                        global $asset;
                                        foreach($asset['SD_YesNo_Int']  as $key => $val): ?>
                                      <?php if($key == $this->system->auth_required):  ?>
                                      <option value="<?php echo $key?>" selected="selected"><?php echo $val?></option>
                                      <?php else : ?>
                                      <option value="<?php echo $key?>"><?php echo $val?></option>
                                      <?php endif; ?>
                                      <?php endforeach; ?>
                                    </select></td>
                                </tr>
                                <tr height="25">
                                  <td><span class="fieldlabel">User Name</span></td>
                                  <td  valign="middle"><input type=text id="auth_username" name="auth_username" size="42" value="<?php echo $this->system->auth_username ?>"></td>
                                </tr>
                                <tr height="25">
                                  <td><span class="fieldlabel">Password</span></td>
                                  <td  valign="middle"><input type="password" id="auth_password" name="auth_password" size="42" value="<?php echo $this->system->auth_password ?>"></td>
                                </tr>
                              </tbody>
                            </table>
                          </div>
                          <table width="100%" align="center" cellspacing="1" cellpadding="4" class="tableborder">
                            <tr>
                              <td colspan="2" class="stdLabel" align="center"><input type="submit" name="submit" class="btn btn-primary" value="Update" onclick="return confirmSubmit(document.frmsettings);" />
                                &nbsp;&nbsp;
                                <input type="button" name="cancel" class="btn" value="Cancel" onclick="location.href='<?php echo base_url()?>admin/home'"  /></td>
                            </tr>
                          </table>
                        </div>
                      </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript" src="<?php echo base_url().$this->config->item('javascript_path');?>tinymce/tinymce.min.js"></script> 
<script>
//tinymce.PluginManager.load('moxiemanager', '/js/moxiemanager/plugin.min.js');
tinymce.init({
        selector: "#admin_shutdown_message",
        theme: "modern",
        plugins: [
                "advlist autolink lists link image charmap print preview hr anchor pagebreak",
                "searchreplace wordcount visualblocks visualchars code fullscreen",
                "insertdatetime media nonbreaking save table contextmenu directionality",
                "emoticons paste textcolor"
        ],
        toolbar1: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image",
        toolbar2: "print preview media | forecolor backcolor emoticons",
        image_advtab: true,
});
</script>
<script type="text/javascript">
jQuery(document).ready(function() {
$('a[data-toggle="tab"]').on('shown', function (e) {
  var target=e.target // activated tab
  e.relatedTarget // previous tab
 $("#targets").val(e.target);
});
});
</script>
<?php $this->load->view('admin/footer');?>
<script>
$(".phone").mask("(999) 999-9999");
</script>