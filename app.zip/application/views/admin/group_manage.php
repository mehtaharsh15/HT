<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');$this->load->view('admin/header');
global $asset; 
?>
<div id="content" class="span12 section-body">
  <?php if ($this->session->flashdata('notification')): ?>
  <div class="alert alert-success"> <a class="close" data-dismiss="alert" href="#">×</a>
    <?php echo $this->session->flashdata('notification');?> </div>
  <?php endif; ?>
  <div id="section-body" class="tabbable"> <!-- Only required for left/right tabs -->
    <ul class="nav nav-tabs">
      <li class="active"><a href="#tab1" data-toggle="tab">Group Listing</a></li>
    <?php
        if($this->common->admin_permission('Group_Add','Management','Group',TRUE))
        {
    ?>
      <li><a href="<?php echo base_url();?>admin/group/insert" >Add New Group</a></li>
    <?php
        }
    ?>
    </ul>
    <div class="tab-content">
      <div class="tab-pane active" id="tab1">
        <div class="row-fluid">
          <!--Tabs2-->
          <div class="span12">
            <div id="accordion1" class="accordion">
              <div class="accordion-group">
                <div class="accordion-heading"> <a class="accordion-toggle" data-toggle="collapse" href="#notification" data-original-title=""> <i class="icon-user icon-white"></i> <span class="divider-vertical"></span>Group<i class="icon-chevron-down icon-white pull-right"></i> </a> </div>
                <div id="notification" class="accordion-body collapse in">
                  <div class="accordion-inner paddind">
                    <form name="frmGroupList" method="post" action="<?php echo base_url()?>admin/group">
                      <table class="table table-bordered table-striped pull-left" id="example">
                        <thead>
                          <tr>
                            <?php foreach ($this->group->column_headers as $key => $val): ?>
                            <th width="<?php echo $val ?>"><?php echo $key?></th>
                            <?php endforeach;?>
                            <th width="13%">Action</th>
                          </tr>
                        </thead>
                        <tbody>
                          <?php if($group_count == 0): ?>
                          <tr>
                            <td colspan="7" align="center">No group found.</td>
                          </tr>
                          <?php else: ?>
                          <?php foreach($group_entry as $groupEntry):?>
                          <tr class="delete-<?php echo $groupEntry['group_id'];?>">
                            <td><?php echo $groupEntry['group_name'];?></td>
                            <td><?php echo $groupEntry['group_address_1'],"<br/>";if(!empty($groupEntry['group_address_2'])) echo $groupEntry['group_address_2'],"<br/>"; echo $groupEntry['group_city'],"&nbsp;"; echo $groupEntry['group_zip'],"<br/>",$states[$groupEntry['group_state_id']];?></td>
                            <td>
                                <?php 
                                    //echo $groupEntry['group_email'];
                                    echo '<a href="mailto:'.$groupEntry['group_email'].'" target="_top">'.$groupEntry['group_email'].'</a>';
                                ?>
                            </td>
                            <td><?php echo $groupEntry['group_phone'];?></td>
                            <td><?php echo $groupEntry['practice_name'];?></td>
                            <td><?php echo $asset['SD_GroupType'][$groupEntry['group_type']];?></td>
                            <td align="center" width="13%">
                            <div>
                                <input type="hidden" name="group_id" value="<?php echo $groupEntry['group_id'];?>">
                                <a data-toggle="modal" href="#myModal<?php echo $groupEntry['group_id'];?>" class="tooltip-top btn" data-original-title="View"> <i class="icon-eye-open" ></i></a>
                                &nbsp;
                                <?php
                                    if($this->common->admin_permission('Group_Edit','Management','Group',TRUE))
                                    {
                                ?>
                                    <a data-original-title="Edit" href="<?php echo base_url()?>admin/group/edit/<?php echo $groupEntry['group_id']?>" class="tooltip-top btn"><i class="icon-edit" ></i></a>
                                    &nbsp;
                                <?php
                                    }
                                    if($this->common->admin_permission('Group_Delete','Management','Group',TRUE))
                                    {
                                ?>
                                    <a class="tooltip-top btn" data-original-title="Delete" onClick="fun_delete('group_master','group_id','<?php echo $groupEntry['group_id'];?>','group_active','<?php echo $groupEntry['group_active']?0:$groupEntry['group_active'];?>');"><i class="icon-trash" style="cursor: pointer" ></i></a>
                                <?php
                                    }
                                ?>
                                </div>
                              <div id="myModal<?php echo $groupEntry['group_id'];?>" class="modal hide fade">
                                <div class="modal-header">
                                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                                  <h3>Group</h3>
                                </div>
                                <div class="modal-body" id="result">
                                  <div id="accordion2" class="accordion">
                                    <div class="accordion-heading"> <a href="#widget-tabs<?php echo $groupEntry['group_id'];?>" data-toggle="collapse" class="accordion-toggle in"> <i class="icon-user icon-white"></i> <span class="divider-vertical"></span> <?php echo $groupEntry['group_name'];?><i class="icon-chevron-down icon-white pull-right"></i> </a> </div>
                                    <div class="accordion-body collapse in" id="widget-tabs<?php echo $groupEntry['group_id'];?>">
                                      <div class="accordion-inner">
                                        <table class="table table-striped" width="90%">
                                          <tbody>
                                            <tr>
                                              <td><span class="fieldlabel"><b>Name:</b></span></td>
                                              <td><?php echo $groupEntry['group_name'];?></td>
                                            </tr>
                                            <tr>
                                              <td><span class="fieldlabel"><b>Type:</b></span></td>
                                              <td><?php echo $asset['SD_GroupType'][$groupEntry['group_type']];?></td>
                                            </tr>
                                            <tr>
                                              <td><span class="fieldlabel"><b>Address:</b></span></td>
                                              <td><?php echo $groupEntry['group_address_1'],"<br/>"; if(!empty($groupEntry['group_address_2'])) echo $groupEntry['group_address_2'],"<br/>"; echo $groupEntry['group_city'],"<br/>"; echo $groupEntry['group_zip'];?></td>
                                            </tr>
                                            <tr>
                                              <td><span class="fieldlabel"><b>State:</b></span></td>
                                              <td><?php echo $states[$groupEntry['group_state_id']];?></td>
                                            </tr>
                                            <tr>
                                              <td><span class="fieldlabel"><b>ZIP:</b></span></td>
                                              <td><?php echo $groupEntry['group_zip'];?></td>
                                            </tr>
                                            <tr>
                                              <td><span class="fieldlabel"><b>Email:</b></span></td>
                                              <td>
                                                  <?php 
                                                      //echo $groupEntry['group_email'];
                                                    echo '<a href="mailto:'.$groupEntry['group_email'].'" target="_top">'.$groupEntry['group_email'].'</a>';
                                                  ?>
                                              </td>
                                            </tr>
                                            <tr>
                                              <td><span class="fieldlabel"><b>Phone:</b></span></td>
                                              <td><?php echo $groupEntry['group_phone'];?></td>
                                            </tr>
                                            <tr>
                                              <td><span class="fieldlabel"><b>Fax:</b></span></td>
                                              <td><?php echo $groupEntry['group_fax'];?></td>
                                            </tr>
                                            <?php
                                                if(!empty($groupEntry['group_url']))
                                                {
                                            ?>
                                                <tr>
                                                    <td><span class="fieldlabel"><b>URL:</b></span></td>
                                                    <td><?php echo $groupEntry['group_url'];?></td>
                                                </tr>
                                            <?php
                                                }
                                            ?>
                                            <tr>
                                              <td><span class="fieldlabel"><b>Practice:</b></span></td>
                                              <td><?php echo $groupEntry['practice_name'];?></td>
                                            </tr>
                                            <tr>
                                              <td><span class="fieldlabel"><b>Status:</b></span></td>
                                              <td><?php echo $asset['SD_Active'][$groupEntry['group_active']];?></td>
                                            </tr>
                                          </tbody>
                                        </table>
                                      </div>
                                    </div>
                                  </div>
                                  <div class="modal-footer">
                                    <?php
                                        if($this->common->admin_permission('Group_Edit','Management','Group',TRUE))
                                        {
                                    ?>
                                        <a href="<?php echo base_url()?>admin/group/edit/<?php echo $groupEntry['group_id']?>" class="btn">Edit</a>
                                    <?php
                                        }
                                    ?>
                                      <a href="#" class="btn" data-dismiss="modal" >Close</a>
                                  </div>
                                </div>
                              </div>
                              </td>
                          </tr>
                          <?php endforeach;?>
                          <?php endif; ?>
                        </tbody>
                        <tfoot>
                          <tr>
                            <?php foreach ($this->group->column_headers as $key => $val): ?>
                            <th><?php echo $key?></th>
                            <?php endforeach;?>
                            <th>Action</th>
                          </tr>
                        </tfoot>
                      </table>
                      <input type="hidden" name="action"/>
                      <input type="hidden" name="groupid"/>
                    </form>
                    <br />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<style type="text/css">
.control-group.error td{color:#b94a48;}
.control-group.success td{color:#468847;}
.control-group.success label.valid 
{
    background: url('../img/valid.png') center center no-repeat;
    display: inline-block;
    text-indent: 45px;
}
</style>
<script type="text/javascript" charset="utf-8">
function fun_delete(tablename,field_id,field_value,status_field,status_value){
    $.ajax({
        url:"<?php echo base_url().'index.php/admin/group/changeactivestatus/1/';?>",
        type:"POST",
        beforeSend: function(){
            var conform=confirm("Are you sure to delete this group?");
            if(!conform){
                    return false;
            }
        },
        data:{group_id:field_value, group_active:status_value},
        success:function(data){
                    //alert(data);
                    $('.delete-'+data).fadeOut('slow');
        }
    });
}
</script>
<?php $this->load->view('admin/footer');?>