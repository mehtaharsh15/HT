<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');$this->load->view('admin/header');
global $asset;
?>
<!--<link href="<?php echo base_url().$this->config->item('stylesheet_path');?>css.css" media="screen" rel="stylesheet" type="text/css" />-->
<div id="content" class="span12 section-body">
	<?php if (isset($machineMsg) && !empty($machineMsg)): ?>
      <div class="alert alert-error">
          <a class="close" data-dismiss="alert" href="#">×</a>
          <?php //echo $this->session->flashdata('notification');?> <?php echo $machineMsg;?>
      </div>
    <?php endif; ?>
  <div id="section-body" class="tabbable"> <!-- Only required for left/right tabs -->
    <ul class="nav nav-tabs">
      <li><a href="<?php echo base_url()?>admin/machine/index" >Machine Listing</a></li>
      <li  <?php if($this->uri->segment(3) == 'insert'):?>class="active"<?php  endif;?>
><a href="<?php echo base_url()?>admin/machine/insert" >Add New Machine</a></li>
      <?php if($this->uri->segment(3) == 'edit'):?>
      <li class="active"><a href="#tab1" data-toggle="tab" >Edit Machine</a></li>
      <?php endif;?>
    </ul>
    <div class="tab-content">
      <div class="tab-pane active" id="tab1">
        <div class="row-fluid"> 
          <!--Tabs2-->
          <div class="span12">
            <div id="accordion1" class="accordion">
              <div class="accordion-partner">
                <div class="accordion-heading"> <a class="accordion-toggle" data-toggle="collapse" href="#notification" data-original-title=""> <i class="icon-user icon-white"></i> <span class="divider-vertical"></span>
                  <?php if($this->uri->segment(3) == 'edit'): echo "Edit Machine"; else: echo "Add New Machine"; endif;?>
                  <i class="icon-chevron-down icon-white pull-right"></i> </a> </div>
                <div id="notification" class="accordion-body collapse in">
                  <div class="accordion-inner paddind">
                    <div class="mandatory-note">
                      Fields marked with * are mandatory.
                      <br/>
                    </div>
                    <form name="frmpartner" id="form" action="<?php if($this->uri->segment(3) == 'insert'): ?><?php echo base_url();?>admin/machine/insert<?php else: ?><?php echo base_url();?>admin/machine/edit<?php endif; ?>" method="post" enctype="multipart/form-data">
                      <table class="table table-bordered table-striped pull-left">
                        <tbody>
                          <tr class="control-partner">
                            <td class="control-label"><span class="fieldlabel"><span class="mandatory-star">*</span>Machine Name:</span></td>
                            <td class="controls">
                              <input type="text" class="required" required maxlength="150" name="machine_name" id="machine_name" value="<?php echo $machine_edit_entry['machine_name'];?>" />
                            </td>
                          </tr>
                          <tr class="control-partner">
                            <td class="control-label"><span class="fieldlabel"><span class="mandatory-star">*</span>Machine Code:</span></td>
                            <td class="controls">
                              <input type="text" class="required" required maxlength="15" name="machine_code" id="machine_code" value="<?php echo $machine_edit_entry['machine_code'];?>" />
                            </td>
                          </tr>
                        
                        
                          <tr class="control-partner">
                            <td class="control-label"><span class="fieldlabel"><span class="mandatory-star">*</span>Machine Latitude:</span></td>
                            <td class="controls"><input type="text" class="required" required maxlength="20" name="machine_latitude" id="machine_latitude" value="<?php echo $machine_edit_entry['machine_latitude']; ?>"></td>
                          </tr>
                        
                          <tr class="control-partner">
                            <td class="control-label"><span class="fieldlabel"><span class="mandatory-star">*</span>Machine Longitude:</span></td>
                            <td class="controls"><input type="text" class="required" required maxlength="20" name="machine_longitude" id="machine_longitude" value="<?php echo $machine_edit_entry['machine_longitude']; ?>"></td>
                          </tr>
                        
                        
                          
                         
                        <?php
                        if($this->uri->segment(3) != 'edit')
                        {
                        ?>
                          <tr>
                            <td><span class="fieldlabel"><span class="mandatory-star">*</span>Machine Status:</span></td>
                            <td>
                              <select id="machine_active" name="machine_active">
                                <?php foreach($asset['SD_Active'] as $key => $val): ?>
                                <?php if(isset($machine_edit_entry['machine_active']))
									  {
										  if($key == $machine_edit_entry['machine_active'])
										  {
								?>
	                                        <option value="<?php echo $key?>" selected="selected"><?php echo $val?></option>
			                    <?php 	  }
										  else
										  {
								?>
			                                <option value="<?php echo $key?>"><?php echo $val?></option>
                                <?php 
										  }
									  }
									  else
									  {
										  if($key == 1)
										  {
								?>
	                                        <option value="<?php echo $key?>" selected="selected"><?php echo $val?></option>
			                    <?php 	  }
										  else
										  {
								?>
			                                <option value="<?php echo $key?>"><?php echo $val?></option>
                                <?php 
										  }
									  }
								?>
                                <?php endforeach; ?>
                              </select>
                            </td>
                          </tr>
                        <?php
                        }
                        ?>
                          <tr>
                          	<td>&nbsp;</td>
                            <td class="stdLabel" style="text-align:left;"><input type="submit" name="submit" class="btn btn-primary" value="<?php if($this->uri->segment(3) == 'insert'): ?>Save<?php else: ?>Update<?php endif; ?>" />
                              &nbsp;&nbsp;
                              <input type="button" name="cancel" class="btn" value="Cancel"  onclick="location.href='<?php echo base_url();?>admin/machine/index/'"/></td>
                          </tr>
                        </tbody>
                      </table>
                      <input type="hidden" name="machine_id" id="machine_id" value="<?php echo $machine_edit_entry['machine_id'];?>" />
                    </form>
                    <br />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<?php $this->load->view('admin/footer');?>
