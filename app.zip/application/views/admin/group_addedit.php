<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');$this->load->view('admin/header');
global $asset;
?>
<!--<link href="<?php echo base_url().$this->config->item('stylesheet_path');?>css.css" media="screen" rel="stylesheet" type="text/css" />-->
<div id="content" class="span12 section-body">
	<?php if ($this->session->flashdata('notification')): ?>
      <div class="alert alert-success">
          <a class="close" data-dismiss="alert" href="#">×</a>
          <?php echo $this->session->flashdata('notification');?> <?php echo $this->session->flashdata('groupMsg');?>
      </div>
    <?php endif; ?>
  <div id="section-body" class="tabbable"> <!-- Only required for left/right tabs -->
    <ul class="nav nav-tabs">
      <li><a href="<?php echo base_url()?>admin/group/index" >Group Listing</a></li>
      <li  <?php if($this->uri->segment(3) == 'insert'):?>class="active"<?php  endif;?>
><a href="<?php echo base_url()?>admin/group/insert" >Add New Group</a></li>
      <?php if($this->uri->segment(3) == 'edit'):?>
      <li class="active"><a href="#tab1" data-toggle="tab" >Edit Group</a></li>
      <?php endif;?>
    </ul>
    <div class="tab-content">
      <div class="tab-pane active" id="tab1">
        <div class="row-fluid"> 
          <!--Tabs2-->
          <div class="span12">
            <div id="accordion1" class="accordion">
              <div class="accordion-group">
                <div class="accordion-heading"> <a class="accordion-toggle" data-toggle="collapse" href="#notification" data-original-title=""> <i class="icon-user icon-white"></i> <span class="divider-vertical"></span>
                  <?php if($this->uri->segment(3) == 'edit'): echo "Edit Group"; else: echo "Add New Group"; endif;?>
                  <i class="icon-chevron-down icon-white pull-right"></i> </a> </div>
                <div id="notification" class="accordion-body collapse in">
                  <div class="accordion-inner paddind">
                    <div class="mandatory-note">
                      Fields marked with * are mandatory.
                      <br/>
                    </div>
                    <form name="frmgroup" id="form" action="<?php if($this->uri->segment(3) == 'insert'): ?><?php echo base_url();?>admin/group/insert<?php else: ?><?php echo base_url();?>admin/group/edit<?php endif; ?>" method="post" enctype="multipart/form-data">
                      <table class="table table-bordered table-striped pull-left">
                        <tbody>
                          <tr class="control-group">
                            <td class="control-label"><span class="fieldlabel"><span class="mandatory-star">*</span>Group Name:</span></td>
                            <td class="controls">
                              <input type="text" class="required" required maxlength="150" name="group_name" id="group_name" value="<?php echo $group_edit_entry['group_name'];?>" />
							</td>
                          </tr>
                          <tr class="control-group">
                            <td class="control-label"><span class="fieldlabel"><span class="mandatory-star">*</span>Type:</span></td>
                            <td>
                              <select id="group_type" name="group_type">
                                <?php foreach($asset['SD_GroupType'] as $key => $val): ?>
                                <?php if($key == $group_edit_entry['group_type']): ?>
                                <option value="<?php echo $key?>" selected="selected"><?php echo $val?></option>
                                <?php else: ?>
                                <option value="<?php echo $key?>"><?php echo $val?></option>
                                <?php endif; ?>
                                <?php endforeach; ?>
                              </select>
                            </td>
                          </tr>
                          <tr class="control-group">
                            <td class="control-label"><span class="fieldlabel"><span class="mandatory-star">*</span>Address Line 1:</span></td>
                            <td class="controls"><input type="text" class="required" required maxlength="255" name="group_address_1" value="<?php echo $group_edit_entry['group_address_1'];?>" id="group_address_1" >
                            </td>
                          </tr>
                          <tr class="control-group">
                            <td class="control-label"><span class="fieldlabel">Address Line 2:</span></td>
                            <td class="controls"><input type="text" maxlength="255" name="group_address_2" value="<?php echo $group_edit_entry['group_address_2']; ?>" id="group_address_2" >
                            </td>
                          </tr>
                          <tr class="control-group">
                            <td class="control-label"><span class="fieldlabel"><span class="mandatory-star">*</span>City:</span></td>
                            <td class="controls"><input type="text" class="required" required maxlength="255" name="group_city" id="group_city" value="<?php echo $group_edit_entry['group_city']; ?>"></td>
                          </tr>
                          <tr>
                            <td><span class="fieldlabel"><span class="mandatory-star">*</span>State:</span></td>
                            <td>
                              <select id="group_state_id" name="group_state_id">
                                <?php foreach($states as $key => $val): ?>
                                <?php if($val['state_id'] == $group_edit_entry['group_state_id']): ?>
                                <option value="<?php echo $val['state_id']?>" selected="selected"><?php echo $val['state_name'];?></option>
                                <?php else: ?>
                                <option value="<?php echo $val['state_id']?>"><?php echo $val['state_name'];?></option>
                                <?php endif; ?>
                                <?php endforeach; ?>
                              </select>
                            </td>
                          </tr>
                          <tr class="control-group">
                            <td class="control-label"><span class="fieldlabel"><span class="mandatory-star">*</span>ZIP:</span></td>
                            <td class="controls"><input type="text" class="required" required maxlength="6" name="group_zip" id="group_zip" value="<?php echo $group_edit_entry['group_zip']; ?>"></td>
                          </tr>
                          <tr class="control-group">
                            <td class="control-label"><span class="fieldlabel"><span class="mandatory-star">*</span>Email:</span></td>
                            <td class="controls"><input type="text" class="required email" required maxlength="100" name="group_email" id="group_email" value="<?php echo $group_edit_entry['group_email']; ?>"></td>
                          </tr>
                          <tr class="control-group">
                            <td class="control-label"><span class="fieldlabel"><span class="mandatory-star">*</span>Phone:</span></td>
                            <td class="controls"><input type="text" class="required phone" required maxlength="14" name="group_phone" id="group_phone" value="<?php echo $group_edit_entry['group_phone']; ?>"></td>
                          </tr>
                          <tr class="control-group">
                            <td class="control-label"><span class="fieldlabel">Fax:</span></td>
                            <td class="controls"><input type="text" class="phone" maxlength="15" name="group_fax" id="group_fax" value="<?php echo $group_edit_entry['group_fax']; ?>"></td>
                          </tr>
                          <tr class="control-group">
                            <td class="control-label"><span class="fieldlabel">URL:</span></td>
                            <td class="controls"><input type="text" class="url" maxlength="255" name="group_url" id="group_url" value="<?php echo $group_edit_entry['group_url']; ?>"></td>
                          </tr>
                          <tr>
                            <td><span class="fieldlabel"><span class="mandatory-star">*</span>Practice:</span></td>
                            <td>
                              <select id="group_practice_id" name="group_practice_id">
                                <?php foreach($practices as $key => $val): ?>
                                <?php if($val['practice_id'] == $group_edit_entry['group_practice_id']): ?>
                                <option value="<?php echo $val['practice_id']?>" selected="selected"><?php echo $val['practice_name'];?></option>
                                <?php else: ?>
                                <option value="<?php echo $val['practice_id']?>"><?php echo $val['practice_name'];?></option>
                                <?php endif; ?>
                                <?php endforeach; ?>
                              </select>
                            </td>
                          </tr>
                        <?php
                        if($this->uri->segment(3) != 'edit')
                        {
                        ?>
                          <tr>
                            <td><span class="fieldlabel"><span class="mandatory-star">*</span>Status:</span></td>
                            <td>
                              <select id="group_active" name="group_active">
                                <?php foreach($asset['SD_Active'] as $key => $val): ?>
                                <?php if(isset($group_edit_entry['group_active']))
									  {
										  if($key == $group_edit_entry['group_active'])
										  {
								?>
	                                        <option value="<?php echo $key?>" selected="selected"><?php echo $val?></option>
			                    <?php 	  }
										  else
										  {
								?>
			                                <option value="<?php echo $key?>"><?php echo $val?></option>
                                <?php 
										  }
									  }
									  else
									  {
										  if($key == 1)
										  {
								?>
	                                        <option value="<?php echo $key?>" selected="selected"><?php echo $val?></option>
			                    <?php 	  }
										  else
										  {
								?>
			                                <option value="<?php echo $key?>"><?php echo $val?></option>
                                <?php 
										  }
									  }
								?>
                                <?php endforeach; ?>
                              </select>
                            </td>
                          </tr>
                        <?php
                        }
                        ?>
                          <tr>
                          	<td>&nbsp;</td>
                            <td class="stdLabel" style="text-align:left;"><input type="submit" name="submit" class="btn btn-primary" value="<?php if($this->uri->segment(3) == 'insert'): ?>Save<?php else: ?>Update<?php endif; ?>" />
                              &nbsp;&nbsp;
                              <input type="button" name="cancel" class="btn" value="Cancel"  onclick="location.href='<?php echo base_url();?>admin/group/index/'"/></td>
                          </tr>
                        </tbody>
                      </table>
                      <input type="hidden" name="group_id" id="group_id" value="<?php echo $group_edit_entry['group_id'];?>" />
                    </form>
                    <br />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $this->load->view('admin/footer');?>
<script>
$('#group_name').focus();
$(".phone").mask("(999) 999-9999");
</script>