<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); $this->load->view('admin/header');?>
<div class='singin' style='display:block;'>
    <div class="accounts-form">
        <table id="login" cellpadding="2" cellspacing="1" class="table table-striped table-bordered table-condensed">
            <tr>
                <th colspan="2" align="center">
                    Login
                </th>
            </tr>
			<?php if (!empty($msg)) { ?>
            <tr>
                <td colspan="2" align="center" height="15">
                    <font color="#FF0000">
                        <?php echo $msg;?>
                    </font>
                </td>
            </tr>
			<?php } ?>
			<?php if (!empty($succmsg)) { ?>
            <tr>
                <td colspan="2" align="center" height="15">
                    <font color="#62C462">
                        <?php echo $succmsg;?>
                    </font>
                </td>
            </tr>
			<?php } ?>
            <tr>
                <td width="40%" align="center" style="text-align: center; vertical-align: middle;">
                    <img src="<?php echo base_url().$this->config->item('image_path');?>admin/login.png" style="padding-top:15px;" />
                </td>
                <td width="60%">
				
                    <form name="frmlogin" class="clearfix" autocomplete="off" id="frmlogin" action="<?php echo site_url('admin/login/dologin/')?>" method="post" enctype="multipart/form-data">
					
                        <table cellpadding="2" cellspacing="2" class="table table-striped table-bordered table-condensed">
                            <tr>
                                <td>
                                    <strong>
                                        Username
                                    </strong>
                                </td>
                                <td>
                                    <div class="input">
                                        <input type="text" name="username" id="username" class="input-medium" placeholder="Username" required value="<?php echo $this->input->post('username');?>"/>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <strong>
                                        Password
                                    </strong>
                                </td>
                                <td>
                                    <div class="input">
                                        <input type="password" name="password" id="password" class="input-medium" placeholder="Password" required /><br />
										<font color="red">Password is case sensitive.</font>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="2">
                                    <div class="actions">
                                        <input type="submit" name="submit" value="Login" class="btn btn-success" />
                                    </div>
                                </td>
                            </tr>
                        </table>
                    </form>
                </td>
            </tr>
        </table>
		You are accessing this section from <?php echo $this->input->server('REMOTE_ADDR'); ?>.<br />If you do not have the access permission, please contact portal administrator.
    </div>
</div>
<script>
$('#username').focus();
</script>
<?php $this->load->view('admin/footer');?>
