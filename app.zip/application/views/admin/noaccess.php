<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); $this->load->view('admin/header');?>
<div id="content" class="span12 section-body">
  <?php if ($this->session->flashdata('notification')): ?>
  <div class="alert alert-success"> <a class="close" data-dismiss="alert" href="#">×</a>
    <?php echo $this->session->flashdata('notification');?> </div>
  <?php endif; ?>
  <div id="section-body" class="tabbable"> <!-- Only required for left/right tabs -->
    <ul class="nav nav-tabs">
      <li class="active"><a href="#tab1" data-toggle="tab">No Access</a></li>
    </ul>
    <div class="tab-content">
      <div class="tab-pane active" id="tab1">
        <div class="row-fluid"> 
          <!--Tabs2-->
          <form name="frmblocklist"  method="post" action="<?php echo base_url()?>admin/block">
            <div class="span12">
              <div id="accordion1" class="accordion">
                <div class="accordion-group">
                  <div class="accordion-heading"> <a class="accordion-toggle" data-toggle="collapse" href="#notification" data-original-title=""> <i class="icon-th icon-white"></i> <span class="divider-vertical"></span>Sorry!!! You do not have access to this module.<i class="icon-chevron-down icon-white pull-right"></i> </a> </div>
                  <div id="notification" class="accordion-body collapse in">
                    <div class="accordion-inner paddind">
                      <center><img src="<?php echo base_url().$this->config->item('image_path');?>admin/prohibition-unauth-2.gif" align="middle"/></center>
                      <br />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $this->load->view('admin/footer');?>