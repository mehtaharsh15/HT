
<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');$this->load->view('admin/header');
global $asset; 

?>

<div id="content" class="span12 section-body">
  <?php if ($this->session->flashdata('notification')): ?>
  <div class="alert alert-success"> <a class="close" data-dismiss="alert" href="#">×</a>
    <?php echo $this->session->flashdata('notification');?> </div>
  <?php endif; ?>
  
  <div id="section-body" class="tabbable"> <!-- Only required for left/right tabs -->
    <ul class="nav nav-tabs">
      <li ><a href="<?php echo base_url();?>admin/Buy/index">Buy</a></li>
      <li class="active"><a href="<?php echo base_url();?>admin/sell/index" >Sell</a></li>
    
    </ul>
    <div class="tab-content">
      <div class="tab-pane active" id="tab1">
        <div class="row-fluid">
          <!--Tabs2-->
          <div class="span12">
            <div id="accordion1" class="accordion">
              <div class="accordion-partner">
                <div class="accordion-heading"> <a class="accordion-toggle" data-toggle="collapse" href="#notification" data-original-title=""> <i class="icon-user icon-white"></i> <span class="divider-vertical"></span>Sell Trasaction<i class="icon-chevron-down icon-white pull-right"></i> </a> 
				</div>
                <div id="notification" class="accordion-body collapse in">
                  <div class="accordion-inner paddind">
                    <form name="frmPartnerList" method="post" action="<?php echo base_url();?>admin/sell">
                      <table class="table table-bordered table-striped pull-left" id="example">
                        <thead>
                          <tr>
                            <?php foreach ($this->sell->column_headers as $key => $val): ?>
                            <th width="<?php echo $val;?>"><?php echo $key;?></th>
                            <?php endforeach;?>
							
							
							
                            <th width="20%">Action</th>
                          </tr>
                        </thead>
                        <tbody>
                          <?php if($machine_count != 0): ?>
                          <tr class="delete-0">
                            <td colspan="5" align="center">No machine found.</td>
                          </tr>
                          <?php else: ?>
						  
						  
						  
                          <?php foreach($sell_entry as $sellEntry):?>
                          <tr class="delete-<?php echo $sellEntry['sell_id'];?>">
						     <td>#<?php echo$sellEntry['sell_txn_no'];?></td>
                             <td><?php echo $sellEntry['sell_date'];?></td>
                             <td><?php echo $sellEntry['sell_uom'];?></td>
                             <td><?php echo $sellEntry['customer_firstname'];?>&nbsp;<?php echo $sellEntry['customer_lastname'];?></td>
						     <td><?php echo $sellEntry['machine_code'];?></td>
							 <td><?php echo $sellEntry['sell_amount'];?></td>
						     <td><?php echo $sellEntry['sell_qty'];?></td>
						    
                          
                          

                            <td align="center" width="20%">
                            <div>
                                <input type="hidden" name="sell_id" value="<?php echo $sellEntry['sell_id'];?>">
                                <a data-toggle="modal" href="#myModal<?php echo $sellEntry['sell_id'];?>" class="tooltip-top btn" data-original-title="View"><i class="icon-eye-open"></i></a>
                                &nbsp;
                             
                                    <a data-original-title="Edit" href="<?php echo base_url()?>admin/sell/edit/<?php echo $sellEntry['sell_id']?>" class="tooltip-top btn"><i class="icon-edit"></i></a>
                                    &nbsp;
                               
                                    <a class="tooltip-top btn" data-original-title="Delete" onClick="fun_delete('<?php echo $sellEntry['sell_id'];?>','<?php echo $sellEntry['sell_active']?0:$sellEntry['sell_active'];?>');">
									<i class="icon-trash" style="cursor: pointer"></i></a>
                               
                                </div>
                              <div id="myModal<?php echo $sellEntry['sell_id'];?>" class="modal hide fade">
                                <div class="modal-header">
                                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                                  <h3>Sell Trasaction</h3>
                                </div>
                                <div class="modal-body" id="result">
                                  <div id="accordion2" class="accordion">
                                    <div class="accordion-heading"><a href="#widget-tabs<?php echo $sellEntry['sell_id'];?>" data-toggle="collapse" class="accordion-toggle in"><i class="icon-user icon-white"></i><span class="divider-vertical"></span>
									Sell  Trasaction<i class="icon-chevron-down icon-white pull-right"></i></a></div>
                                    <div class="accordion-body collapse in" id="widget-tabs<?php echo $sellEntry['sell_id'];?>">
                                      <div class="accordion-inner">
                                        <table class="table table-striped" width="90%">
                                          <tbody>
										     <tr>
                                              <td><span class="fieldlabel"><b> Sell Trasaction ID:</b></span></td>
                                              <td>#<?php echo $sellEntry['sell_txn_no'];?></td>
                                            </tr>
                                            <tr>
                                              <td><span class="fieldlabel"><b> Sell Date:</b></span></td>
                                              <td><?php echo $sellEntry['sell_date'];?></td>
                                            </tr>
                                         
                                            <tr>
                                              <td><span class="fieldlabel"><b>Machine Code:</b></span></td>
                                              <td><?php echo $sellEntry['machine_code'];?></td>
                                            </tr>
                                            <tr>
                                              <td><span class="fieldlabel"><b>Sell-UOM:</b></span></td>
                                              <td><?php echo $sellEntry['sell_uom'];?></td>
                                            </tr>
                                           
                                            <tr>
                                              <td><span class="fieldlabel"><b>Customer Name:</b></span></td>
                                              <td><?php echo $sellEntry['customer_firstname'];?>&nbsp;<?php echo $sellEntry['customer_lastname'];?></td>
                                            </tr>
											<tr>
                                              <td><span class="fieldlabel"><b>Sell-Amount:</b></span></td>
                                              <td><?php echo $sellEntry['sell_amount'];?></td>
                                            </tr>
                                           <tr>
                                              <td><span class="fieldlabel"><b>Sell-Quantity:</b></span></td>
                                              <td><?php echo $sellEntry['sell_qty'];?></td>
                                            </tr>
                                           
                                          
                                          
                                           
                                            <tr>
                                              <td><span class="fieldlabel"><b>Status:</b></span></td>
                                              <td><?php echo $asset['SD_Active'][1];?></td>
                                            </tr>
                                          </tbody>
                                        </table>
                                      </div>
                                    </div>
                                  </div>
                                  <div class="modal-footer">
                                        
                                          <a href="<?php echo base_url();?>admin/sell/edit/<?php echo $sellEntry['sell_id'];?>" class="btn">Edit</a>
                                      
                                      <a href="#" class="btn" data-dismiss="modal">Close</a>
                                  </div>
                                </div>
                              </div>
					
                              </td>
                          </tr>
                          <?php endforeach;?>
                          <?php endif;?>
                        </tbody>
                        <tfoot>
                          <tr>
                            <?php foreach ($this->sell->column_headers as $key => $val): ?>
                            <th><?php echo $key;?></th>
                            <?php endforeach;?>
							<th>Action</th>
                          </tr>
                        </tfoot>
                      </table>
                      <input type="hidden" name="action"/>
                      <input type="hidden" name="machineid"/>
                    </form>
                    <br />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<style type="text/css">
.control-partner.error td{color:#b94a48;}
.control-partner.success td{color:#468847;}
.control-partner.success label.valid 
{
    background: url('../img/valid.png') center center no-repeat;
    display: inline-block;
    text-indent: 45px;
}
</style>
<script type="text/javascript" charset="utf-8">

function fun_delete(field_value,status_value){
    $.ajax({
        url:"<?php echo base_url().'index.php/admin/sell/changeactivestatus/1/';?>",
        type:"POST",
        beforeSend: function(){
            var conform=confirm("Are you sure to delete this machine?");
            if(!conform){
                return false;
            }
        },
        data:{sell_id:field_value, sell_active:status_value},
        success:function(data){
            //alert(data);
            $('.delete-'+field_value).fadeOut('slow');
        }
    });
}
</script>


<?php $this->load->view('admin/footer');?>