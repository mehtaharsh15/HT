
<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');$this->load->view('admin/header');
global $asset; 

?>

<div id="content" class="span12 section-body">
  <?php if ($this->session->flashdata('notification')): ?>
  <div class="alert alert-success"> <a class="close" data-dismiss="alert" href="#">×</a>
    <?php echo $this->session->flashdata('notification');?> </div>
  <?php endif; ?>
  
  <div id="section-body" class="tabbable"> <!-- Only required for left/right tabs -->
    <ul class="nav nav-tabs">
      <li class="active"><a href="#tab1" data-toggle="tab">FAQ Listing</a></li>
   
            <li><a href="<?php echo base_url();?>admin/faq/insert" >Add New FAQ</a></li>
    
    </ul>
    <div class="tab-content">
      <div class="tab-pane active" id="tab1">
        <div class="row-fluid">
          <!--Tabs2-->
          <div class="span12">
            <div id="accordion1" class="accordion">
              <div class="accordion-partner">
                <div class="accordion-heading"> <a class="accordion-toggle" data-toggle="collapse" href="#notification" data-original-title=""> <i class="icon-user icon-white"></i> <span class="divider-vertical"></span>FAQ<i class="icon-chevron-down icon-white pull-right"></i> </a> 
				</div>
                <div id="notification" class="accordion-body collapse in">
                  <div class="accordion-inner paddind">
                    <form name="frmPartnerList" method="post" action="<?php echo base_url();?>admin/faq">
                      <table class="table table-bordered table-striped pull-left" id="example">
                        <thead>
                          <tr>
                            <?php foreach ($this->faq->column_headers as $key => $val): ?>
                            <th width="<?php echo $val;?>"><?php echo $key;?></th>
                            <?php endforeach;?>
                            <th width="20%">Action</th>
                          </tr>
                        </thead>
                        <tbody>
                          <?php if($faq_count == 0): ?>
                          <tr class="delete-0">
                            <td colspan="5" align="center">No FAQ found.</td>
                          </tr>
                          <?php else: ?>
                          <?php foreach($faq_entry as $faqEntry):?>
                          <tr class="delete-<?php echo $faqEntry['faq_id'];?>">
                            <td><?php echo $faqEntry['faq_question'];?></td>
                            <td><?php echo $faqEntry['faq_answer'];?></td>
                           
                         
                            <td align="center" width="10%">
                            <div>
                                <input type="hidden" name="faq_id" value="<?php echo $faqEntry['faq_id'];?>">
                             
                                    <a data-original-title="Edit" href="<?php echo base_url()?>admin/faq/edit/<?php echo $faqEntry['faq_id']?>" class="tooltip-top btn"><i class="icon-edit"></i></a>
                                    &nbsp;
                               
                                    <a class="tooltip-top btn" data-original-title="Delete" onClick="faq_delete('<?php echo $faqEntry['faq_id'];?>','<?php echo $faqEntry['faq_active']?0:$faqEntry['faq_active'];?>');">
									<i class="icon-trash" style="cursor: pointer"></i></a>
                               
                                &nbsp;
                              </div>
                             </td>
                          </tr>
                          <?php endforeach;?>
                          <?php endif;?>
                        </tbody>
                        <tfoot>
                          <tr>
                            <?php foreach ($this->faq->column_headers as $key => $val): ?>
                            <th><?php echo $key;?></th>
                            <?php endforeach;?>
                            <th>Action</th>
                          </tr>
                        </tfoot>
                      </table>
                      <input type="hidden" name="action"/>
                      <input type="hidden" name="faqid"/>
                    </form>
                    <br />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<style type="text/css">
.control-partner.error td{color:#b94a48;}
.control-partner.success td{color:#468847;}
.control-partner.success label.valid 
{
    background: url('../img/valid.png') center center no-repeat;
    display: inline-block;
    text-indent: 45px;
}
</style>
<script type="text/javascript" charset="utf-8">

function faq_delete(field_value,status_value){
		
    $.ajax({
	
        url:"<?php echo base_url().'index.php/admin/faq/changeactivestatus/1/';?>",
        type:"POST",
        beforeSend: function(){
            var conform=confirm("Are you sure to delete this faq?");
            if(!conform){
                return false;
            }
        },
        data:{faq_id:field_value, faq_active:status_value},
        success:function(data){
            //alert(data);
            $('.delete-'+field_value).fadeOut('slow');
        }
    });
}
</script>


<?php $this->load->view('admin/footer');?>