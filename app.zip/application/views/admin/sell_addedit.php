<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');$this->load->view('admin/header');
global $asset;
?>
<!--<link href="<?php echo base_url().$this->config->item('stylesheet_path');?>css.css" media="screen" rel="stylesheet" type="text/css" />-->
<div id="content" class="span12 section-body">
	<?php if (isset($machineMsg) && !empty($machineMsg)): ?>
      <div class="alert alert-error">
          <a class="close" data-dismiss="alert" href="#">×</a>
          <?php //echo $this->session->flashdata('notification');?> <?php echo $machineMsg;?>
      </div>
    <?php endif; ?>
  <div id="section-body" class="tabbable"> <!-- Only required for left/right tabs -->
    <ul class="nav nav-tabs">
      <li><a href="<?php echo base_url()?>admin/sell/index" >Sell Listing</a></li>
    
      <?php if($this->uri->segment(3) == 'edit'):?>
      <li class="active"><a href="#tab1" data-toggle="tab" >Edit Sell</a></li>
      <?php endif;?>
    </ul>
    <div class="tab-content">
      <div class="tab-pane active" id="tab1">
        <div class="row-fluid"> 
          <!--Tabs2-->
          <div class="span12">
            <div id="accordion1" class="accordion">
              <div class="accordion-partner">
                <div class="accordion-heading"> <a class="accordion-toggle" data-toggle="collapse" href="#notification" data-original-title=""> <i class="icon-user icon-white"></i> <span class="divider-vertical"></span>
                  <?php if($this->uri->segment(3) == 'edit'): echo "Edit Sell"; else: echo "Add New Sell"; endif;?>
                  <i class="icon-chevron-down icon-white pull-right"></i> </a> </div>
                <div id="notification" class="accordion-body collapse in">
                  <div class="accordion-inner paddind">
                    <div class="mandatory-note">
                      Fields marked with * are mandatory.
                      <br/>
                    </div>
					  <?php foreach($sell_edit_entry as $row):?>
                    <form name="frmpartner" id="form" action="<?php if($this->uri->segment(3) == 'insert'): ?><?php echo base_url();?>admin/sell/insert<?php else: ?><?php echo base_url();?>admin/sell/edit<?php endif; ?>" method="post" enctype="multipart/form-data">
                      <table class="table table-bordered table-striped pull-left">
                        <tbody>
						 <tr class="control-partner">
                            <td class="control-label"><span class="fieldlabel"><span class="mandatory-star">*</span>Txn-No:</span></td>
                            <td class="controls">
                              <input type="text" class="required" required maxlength="15" name="machine_code" id="machine_code" 
							  value="#<?php echo $row['sell_txn_no'];?>" readonly />
                            </td>
                          </tr>
						  
						  
						
						
						
                          <tr class="control-partner">
                            <td class="control-label"><span class="fieldlabel"><span class="mandatory-star">*</span>Date:</span></td>
                            <td class="controls">
                              <input type="text" class="required" required maxlength="150" name="sell_date" id="sell_date"
							  value="<?php echo $row['sell_date'];?>" readonly />
                            </td>
                          </tr>
						  
						  
						   <tr class="control-partner">
                            <td class="control-label"><span class="fieldlabel"><span class="mandatory-star">*</span>UOM:</span></td>
                            <td class="controls">
                              <input type="text" class="required" required maxlength="15" name="sell_uom" id="sell_uom" 
							  value="<?php echo $row['sell_uom'];?>" readonly />
                            </td>
                          </tr>
						  
						   <tr class="control-partner">
                            <td class="control-label"><span class="fieldlabel"><span class="mandatory-star">*</span>Customer Name:</span></td>
                            <td class="controls">
                              <input type="text" class="required" required maxlength="15" name="customer_name" id="customer_name" 
							  value="<?php echo $row['customer_firstname']. " ".$row['customer_lastname'];?>" readonly />
                            </td>
                          </tr>
						  
                          <tr class="control-partner">
                            <td class="control-label"><span class="fieldlabel"><span class="mandatory-star">*</span>Machine Code:</span></td>
                            <td class="controls">
                              <input type="text" class="required" required maxlength="15" name="machine_code" id="machine_code" 
							  value="<?php echo $row['machine_code'];?>" readonly />
                            </td>
                          </tr>
                        
                        
                          <tr class="control-partner">
                            <td class="control-label"><span class="fieldlabel"><span class="mandatory-star">*</span>Amount:</span></td>
                            <td class="controls"><input type="text" class="required" required maxlength="20" name="sell_amount" id="sell_amount"
							value="<?php echo $row['sell_amount']; ?>" readonly ></td>
                          </tr>
                        
                          <tr class="control-partner">
                            <td class="control-label"><span class="fieldlabel"><span class="mandatory-star">*</span>Quantity:</span></td>
                            <td class="controls"><input type="text" class="required" required maxlength="20" name="sell_qty" id="sell_qty"
							value="<?php echo $row['sell_qty']; ?>" readonly ></td>
                          </tr>
                        
                        
                          <?php endforeach;?>
                    
                           
                       
                       
                          <tr>
                          	<td>&nbsp;</td>
                            <td class="stdLabel" style="text-align:left;"><input readonly type="submit" name="submit" class="btn btn-primary" value="<?php if($this->uri->segment(3) == 'insert'): ?>Save<?php else: ?>Update<?php endif; ?>" />
                              &nbsp;&nbsp;
                              <input type="button" name="cancel" class="btn" value="Cancel"  onclick="location.href='<?php echo base_url();?>admin/sell/index/'"/></td>
                          </tr>
                        </tbody>
                      </table>
                      <input type="hidden" name="machine_id" id="machine_id" value="<?php echo $row['machine_id'];?>" />
                    </form>
                    <br />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<?php $this->load->view('admin/footer');?>
