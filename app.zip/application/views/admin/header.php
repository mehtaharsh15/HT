<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title><?php echo $this->system->site_name; ?> - 
<?php if($title):echo $title; else: echo "No Access"; endif;?>
</title>
<?php //echo $this->system->admin_additional_meta_tag; ?>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="keywords" 		content="<?php echo $this->system->admin_meta_keyword; ?>" />
<meta name="description" 	content="<?php echo $this->system->admin_meta_description; ?>" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>
<meta name="author" content="">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="icon" href="<?php echo base_url()?>favicon.ico" type="image/x-icon" />


<!-- Le styles -->
<link href="<?php echo base_url()?>assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link class="links-css" href="<?php echo base_url()?>assets/bootstrap/css/style.css" rel="stylesheet">
<link href="<?php echo base_url()?>assets/bootstrap/css/datepicker.css" rel="stylesheet"/>
<link href="<?php echo base_url()?>assets/bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet">
<link href="<?php echo base_url()?>assets/bootstrap/css/media-fluid.css" rel="stylesheet">
<link href="<?php echo base_url()?>assets/js/jquery/duplicate-remove/jquery.duplicate-remove.css" rel="stylesheet">

<!-- Load Additional CSS -->
<?php if($CssFiles): ?>
<?php $i = 1; foreach ($CssFiles as $CssFile): ?>
<link href="<?php echo base_url().$this->config->item('stylesheet_path').$CssFile;?>" rel="stylesheet">
<?php $i++; endforeach;?>
<?php endif; ?>

<script src="<?php echo base_url()?>assets/bootstrap/js/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo base_url().$this->config->item('javascript_path');?>bootstrap-datepicker.js"></script>
<script type="text/javascript" src="<?php echo base_url().$this->config->item('javascript_path');?>bootstrap-timepicker.min.js"></script>





<!--Start:  Addidonal Jquery and CSS Fancy Box For QR Code-->

<script src="<?php echo base_url()?>assets/js/fancybox/lib/jquery.mousewheel-3.0.6.pack.js"></script>
<!--<script src="<?php //echo base_url()?>assets/js/fancybox/lib/jquery-1.9.0.min.js"></script>-->
<script src="<?php echo base_url()?>assets/js/fancybox/lib/jquery-1.10.1.min.js"></script>


<link href="<?php echo base_url()?>assets/js/fancybox/source/jquery.fancybox.css" rel="stylesheet">
<script src="<?php echo base_url()?>assets/js/fancybox/source/jquery.fancybox.pack.js"></script>
<script src="<?php echo base_url()?>assets/js/fancybox/source/jquery.fancybox.js"></script>


<script src="<?php echo base_url()?>assets/js/fancybox/source/helpers/jquery.fancybox-thumbs.js"></script>
<link href="<?php echo base_url()?>assets/js/fancybox/source/helpers/jquery.fancybox-thumbs.css" rel="stylesheet">
<script src="<?php echo base_url()?>assets/js/fancybox/source/helpers/jquery.fancybox-buttons.js"></script>

<link href="<?php echo base_url()?>assets/js/fancybox/source/helpers/jquery.fancybox-buttons.css" rel="stylesheet">

<script src="<?php echo base_url()?>assets/js/fancybox/source/helpers/jquery.fancybox-media.js"></script>
 <script src="<?php echo base_url()?>assets/js/validate.js"></script>


 <script type="text/javascript">
	$(document).ready(function() {
		$(".fancybox").fancybox({
			'width'				: '35%',
			'height'			: '5%',
			'autoScale'			: true,
			'transitionIn'		: 'none',
			'transitionOut'		: 'none',
			'arrows'		    : false,
			'position'		    : 'absolute',
			 'type'				: 'iframe'
		});
	});
</script>
<!-- End :  Addidonal Jquery and CSS Fancy Box For QR Code -->


<!-- Start :  For Datatables Addidonal Jquery and CSS  -->
<script src="<?php echo base_url()?>assets/datatables/js/jquery.dataTables.min.js"</script>
<!-- End : Datatables Addidonal Jquery and CSS -->


<script type="text/javascript">
var baseurl = "<?php echo base_url();?>";
</script>
</head>
<body>
<?php if(!$hideMenu){?>
<?php if ($this->user->logged_in): ?>
<div class="navbar navbar-fixed-top">
  <div class="navbar-inner">
    <div class="container-fluid"> <a class="btn btn-navbar admininfo"> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar">
	</span> </a> <a class="brand" href="<?php echo base_url();?>admin/home">
	<?php echo $this->system->site_name; ?></a>
      
      <?php
            $usergroupid=$this->session->userdata('user_group_id');
            $userid=$this->session->userdata('id');
            $userdetail=$this->common->getUserDetail($userid);
            $usergroupdetail=$this->common->getUserGroupDetail($usergroupid);
        ?>
      <div class="group-menu nav-collapse admininfo-block">
        <ul class="nav pull-right">
          <li class="dropdown"> <a data-toggle="dropdown" href="#" class="adminlink"><i class="icon-user icon-white"></i> <?php echo $this->user->username;?><b class="caret"></b></a>
            <ul class="dropdown-menu">
              <li>
                <div class="modal-header">
                  <h4 style="margin:0px; padding:0px;"><div id="loggedinuser"><?php echo $userdetail[0]['user_firstname']." ".$userdetail[0]['user_lastname'];?></div> - <?php  echo $usergroupdetail[0]['user_group_name'];?></h4>
                </div>
                <div class="modal-body">
                    <!--<div class="span1"><img src="<?php echo base_url()?>assets/bootstrap/img/avatar/photo.png" alt="avatar" /></div>-->
                    <p><?php  echo $userdetail[0]['user_email'];?></p>
                    <?php if(!$forcepasswordchange){?>
                        <a href="<?php echo base_url()."admin/changepassword"; ?>" class="link-modal"> Change Password </a>   
                    <?php } ?>
                </div>
                <div class="modal-footer"> <!--<a href="<?php //echo base_url()."admin/users/edit/".$this->user->id; ?>" class="btn btn-info pull-left">Edit My Profile</a>--> <a class="btn btn-small btn-danger" href="<?php echo base_url()."admin/logout"; ?>"><i class="icon-off icon-white"></i> Logout</a> </div>
              </li>
            </ul>
          </li>
        </ul>
      </div>
    </div>
  </div>
  <?php if(!$forcepasswordchange)$this->load->view('admin/menu');?>
</div>
<div class="container-fluid">
<div class="row-fluid">
<?php endif; ?>
<?php }?>
