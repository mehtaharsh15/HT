<?php
if(!defined('BASEPATH'))
	exit('No direct script access allowed');

$this->load->view('admin/header');
?>
<?php $this->load->view($view);?>
<?php if(!$hideMenu){?>
    <?php $this->load->view('admin/footer');?>
<?php }?>
