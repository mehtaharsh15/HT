<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); $this->load->view('admin/header');?>
<div id="content" class="span12 section-body">
  <?php if ($this->session->flashdata('notification')): ?>
  <div class="alert alert-success"> <a class="close" data-dismiss="alert" href="#">×</a>
    <?php echo $this->session->flashdata('notification');?> </div>
  <?php endif; ?>
  <div id="section-body" class="tabbable"> <!-- Only required for left/right tabs -->
    <ul class="nav nav-tabs">
      <li class="active"><a href="#tab1" data-toggle="tab">Change Password</a></li>
    </ul>
    <div class="tab-content">
      <div class="tab-pane active" id="tab1">
        <div class="row-fluid"> 
          <!--Tabs2-->
          <form name="frmchangepwd" id="frmchangepwd" action="<?php echo base_url();?>admin/changepassword/change" method="post" enctype="multipart/form-data">
            <div class="span12">
              <div id="accordion1" class="accordion">
                <div class="accordion-group">
                  <div class="accordion-heading"> <a class="accordion-toggle" data-toggle="collapse" href="#notification" data-original-title=""> <i class="icon-th icon-white"></i> <span class="divider-vertical"></span> Change Password <i class="icon-chevron-down icon-white pull-right"></i> </a> </div>
                  <div id="notification" class="accordion-body collapse in">
                    <div class="accordion-inner paddind">
                      <table width="100%" align="center" cellspacing="1" cellpadding="4" class="table table-striped table-bordered table-condensed" style="margin-top: 40px;">
                        <tr>
                          <td><span class="fieldlabel">Login Id :</span></td>
                          <td><input type=text name="login_id" readonly size="30" value="<?php echo $this->user->username?>"></td>
                        </tr>
                        <tr>
                          <td><span class="fieldlabel">Old Password :</span></td>
                          <td valign="middle"><input type="password" name="o_password" id="o_password" size="30" ></td>
                        </tr>
                        <tr>
                          <td><span class="fieldlabel">New Password :</span></td>
                          <td valign="middle"><input type="password" name="n_password" id="n_password" size="30" maxlength="20"></td>
                        </tr>
                        <tr>
                          <td><span class="fieldlabel">Confirm Password :</span></td>
                          <td valign="middle"><input type="password" style="color:#000000;" name="c_password" id="c_password" size="30" ></td>
                        </tr>
                        <tr>
                          <td colspan="2" class="stdLabel" style="text-align:center;"><input type="submit" name="submit" class="btn btn-primary" value="Update" />
                            &nbsp;&nbsp;
                            <input type="button" name="cancel" class="btn" value="Cancel" onclick="location.href='<?php echo base_url()?>admin/home/'"  /></td>
                        </tr>
                      </table>
                      <br />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript">
$().ready(function() {
	// validate signup form on keyup and submit
	$("#frmchangepwd").validate({
		rules: {
			o_password: {
				required: true,
				minlength: 6
			},
			n_password: {
				required: true,
				minlength: 6
			},
			c_password: {
				required: true,
				minlength: 6,
				equalTo: "#n_password"
			}
		},
		messages: {
			o_password: {
				required: "Please enter your old password",
				minlength: "Your password must consist of at least 6 characters"
			},
			n_password: {
				required: "Please provide a password",
				minlength: "Your password must be at least 6 characters long"
			},
			c_password: {
				required: "Please provide a confirm password",
				minlength: "Your password must be at least 6 characters long",
				equalTo: "Please enter the same password as above"
			}
		}
	});
});
</script>
<style>
.password {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 11px;
	color: #000000;
}
.pstrength-minchar {
	font-size : 11px;
}
#o_password, #n_password, #c_password {
	color: #000000;
	font-size: 11px;
}
</style>
<?php $this->load->view('admin/footer');?>