<?php
if(!defined('BASEPATH'))
	exit('No direct script access allowed');

$this->load->view('admin/header');
?>

<font face="Algerian" size="6px">W</font><font face="verdana">elcome To <strong>Hi-Tech</strong> Wallet App</font><br>
 
 <!-- <img src="<?//php echo base_url().$this->config->item('image_path');?>admin/HT_n.jpg">  -->

<?php $this->load->view('admin/footer');?>
</body>	
</html>