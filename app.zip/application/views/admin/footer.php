<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); if ($this->user->logged_in): ?>
</div>
</div>
<footer>
	<div class="footer">
      	    <div id="copyright">Copyright &copy; 2016 hitechwallet<?php //echo $this->system->company_copyright?></div>
      		<div id="poweredby">&nbsp;
			<?php echo $this->system->company_powerby?> </div>
  	</div>
</footer>
<?php endif; ?>

<!-- Placed at the end of the document so the pages load faster --> 

<script src="<?php echo base_url()?>assets/bootstrap/js/jquery-ui.min.js"></script> 
<script src="<?php echo base_url()?>assets/bootstrap/js/bootstrap.min.js"></script> 
<script src="<?php echo base_url()?>assets/bootstrap/js/highcharts.js"></script> 

<script type="text/javascript" src="<?php echo base_url().$this->config->item('javascript_path');?>jquery/jquery.validate.min.js"></script>
<script type="text/javascript" src="<?php echo base_url().$this->config->item('javascript_path');?>jquery/additional-methods.min.js"></script>
<!-- Load Additional JS -->
<?php if($js): ?>
<?php $i = 1; foreach ($js as $JSFile): ?>
<script type="text/javascript" src="<?php echo base_url().$this->config->item('javascript_path').$JSFile;?>"></script>
<?php $i++; endforeach;?>
<?php endif; ?>
<script type="text/javascript">
$(document).ready(function(){
    $('.admininfo').click(function(){
        $('.admininfo-block').toggleClass('autoheight');
    });
    $('.togglemenuleft').click(function(){
        $('#menu-left, .sidebar-nav').toggleClass('span1');
        $('#menu-left, .sidebar-nav').toggleClass('icons-only');
        $('#menu-left, .sidebar-nav').toggleClass('span3');
        $('#content').toggleClass('span9');
        $('#content').toggleClass('span11');
        $(this).find('i').toggleClass('icon-circle-arrow-right');
        $(this).find('i').toggleClass('icon-circle-arrow-left');
        $('#menu-left').find('span').toggle();
        $('#menu-left').find('.dropdown').toggle();
    });

    $('#menu-left a').click(function(){
        $('#menu-left').find('a').removeClass('active');
        $(this).addClass('active');
    });
    $('a').tooltip('hide');
    $('a.style').click(function(){
        var style = $(this).attr('href');
        $('.links-css').attr('href','css/' + style);
        return false;
    });
    $('#example').dataTable({_MENU_:'Page Size'});
});
</script>
<script type="text/javascript">
$(function() {
        setTimeout(function() {
                $(".alert").hide('blind', {}, 500)
        }, 3000);
});
</script>
</body>
</html>