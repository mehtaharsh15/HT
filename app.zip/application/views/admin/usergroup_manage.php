<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); $this->load->view('admin/header');?>
<div id="content" class="span12 section-body">
  <?php if ($this->session->flashdata('notification')): ?>
  <div class="alert alert-success"> <a class="close" data-dismiss="alert" href="#">×</a>
    <?php echo $this->session->flashdata('notification');?> </div>
  <?php endif; ?>
  <div id="section-body" class="tabbable"> <!-- Only required for left/right tabs -->
    <ul class="nav nav-tabs">
      <li class="active"><a href="#tab1" data-toggle="tab">User Group Manager</a></li>
    <?php
        /*if($this->common->admin_permission('UserGroups_Add','Manage_Users','User_Groups',TRUE))
        {*/
    ?>
          <li><a href="<?php echo base_url()?>admin/usergroup/insert" >Add New User Group</a></li>
    <?php
        //}
    ?>
    </ul>
    <div class="tab-content">
      <div class="tab-pane active" id="tab1">
        <div class="row-fluid"> 
          <!--Tabs2-->
          <div class="span12">
            <div id="accordion1" class="accordion">
              <div class="accordion-group">
                <div class="accordion-heading"> <a class="accordion-toggle" data-toggle="collapse" href="#notification" data-original-title=""> <i class="icon-th icon-white"></i> <span class="divider-vertical"></span> User Group Manager <i class="icon-chevron-down icon-white pull-right"></i> </a> </div>
                <div id="notification" class="accordion-body collapse in">
                  <div class="accordion-inner paddind">
                    <form name="frmusergrouplist" method="post" action="<?php echo base_url()?>admin/usergroup">
                      <table class="table table-bordered table-striped pull-left" id="example">
                        <thead>
                          <tr>
                            <?php foreach ($this->usergroup->column_headers as $key => $val): ?>
                            <th><?php echo $key?></th>
                            <?php endforeach;?>
                            <th>Action</th>
                          </tr>
                        </thead>
                        <tbody>
                          <?php if($usergroup_count == 0): ?>
                          <tr>
                            <td colspan="7" align="center">No User Group Found.</td>
                          </tr>
                          <?php else: ?>
                          <?php foreach($usergroup_entry as $usergroupentry):?>
                          <tr class="delete-<?php echo $usergroupentry['user_group_id'];?>">
                            <td><?php echo $usergroupentry['user_group_name'];?></td>
                            <td align="center" width="25%">
                                <div>
                                    <a data-toggle="modal" href="#myModal<?php echo $usergroupentry['user_group_id']?>" class="tooltip-top btn" data-original-title="View">
                                    <i class="icon-eye-open"></i>
                                    </a>&nbsp;
                                    <?php if($this->user->user_group_id != 1)
                                            {
                                                if(!$usergroupentry['user_group_default']):?>
                                                <?php
                                                    /*if($this->common->admin_permission('UserGroups_Edit','Manage_Users','User_Groups',TRUE))
                                                    {*/
                                                ?>
                                                        <a href="<?php echo base_url()?>admin/usergroup/edit/<?php echo $usergroupentry['user_group_id']?>" class="tooltip-top btn" data-original-title="Edit">
                                                        <i class="icon-edit"></i>
                                                        </a>&nbsp;
                                                <?php
                                                    //}
                                                    /*if($this->common->admin_permission('UserGroups_Edit','Manage_Users','User_Groups',TRUE))
                                                    {*/
                                                ?>
                                                        <a class="tooltip-top btn" data-original-title="Delete" onClick="fun_delete('<?php echo $usergroupentry['user_group_id']; ?>','<?php echo $usergroupentry['user_group_active']?0:$usergroupentry['user_group_active'];?>');">
                                                        <i class="icon-trash" style="cursor: pointer"></i>
                                                        </a>
                                                <?php
                                                    //}
                                                endif;
                                            }
                                            else
                                            {
                                            ?>
                                                <a href="<?php echo base_url()?>admin/usergroup/edit/<?php echo $usergroupentry['user_group_id']?>" class="tooltip-top btn" data-original-title="Edit">
                                                <i class="icon-edit"></i>
                                                </a>&nbsp;
                                            <?php
                                                if(!$usergroupentry['user_group_default']):
                                            ?>
                                                <a class="tooltip-top btn" data-original-title="Delete" onClick="fun_delete('<?php echo $usergroupentry['user_group_id']; ?>','<?php echo $usergroupentry['user_group_active']?0:$usergroupentry['user_group_active'];?>');">
                                                <i class="icon-trash" style="cursor: pointer"></i>
                                                </a>
                                            <?php
                                                endif;
                                            }
                                            ?>
                                </div>
                              <div id="myModal<?php echo $usergroupentry['user_group_id']?>" class="modal hide fade">
                                <div class="modal-header">
                                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                                  <h3>User Group</h3>
                                </div>
                                <div class="modal-body" id="result">
                                  <div id="accordion2" class="accordion">
                                    <div class="accordion-heading"> <a href="#widget-tabs<?php echo $usergroupentry['user_group_id']?>" data-toggle="collapse" class="accordion-toggle in"> <i class="icon-user icon-white"></i> <span class="divider-vertical"></span> <?php echo $usergroupentry['user_group_name'];?><i class="icon-chevron-down icon-white pull-right"></i> </a> </div>
                                    <div class="accordion-body collapse in" id="widget-tabs<?php echo $usergroupentry['user_group_id']?>">
                                      <div class="accordion-inner">
                                        <table class="table table-striped" width="90%">
                                          <tbody>
                                            <tr>
                                              <td>
                                                  <b>Group Name:</b>
                                                  <?php if($usergroupentry['user_group_name']==NULL): echo "No User Group Avilable"; else:echo $usergroupentry['user_group_name']; endif;?>
                                              </td>
                                            </tr>
                                            <tr>
                                              <td><!--<span class="fieldlabel">--><b>Management:</b><!--</span>--><br/><br/>
                                                 <table class="table table-striped table-bordered table-condensed">
                                                    <?php
                                                    $obj= json_decode($usergroupentry['user_group_privileges']);
                                                    $group_obj= json_decode($usergroupentry['user_group_privileges']);
                                                    global $asset;
                                                    foreach ($asset['SD_UserGroup_Permissions'] as $key => $value):
                                                        ?>
                                                        <tr>
                                                            <td width="30%">
                                                                <label class="checkbox">
                                                                    <input type="checkbox" id="user_group_privileges[<?php echo $key; ?>][module]" name="user_group_privileges[<?php echo $key; ?>][module]" size="42" value="<?php echo $key; ?>" <?php if ($obj->user_group_privileges->$key) echo "checked"; ?> disabled/>
                                                                    <?php echo $value['Title']; ?>
                                                                </label>
                                                            </td>
                                                            <td>
                                                                <?php
                                                                if (is_array($value) && $key != 'Submenu') {
                                                                    foreach ($value as $k => $v) {
                                                                        if (is_array($v) && $k != 'Submenu') {
                                                                            ?>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>
                                                                            <label class="checkbox ">
                                                                                <input type="checkbox" id="user_group_privileges[<?php echo $key; ?>][<?php echo $k; ?>][module]" name="user_group_privileges[<?php echo $key; ?>][<?php echo $k; ?>][module]" size="42" value="<?php echo $k; ?>" <?php if ($obj->user_group_privileges->$key->$k) echo "checked"; ?> disabled/>
                                                                                &nbsp;&nbsp;&nbsp;&nbsp;|---
                                                                                <?php echo $v['Title']; ?>
                                                                            </label>
                                                                        </td>
                                                                        <td>
                                                                            <?php
                                                                            foreach ($v as $k1 => $v1) {
                                                                                if (is_array($v1) && $k1 != 'Submenu') {
                                                                                    ?>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td>
                                                                                    <label class="checkbox">
                                                                                        <input type="checkbox" id="user_group_privileges[<?php echo $key; ?>][<?php echo $k; ?>][<?php echo $k1; ?>]" name="user_group_privileges[<?php echo $key; ?>][<?php echo $k; ?>][<?php echo $k1; ?>]" size="42" value="<?php echo $k1; ?>" <?php if ($obj->user_group_privileges->$key->$k->$k1) echo "checked"; ?> disabled/>
                                                                                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;|---
                                                                                        <?php echo $k1; ?>
                                                                                    </label>
                                                                                </td>
                                                                                <td>
                                                                                    <?php
                                                                                    foreach ($v1 as $k2 => $v2) {
                                                                                        if ($k2 != 'Title' && $k1 != 'Link' && $k1 != 'Icon' && $key != 'Submenu') {
                                                                                            ?>
                                                                                            <label class="checkbox permissionRadio">
                                                                                                <input type="checkbox" id="user_group_privileges[<?php echo $key; ?>][<?php echo $k; ?>][<?php echo $k1; ?>][permissions][<?php echo $k2; ?>]" name="user_group_privileges[<?php echo $key; ?>][<?php echo $k; ?>][<?php echo $k1; ?>][permissions][<?php echo $k2; ?>]" size="42" value="<?php echo $k2; ?>" <?php if ($obj->user_group_privileges->$key->$k->$k1->permissions->$k2) echo "checked"; ?> disabled/>
                                                                                                <?php echo $v2; ?>
                                                                                            </label>
                                                                                            <?php
                                                                                        }
                                                                                    }
                                                                                }
                                                                                elseif ($k1 != 'Title' && $k1 != 'Link' && $k1 != 'Icon' && $key != 'Submenu') {
                                                                                    ?>
                                                                                    <label class="checkbox permissionRadio">
                                                                                        <input type="checkbox" id="user_group_privileges[<?php echo $key; ?>][<?php echo $k; ?>][permissions][<?php echo $k1; ?>]" name="user_group_privileges[<?php echo $key; ?>][<?php echo $k; ?>][permissions][<?php echo $k1; ?>]" size="42" value="<?php echo $v1; ?>" <?php if ($obj->user_group_privileges->$key->$k->permissions->$k1) echo "checked"; ?> disabled/>
                                                                                        <?php echo $v1; ?>
                                                                                    </label>
                                                                                    <?php
                                                                                }
                                                                            }
                                                                        }
                                                                        elseif ($k != 'Title' && $k != 'Link' && $k != 'Icon' && $k != 'Submenu') {
                                                                            ?>
                                                                            <label class="checkbox permissionRadio">
                                                                                <input type="checkbox" id="user_group_privileges[<?php echo $key; ?>][permissions][<?php echo $k; ?>]" name="user_group_privileges[<?php echo $key; ?>][permissions][<?php echo $k; ?>]" size="42" value="<?php echo $v; ?>" <?php if ($obj->user_group_privileges->$key->permissions->$k) echo "checked"; ?> disabled>
                                                                                <?php echo $v; ?>
                                                                            </label>
                                                                            <?php
                                                                        }
                                                                    }
                                                                }
                                                                elseif ($key != 'Title' && $key != 'Link' && $key != 'Icon' && $key != 'Submenu') {
                                                                    ?>
                                                                    <label class="checkbox permissionRadio">
                                                                        <input type="checkbox" id="user_group_privileges[<?php echo $key; ?>][permissions]" name="user_group_privileges[<?php echo $key; ?>][permissions]" size="42" value="<?php echo $value; ?>" <?php if ($obj->user_group_privileges->$key) echo "checked"; ?> disabled/>
                                                                        <?php echo $value; ?>
                                                                    </label>
                                                                    <?php
                                                                }
                                                                ?>
                                                            </td>
                                                        </tr>
                                                    <?php endforeach; ?>
                                                </table>
                                                </td>
                                            </tr>
                                          </tbody>
                                        </table>
                                      </div>
                                    </div>
                                  </div>
                                  <div class="modal-footer">
                                    <?php
                                        /*if($this->common->admin_permission('UserGroups_Edit','Manage_Users','User_Groups',TRUE))
                                        {*/
                                    ?>
                                      <?php //if(!$usergroupentry['user_group_default']):?>
                                          <a href="<?php echo base_url()?>admin/usergroup/edit/<?php echo $usergroupentry['user_group_id']?>" class="btn">Edit</a>
                                   <?php //endif;
                                        //}
                                    ?>
                                  <a href="#" class="btn" data-dismiss="modal">Close</a>
                                  </div>
                                </div>
                              </div></td>
                          </tr>
                          <?php  endforeach;?>
                          <?php endif; ?>
                        </tbody>
                        <tfoot>
                          <tr>
                            <?php foreach ($this->usergroup->column_headers as $key => $val): ?>
                            <th><?php echo $key?></th>
                            <?php endforeach;?>
                            <th>Action</th>
                          </tr>
                          </tr>
                        </tfoot>
                      </table>
                      <input type="hidden" name="action" />
                      <input type="hidden" name="usergroupid" />
                      <input type="hidden" name="publish" />
                      <input type="hidden" name="user_privileges" />
                    </form>
                    <br />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript" charset="utf-8">
function fun_delete(field_value, status_value){
    $.ajax({
        url:"<?php echo base_url().'index.php/admin/usergroup/changeactivestatus/1/';?>",
        type:"POST",
        beforeSend: function(){
            var conform=confirm("Are you sure to delete this user?");
            if(!conform){
                    return false;
            }
        },
        data:{user_group_id:field_value, user_group_active:status_value},
        success:function(data){
                    $('.delete-'+data).fadeOut('slow');
        }
    });
}
</script>
<?php $this->load->view('admin/footer');?>