<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Cron extends CI_Controller
{
    function Cron()
    {
        parent :: __construct();
    }
    function index()
    {
    }
    //This function releases the patient items locked but idle
    //This cron is set to run at every 5 minutes
    function releasePatientLocks()
    {
        # loads required models
        $this->load->model('Patient_model', 'patient');

        $response	=	$this->patient->releaseLocks($this->system->lock_expiration_time);
        if($response)
            echo "Success";
        else
            echo "Failure";
    }
    //This function generates the daily report with # of requests, appointments and canceled
    //This cron is set to run at 1 AM daily
    function generateDailyReport()
    {
        # loads required models
        $this->load->model('Patient_model', 'patient');

        $response	=	$this->patient->prepareReport();
        if($response)
            echo "Report generated successfully.";
        else
            echo "Report generation failed.";
    }
    //This function generates the notifications for unread messages
    //This cron is set to run on hourly basis
    function sendMsgNotification()
    {
        # loads required models
        $this->load->model('Patient_model', 'patient');

        $response	=	$this->patient->sendNotification();
        if($response)
            echo "Notifications sent successfully.";
        else
            echo "No notifications are to be sent.";
            //echo "Notifications sending failed.";
    }
}
?>