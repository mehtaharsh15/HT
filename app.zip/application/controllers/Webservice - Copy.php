<?php
header('Access-Control-Allow-Origin: *');
defined('BASEPATH') OR exit('No direct script access allowed');
require APPPATH.'/libraries/REST_Controller.php';

class Webservice extends REST_Controller
{
    function Webservice()
    {
        parent :: __construct();
    }
	
    function register_get()
    {
		// load customer model to verify mobile no 
		//check requested mobile number exits or not. if not exit then register new customer other wise move to login page
		$this->load->model('customer_model', 'customer');
		
		//assign mobile no
		$mbl_no =  $this->get(mbl_no);
		
		//key value array of machine
		$customer_info = $this->customer->verify_customer_mobile($mbl_no);
		
		//define register array
		$register = array();
		
		//check customer info exits or not
		if($customer_info === TRUE) {
			$register['register'] = 'No';
		} else {
			//assign platform name, device uuid, device info			
			$platform = $this->get(platform);
			$device_uuid = $this->get(deviceid);
			$device_info = $this->get(deviceinfo);
			
			//register new customer 
			$inserted_id = $this->customer->Insert($mbl_no, $platform, $device_uuid, $device_info);
			//check customer id exits or not
			if(!empty($inserted_id)) {
				//assign already exits value to array
				$register['register'] = 'Yes';
			}
			
		}
		
		//$register = array('adsafsd');
		//check register array empty or not
        if($register)
        {
            $this->response($register, 200); // 200 being the HTTP response code
        }
        else
        {
            $this->response(array('error' => 'Couldn\'t find any $register!'), 404);
        }
    }
	/** purpose: get customer name base on mobile id
	*  @return customer first latter of customer fname and customer lname
	* 
*/
	/*function customername_get()
	{
		// check customer mobile number exits or not	
		if(!empty($this->get(mbl_no))) {
			
			//load customer model to edit profile
			$this->load->model('customer_model', 'customer');
			
			//edit customer info
			$customer_info = $this->customer->getcustomer_name($this->get(mbl_no));
			
			
		}
		else {
			 $this->response(array('error' => 'Couldn\'t find any $customer!'), 404);
		}	
	}*/
	
	
	/*function editprofile_get()
	{
		//check mobile number empty or not
		$customer = array();
		if(!empty($this->get(mbl_no))) {
			//assign mobile no,email, fname,lname
			$mbl_no = $this->get(mbl_no);
			$email = $this->get(email);
			
			//load customer model to edit profile
			$this->load->model('customer_model', 'customer');
			
			//edit customer info
			$customer_info = $this->customer->update_profile($mbl_no, $email, $fname, $lname);
			//set succsess/error message base on info
			if($customer_info) {
				$customer['msg'] = "Profile has been updated succsessfully!!";
			} else{
				$customer['msg'] = "There was an error while updateing your profile";
			}
			
			if($customer)
	        {
	            $this->response($customer, 200); // 200 being the HTTP response code
	        }
	        else
	        {
	            $this->response(array('error' => 'Couldn\'t find any $customer!'), 404);
	        }	
			
		} else {
			 $this->response(array('error' => 'Couldn\'t find any $customer!'), 404);
		}
		
	}*/
 }
?>