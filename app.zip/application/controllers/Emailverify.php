<?php if(!defined('BASEPATH')) exit('No direct script access allowed');
class Emailverify extends CI_Controller {
    function Emailverify()
    {
        parent :: __construct();        
    }

    function index($sign_to_verify='')
	{
		$pattern_flag = FALSE;
		//check string empty or not
		if(!empty($sign_to_verify)){
			
			$authenticate_string = base64_decode($sign_to_verify);
			//decode string
			$cust_array = json_decode($authenticate_string,TRUE);
			
			//check array empty or not
			if(is_array($cust_array) && count($cust_array) >0){
				
				//print_r($cust_array);die;
				//check email id and customer id exits or not
				if(!empty($cust_array['email']) && !empty($cust_array['cust_id'])) {
					$pattern_flag	=	TRUE;
					//load customer model
					$this->load->model('customer_model', 'customer');
					
					//update
					$ret = $this->customer->update_emailverification_flag($cust_array['email'], $cust_array['cust_id']);
					
					if($ret)
					{
						echo 'Your email address has been verified.';
					}
					else {
						echo 'There was an error while verifing email address';
					}
				}
			}
		}
		
		if($pattern_flag == FALSE){
			echo 'Unauthorize accsess!';
		}
	}
}
?>