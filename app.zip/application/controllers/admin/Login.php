<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Login extends CI_Controller {
    function Login()
    {
        parent :: __construct();
        //$this->load->library('administration');

        $forcepasswordchange = $this->session->userdata('forcepasswordchange');
        //echo $this->user->username."force".$forcepasswordchange;die;
        if($this->user->username && empty($forcepasswordchange))
        //if($this->user->username)
        {
            redirect('admin/home/index');
        }
        else if($forcepasswordchange == 1)
            $this->dologin();
    }

    # default login page
    function index()
    {
        $data['js'] = array("login.js");
        $forcepasswordchange = $this->session->userdata('forcepasswordchange');
        if ($this->user->logged_in && empty($forcepasswordchange)) 
        {
            $data['title'] = "Home";
            $this->load->view('admin/home/index', $data);
        }
        else
        {
            $data['title'] = "Login";
            $this->load->view('admin/login', $data);
        }
    }

    # force password change login page
    function forcechange()
    {
        $data['js'] = array("login.js");
        $data['title'] = "Login";
        $data['succmsg'] = "Your password has been changed successfully. Please login again to continue.";
        $this->load->view('admin/login', $data);
    }

    # do login to the system
    function dologin()
    {
        //echo "dologin";die;
        $data['js'] = array("login.js");
        $forcepasswordchange = $this->session->userdata('forcepasswordchange');
		
        //if ( $this->user->logged_in && !$forcepasswordchange)
        if ( $this->user->logged_in && empty($forcepasswordchange))
        {
            //echo "aa";die;
            /*$data['title'] = "Home";
            $this->load->view('admin/home',$data);*/
            redirect('admin/home/index');
        }
        else
        {
            if(!$this->input->post('submit') && empty($forcepasswordchange))
            //if(!$this->input->post('submit'))
            {
                $data['title'] = "Login";
                $this->load->view('admin/login', $data);
            }
            else
            {
                $username = $this->input->post('username');
                $password = $this->input->post('password');
				
                $isValidLogin = $this->user->login($username, $password);
                if($isValidLogin === TRUE)
                {
                    
				   # loads required models
                    $this->load->model('Userlog_model', 'userlog');
                    $this->userlog->insertUserLog();
                    redirect('admin/home/index','location');
                }
                else if($isValidLogin == 'ForcePasswordChange' || $forcepasswordchange == 1)
                {
                  
                    # loads required models
                    $this->load->model('Common_model', 'common');
                    $data['title'] = "Force Password Change";
                    $data['forcepasswordchange'] = TRUE;
                    $this->session->set_userdata('forcepasswordchange',$data['forcepasswordchange']);
                    $this->load->view('admin/forcepasswordchange', $data);
                }
                else
                {
                    $data['title'] = "Login";
                    $data['msg'] = 'Invalid Login. Please try again.';
                    $this->load->view('admin/login', $data);
                }
            }
        }
    }

    # logout from system
    function logout()
    {
        $this->user->logout();
        redirect('admin/login');
    }
}
?>