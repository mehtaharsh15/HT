<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class NoAccess extends CI_Controller
{
    function NoAccess()
    {
        parent :: __construct();
        $this->load->model('Common_model', 'common');
        $this->load->library('administration');
    }

    function index()
    {
        $this->load->view('admin/noaccess');
    }
}
?>