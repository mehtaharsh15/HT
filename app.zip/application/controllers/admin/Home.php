<?php

if(!defined('BASEPATH'))
    exit('No direct script access allowed');
class Home extends CI_Controller {
    function Home()
    {
        parent :: __construct();

        # loads required libraries
        $this->load->library('administration');
        $this->load->library('user_agent');        
        
        # loads required models
        $this->load->model('Common_model', 'common');
		$this->load->model('Users_model', 'users');
             
    }

    function index()
    {		
		$data['title'] 	= "Active Patients";
        $data['view'] 	= "admin/index";
       
        $data['js'] 	= array("field_mask.js","jquery.pnotify.min.js","socket.io.min.js","socket_connection.js","dashboard.js", "jquery.fancybox.js");
        $data['CssFiles'] = array("bootstrap-timepicker.min.css","jquery.pnotify.default.css", "jquery.fancybox.css");
       
	    $welcome['title']="welcome";
        $this->load->view('admin/welcome',$welcome);
       
    }
  
	function isweekend($year, $month, $day)
	{
		$time = mktime(0, 0, 0, $month, $day, $year);
		$weekday = date('w', $time);
		return ($weekday == 0 || $weekday == 6);
	}
	function isweekendSaturday($year, $month, $day)
	{
		$time = mktime(0, 0, 0, $month, $day, $year);
		$weekday = date('w', $time);
		return ($weekday == 0);
	}

	/*function directmsgs()
    {
        
		$data['title'] 	= "Direct Messages";
        $data['view'] 	= "admin/index";
       
        $data['js'] 	= array("field_mask.js","jquery.pnotify.min.js","socket.io.min.js","dashboard.js", "jquery.fancybox.js");
        $data['CssFiles'] = array("jquery.pnotify.default.css", "jquery.fancybox.css");
        
        $direct_msg=TRUE;
        if($direct_msg)
        {
            if(isset($_POST['search']))
			{
			$this->load->model('Customer_model', 'customer');
			
			
			 $mobile          = $this->input->post('mobile');
             $email           = $this->input->post('email');
			  
			
			 $data['customer_count'] 	= $this->customer->get_customer_count();
			 $data['customer_entry'] 	= $this->customer->Search_Bycustomer($mobile,$email);
			 $customerdata = array(
								'mobile'  => $this->input->post('mobile'),
								'email'   => $this->input->post('email')
								);
             $this->session->set_userdata($customerdata);
			 
		
			  $this->load->view('admin/direct_messages', $data);
			}
			elseif(isset($_POST['reset']))
			{
				  redirect('admin/Customer/index');
			}
			else
			{
				 redirect('admin/noaccess/index');
			}
     
		}
	
	
	}*/

}
?>