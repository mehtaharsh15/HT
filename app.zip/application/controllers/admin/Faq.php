<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Faq extends CI_Controller
{	
    # Constructer
    function Faq()
    {
        parent :: __construct();

        # loads required models
        $this->load->model('Common_model', 'common');
        $this->load->model('Faq_model', 'faq');
       
      
    }

    # default page, Module Listing page
    function index()
    {
        $data['title']	= "Faq Listing";
       // $data['js'] 	= array("machine.js");

       
            $data['faq_count'] 	= $this->faq->get_faq_count();
            $data['faq_entry'] 	= $this->faq->get_allfaq();
           
            # prepare listing view
 
           $this->load->view('admin/faq_manage', $data);
        
    }

    # Add New entry Page
    function insert()
    {
        $data['title']	= "Add New Faq";
        $data['Action']	= "Add";
        $data['js'] 	= array("jquery/duplicate-remove/jquery.duplicate-remove.js","field_mask.js","machine.js");

      
            if ($this->input->post('submit'))
            {
                if($result = $this->faq->insert())
                {
                    $this->session->set_flashdata('notification', 'Faq information has been added successfully.');
                    redirect('admin/faq/index/');
                }
                else
                {
                    $this->session->set_flashdata('notification', 'Faq information cannot be added.');
                    $data['faq_edit_entry'] = array(
                                                        'faq_question'	=>	$this->input->post('faq_question'),
                                                        'faq_answer'     =>	$this->input->post('faq_answer'),
                                                        'faq_active' 	=>	$this->input->post('faq_active'),
														
                                                    );


                    //$data['faqMsg']	= "Code is already exist for selected Faq.";
                    //$this->session->set_flashdata('faqMsg', 'Code is already exist for selected Faq.');
					$this->load->view('admin/faq_addedit', $data);
                }
            }
            elseif($this->input->post('cancel'))
            {
                redirect('admin/faq/index/');
            }
            else
            {
                $this->load->view('admin/faq_addedit', $data);
            }
        
    }

    # Edit entry Page
    function edit()
    {
        
        $data['title']	= "Edit Faq";
        $data['Action']	= "Edit";
        $data['js'] 	= array("jquery/duplicate-remove/jquery.duplicate-remove.js","field_mask.js","machine.js");

    
            if ($this->input->post('submit'))
            {

			   if($result = $this->faq->update())
                {
					$this->session->set_flashdata('notification', 'Faq information has been updated successfully.');
                    redirect('admin/faq/index/');
                }
                else
                {
                    $this->session->set_flashdata('notification', 'Faq information cannot be updated.');
                    $data['faq_edit_entry'] = array(
                                                        'faq_question'	=>	$this->input->post('faq_question'),
                                                        'faq_answer'     =>	$this->input->post('faq_answer'),
                                                        'faq_active' 	=>	$this->input->post('faq_active'),
														
                                                    );

                  
                    //$data['faqMsg']		= "Faq name or code already exists.";
					//$this->session->set_flashdata('faqMsg', 'Faq name or code already exists.');
                    $this->load->view('admin/faq_addedit', $data);
                }
            }
            elseif ($this->input->post('cancel'))
            {
                redirect('admin/faq/index/');
            }
            else
            {
                
                $data['faq_edit_entry']	= $this->faq->get_faq_edit($this->uri->segment(4));
				$this->load->view('admin/faq_addedit', $data);
            }
       
    }

    # change active status
    function changeactivestatus($isajax=1)
    {
       
        header('Content-Type: text/html; charset=utf-8');

        $FaqId 	= $this->input->post('faq_id');
		
        if($isajax == 1)
        {
            
            $this->faq->toggle_status($FaqId, $this->input->post('faq_active'));
            echo $FaqId;
        }

        return;
    }
	

    
}
?>