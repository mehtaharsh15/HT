<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Sell extends CI_Controller
{	
    # Constructer
    function Sell()
    {
        parent :: __construct();

        # loads required models
        $this->load->model('Common_model', 'common');
        $this->load->model('Sell_model', 'sell');
       
      
    }

    # default page, Module Listing page
    function index()
    {
        $data['title']	= "Sell Transaction Listing";
        //$data['js'] 	= array("machine.js");

       
            //$data['machine_count'] 	= $this->machine->get_machine_count();
            $data['sell_entry'] 	= $this->sell->get_allsell(true,'');
           
            # prepare listing view
 
           $this->load->view('admin/sell_manage', $data);
        
    }
	
	
	 # change active status
    function changeactivestatus($isajax=1)
    {
        //header('Content-Type: application/json');
        header('Content-Type: text/html; charset=utf-8');

        $SellId = $this->input->post('sell_id');
		
        if($isajax == 1)
        {
          
            $this->sell->toggle_status($SellId, $this->input->post('sell_active'));
            echo $SellId;
        }

        return;
    }

    # Add New entry Page
   /* function insert()
    {
        $data['title']	= "Add New Machine";
        $data['Action']	= "Add";
        $data['js'] 	= array("jquery/duplicate-remove/jquery.duplicate-remove.js","field_mask.js","machine.js");

      
            if ($this->input->post('submit'))
            {
                if($result = $this->machine->insert())
                {
                    $this->session->set_flashdata('notification', 'Machine information has been added successfully.');
                    redirect('admin/machine/index/');
                }
                else
                {
                    $this->session->set_flashdata('notification', 'Machine information cannot be added.');
                    $data['machine_edit_entry'] = array(
                                                        'machine_name'	=>	$this->input->post('machine_name'),
                                                        'machine_code'          =>	$this->input->post('machine_code'),
                                                        'machine_latitude' 	=>	$this->input->post('machine_latitude'),
                                                        'machine_longitude' 	=>	$this->input->post('machine_longitude'),
                                                        'machine_active' 	=>	$this->input->post('machine_active'),
														'machine_qrcode' 	  =>	'',
                                                    );


                    $data['machineMsg']	= "Code is already exist for selected Machine.";
                    $this->session->set_flashdata('machineMsg', 'Code is already exist for selected Machine.');

                    
                    $this->load->view('admin/machine_addedit', $data);
                }
            }
            elseif($this->input->post('cancel'))
            {
                redirect('admin/machine/index/');
            }
            else
            {
                $this->load->view('admin/machine_addedit', $data);
            }
        
    }*/

    # Edit entry Page
    function edit()
    {
        
        $data['title']	= "Edit Sell";
        $data['Action']	= "Edit";
        $data['js'] 	= array("jquery/duplicate-remove/jquery.duplicate-remove.js","field_mask.js","machine.js");

    
            if ($this->input->post('submit'))
            {
                if($result = $this->sell->update())
                {
                  
				   $this->session->set_flashdata('notification', 'Sell information has been updated successfully.');
                    redirect('admin/sell/index/');
                }
                else
                {
                    $this->session->set_flashdata('notification', 'sell information cannot be updated.');
                    $data['sell_edit_entry'] = array(
                                                        'machine_name'	=>	$this->input->post('machine_name'),
                                                        'machine_code'          =>	$this->input->post('machine_code'),
                                                        'machine_latitude' 	=>	$this->input->post('machine_latitude'),
                                                        'machine_longitude' 	=>	$this->input->post('machine_longitude'),
                                                        'machine_active' 	=>	$this->input->post('machine_active'),
                                                        'machine_id'            =>	$this->input->post('machine_id'),
                                                       
                                                    );

                  
                    $data['machineMsg']		= "sell name or code already exists.";
                 
                    $this->session->set_flashdata('machineMsg', 'sell name or code already exists.');

                   

                    $this->load->view('admin/sell_addedit', $data);
                }
            }
            elseif ($this->input->post('cancel'))
            {
                redirect('admin/sell/index/');
            }
            else
            {
              
                
				$data['sell_edit_entry']	= $this->sell->getsellInfobyId($this->uri->segment(4));
				

                $this->load->view('admin/sell_addedit',$data);
            }
       
    }


    
}
?>