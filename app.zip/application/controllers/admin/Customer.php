<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Customer extends CI_Controller
{	
    # Constructer
    function Customer()
    {
        parent :: __construct();

        # loads required models
        $this->load->model('Common_model', 'common');
        $this->load->model('Customer_model', 'customer');
        $this->load->library('Subquery');
       
      
    }

    # default page, Module Listing page
    function index()
    {
        $data['title']	= "Customer Listing";
        $data['js'] 	= array("customer.js");

       
            $data['customer_count'] 	= $this->customer->count_all();
            $data['customer_entry'] 	= $this->customer->get_allCustomer();
           
            # prepare listing view
 
           $this->load->view('admin/customer_manage', $data);
        
    }

    # Edit entry Page
    function edit()
    {
        
        $data['title']	= "Edit Customer";
        $data['Action']	= "Edit";
        $data['js'] 	= array("jquery/duplicate-remove/jquery.duplicate-remove.js","field_mask.js","customer.js");

    
            if ($this->input->post('submit'))
            {
                if($result = $this->customer->update())
                {
                  
				   $this->session->set_flashdata('notification', 'Customer information has been updated successfully.');
                    redirect('admin/customer/index/');
                }
                else
                {
                    $this->session->set_flashdata('notification', 'Customer information cannot be updated.');
                    $data['customer_edit_entry'] = array(
                                                        'customer_firstname'	=>	$this->input->post('first_name'),
                                                        'customer_lastname'     =>	$this->input->post('last_name'),
                                                        'customer_email' 		=>	$this->input->post('email'),
                                                        'customer_mobile' 		=>	$this->input->post('mobile'),
                                                        'customer_active' 		=>	$this->input->post('customer_active'),
                                                        'customer_id'           =>	$this->input->post('customer_id'),
                                                       
                                                    );

                  
                    $data['customerMsg']		= "Customer email already exists.";
					$this->session->set_flashdata('customerMsg', 'Customer email already exists.');
					
					$this->load->view('admin/customer_addedit', $data);
                }
            }
            elseif ($this->input->post('cancel'))
            {
                redirect('admin/customer/index/');
            }
            else
            {
              
                $data['customer_edit_entry']	= $this->customer->get_customer_edit($this->uri->segment(4));
                $this->load->view('admin/customer_addedit', $data);
            }
       
    }
	
	#datable list using server side scripting
    public function customer_ajax_list()
    {
		
        $list = $this->customer->get_allCustomer();
        $data = array();
        //$no = $this->input->POST['start'];
        foreach ($list as $customer) {
            //$no++;
            $row = array();
            //$row[] = $no;
            $row[] = $customer->customer_firstname;
            $row[] = $customer->customer_lastname;
            $row[] = $customer->customer_email;
            $row[] = $customer->customer_mobile;
            $row[] = !empty($customer->balance)?($customer->balance):0;
            
			  $row[] = '<a class="tooltip-top btn" href="'.base_url().'admin/customer/edit/'.$customer->customer_id.'" title="Edit" >
			  <i class="icon-edit"></i>  </a>
              <a id="delete" class="tooltip-top btn" data-original-title="Delete" onclick="customer_delete('."'".$customer->customer_id."'".')">
			  <i class="icon-trash"></i> </a>';
        
 
            $data[] = $row;
        }
 
        $output = array(
                        "draw" => $this->input->POST['draw'],
                        "recordsTotal" => $this->customer->count_all(),
                        "recordsFiltered" => $this->customer->customer_count_filtered(),
                        "data" => $data,
                );
        //output to json format
        echo json_encode($output);
    }
	
    # change active status
    function changeactivestatus($isajax=1)
    {
      
        header('Content-Type: text/html; charset=utf-8');

        $CustomerId 	= $this->input->post('customer_id');
		
        if($isajax == 1)
        {
            
            $this->customer->toggle_status($CustomerId, $this->input->post('customer_active'));
            echo $CustomerId;
        }

        return;
    }

}
?>