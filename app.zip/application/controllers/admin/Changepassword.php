<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Changepassword extends CI_Controller {
    function Changepassword()
    {
        parent :: __construct();
        $this->load->library('administration');
        $this->load->model('Common_model', 'common');
    }
    function index()
    {
        //echo "change";die;
        $data['js'] = array("changepassword.js");
        $data['title'] = "Change Password";
        $this->load->view('admin/changepassword', $data);
    }
    function change()
    {
        $data['js'] = array("changepassword.js");
        $data['title'] = "Change Password";
        if ($this->input->post('submit') == "Update")
        {
            $this->db->where('user_name', $this->input->post('login_id'));
            $this->db->where('user_password', md5($this->input->post('o_password')));
            $query = $this->db->get('user_master');
            //echo $query->num_rows()." ".$this->session->userdata('forcepasswordchange');die;
            if($query->num_rows())
            {
                $data = array('user_password' => md5($this->input->post('n_password')),'user_password_last_changed' => time());
                $this->db->where('user_name', $this->input->post('login_id'));
                //echo $this->db->update('user_master', $data);die;
                $query = $this->db->update('user_master', $data);
                if($query)
                {
                    if($this->session->userdata('forcepasswordchange'))
                    {
                        $this->session->unset_userdata('forcepasswordchange');
                        $this->user->_destroy_session();
                        redirect('admin/login/forcechange/');
                    }
                    $this->session->set_flashdata('notification', 'Password has been changed successfully.');
                }
            }
            else
                $this->session->set_flashdata('notification', 'You have entered invalid old password.');
        }
        if($this->session->userdata('forcepasswordchange'))
        {
            $data['title'] = "Force Password Change";
            $data['error'] = "You have entered invalid old password.";
            $data['forcepasswordchange'] = TRUE;
            $this->session->set_userdata('forcepasswordchange',$data['forcepasswordchange']);
            //$this->session->set_flashdata('notification', 'You have entered invalid old password.');
            $this->load->view('admin/forcepasswordchange', $data);
        }
            
        else
            redirect('admin/changepassword');
    }
}
?>