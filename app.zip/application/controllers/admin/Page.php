<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
	class Page extends CI_Controller {
		function Page()
		{
			parent :: __construct();
			
			$this->load->model('Common_model', 'common');
			
		}		
		function index()
		{	
			 redirect('admin/home/index/');
		}	 
			 
	}			