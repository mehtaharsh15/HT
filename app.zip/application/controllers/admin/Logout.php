<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
	class Logout extends CI_Controller {
	
		function Logout()
		{
			parent :: __construct();

			//$this->output->enable_profiler(TRUE);
		}		

		function index()
		{
			$this->user->logout();

			redirect('admin/login');
		}

	}

?>