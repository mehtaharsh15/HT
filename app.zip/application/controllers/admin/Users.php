<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Users extends CI_Controller
{
    # constructure
    function Users()
    {
        parent :: __construct();

        $this->load->model('Common_model', 'common');
        $this->load->model('UserGroup_model', 'usergroup');
        $this->load->model('Users_model', 'users');
    
    }

    # default listing page
    function index()
    {
        $data['title']	= "User Information";
        
        if($this->common->admin_permission('Users_View','Manage_Users','Users'))
        {
            $data['users_count'] = $this->users->get_users_count();
            $data['users_entry'] = $this->users->get_users();
           
            $data['rsClients'] = $this->client->get_allClientKeyValueArray();
          
            $this->load->view('admin/users_manage', $data);            
        }
    }

    # add new record page
    function insert()
    {
        $data['title']	= "Add New User";
        $data['Action']	= "Add";
        $data['js'] 	= array("field_mask.js","users.js");
        $userDetails = $this->common->getUserDetail($this->session->userdata('id'));

        if($this->common->admin_permission('Users_Add','Manage_Users','Users'))
        //if($this->user->user_group_id == 1)
        {
            if ($this->input->post('submit'))
            {
                if($result = $this->users->insert())
                {
                    $this->session->set_flashdata('notification', 'User information has been added successfully.');

                    redirect('admin/users/index/');
                }
                else
                {
                    $this->session->set_flashdata('notification', 'User information cannot be added. Duplicate entry found.');

                    $data['users_edit_entry'] = array(
                                                        'user_name' 			=>	$this->input->post('user_username'),
                                                        'user_password' 		=>	'',
                                                        'user_group_id' 		=>	$this->input->post('user_group_id'),
                                                        'user_last_login' 		=>	date('Y-m-d H:m:s'),
                                                        'user_active' 			=>	$this->input->post('is_active'),
                                                        'user_firstname' 		=>	$this->input->post('user_firstname'),
                                                        'user_lastname' 		=>	$this->input->post('user_lastname'),
                                                        'user_email' 			=>	$this->input->post('user_email'),
                                                        'user_contact' 			=>	$this->input->post('user_contactno'),
                                                        'user_client_id' 		=>	$this->input->post('user_client_id'),
                                                        /*'user_allowed_practice_id' 	=>	$this->input->post('user_allowed_practice_id'),
                                                        'user_allowed_group_id' 	=>	$this->input->post('user_allowed_group_id'),
                                                        'user_allowed_physician_id'     =>	$this->input->post('user_allowed_physician_id')*/
                                                    );

                    $data['usergroups'] = $this->usergroup->get_usergroup();
                    $data['userclients'] = $this->client->get_allclient();
                    /*$data['rsPractice'] = $this->practice->get_allpracticeKeyValueArray($userDetails[0]['user_allowed_practice_id']);
                    //$data['rsPractice'] = array_merge(array("0"=>"All Practices"),$data['rsPractice']);
                    if(!$userDetails[0]['user_allowed_practice_id'])
                        $data['rsPractice'] = array("0"=>"All Practices") + $data['rsPractice'];*/

                    $data['usererrormsg'] = "User name already exists.";
                    $this->session->set_flashdata('usermsg', 'User name already exists.');

                    $this->load->view('admin/users_addedit', $data);
                    //redirect('admin/users/index/');
                }
            }
            elseif ($this->input->post('cancel'))
            {
                redirect('admin/users/index/');
            }
            else
            {
                //$data['usergroups'] = $this->usergroup->get_usergroup();
                $data['usergroups']  = $this->usergroup->get_usergroup();
                $data['userclients'] = $this->client->get_allclient();
                /*$data['rsPractice'] = $this->practice->get_allpracticeKeyValueArray($userDetails[0]['user_allowed_practice_id']);
                //$data['rsPractice'] = array_merge(array("0"=>"All Practices"),$data['rsPractice']);
                if(!$userDetails[0]['user_allowed_practice_id'])
                    $data['rsPractice'] = array("0"=>"All Practices") + $data['rsPractice'];*/
                $this->load->view('admin/users_addedit',$data);
            }
        }
    }

    # edit record page
    function edit()
    {
        $data['title']	= "Edit User Information";
        $data['Action']	= "Edit";
        $data['js'] 	= array("field_mask.js","users.js");
        $userDetails = $this->common->getUserDetail($this->session->userdata('id'));

        if($this->common->admin_permission('Users_Edit','Manage_Users','Users'))
        {
            if ($this->input->post('submit'))
            {
                if($result = $this->users->update())
                {
                    $this->session->set_flashdata('notification', 'User information has been updated successfully.');
                    redirect('admin/users/index/');
                }
                else
                {
                    $this->session->set_flashdata('notification', 'User information cannot be updated. Duplicate entry found.');

                    $data['users_edit_entry'] = array(
                                                        'user_name' 			=>	$this->input->post('user_username'),
                                                        'user_password' 		=>	'',
                                                        'user_group_id' 		=>	$this->input->post('user_group_id'),
                                                        'user_last_login' 		=>	date('Y-m-d H:m:s'),
                                                        'user_active' 			=>	$this->input->post('is_active'),
                                                        'user_firstname' 		=>	$this->input->post('user_firstname'),
                                                        'user_lastname' 		=>	$this->input->post('user_lastname'),
                                                        'user_email' 			=>	$this->input->post('user_email'),
                                                        'user_contact' 			=>	$this->input->post('user_contactno'),
                                                        'user_id' 			    =>	$this->input->post('usersid'),
                                                        'user_client_id' 		=>	$this->input->post('user_client_id'),
                                                        /*'user_allowed_practice_id' 	=>	$this->input->post('user_allowed_practice_id'),
                                                        'user_allowed_group_id' 	=>	$this->input->post('user_allowed_group_id'),
                                                        'user_allowed_physician_id'     =>	$this->input->post('user_allowed_physician_id')*/
                                                );

                    $data['usergroups']  = $this->usergroup->get_usergroup();
                    $data['userclients'] = $this->client->get_allclient();
                    /*$data['rsPractice']  = $this->practice->get_allpracticeKeyValueArray($userDetails[0]['user_allowed_practice_id']);
                    $data['rsGroup']	 = $this->group->get_group_keyvalue_bypracticeid($this->input->post('user_allowed_practice_id'), $userDetails[0]['user_allowed_group_id']);
                    $data['rsPhysician'] = $this->physician->get_physician_key_value_array_by_groupid($this->input->post('user_allowed_group_id'), $userDetails[0]['user_allowed_physician_id']);*/
                    //$data['rsPractice']	 = array_merge(array("0"=>"All Practices"),$data['rsPractice']);
                    /*if(!$userDetails[0]['user_allowed_practice_id'])
                        $data['rsPractice'] = array("0"=>"All Practices") + $data['rsPractice'];*/
                    //$data['rsGroup']	 = array_merge(array("0"=>"All Groups"),$data['rsGroup']);
                    //$data['rsPhysician'] = array_merge(array("0"=>"All Physicians"),$data['rsPhysician']);
                    /*if(!$userDetails[0]['user_allowed_group_id'])
                        $data['rsGroup']	 = array("0"=>"All Groups")+$data['rsGroup'];
                    if(!$userDetails[0]['user_allowed_physician_id'])
                        $data['rsPhysician'] = array("0"=>"All Physicians")+$data['rsPhysician'];*/
                    if($this->uri->segment(4) == 1)
                        $data['userclients'] = array("0"=>array("client_id"=>0,"client_company_name"=>"All Clients"))+$data['userclients'];
                    //$data['usermsg']	 = "User Name Already Exists.";
                    $data['usererrormsg'] = "User name already exists.";
                    $this->session->set_flashdata('usermsg', 'User Name Already Exists.');

                    //redirect('admin/users/edit/'.$this->input->post('usersid'));
                    $this->load->view('admin/users_addedit',$data);
                }
            }
            elseif ($this->input->post('cancel'))
            {
                redirect('admin/users/index/');
            }
            else
            {
                $data['usergroups'] 		= $this->usergroup->get_usergroup();
                $data['userclients']            = $this->client->get_allclient();
                $data['users_edit_entry'] 	= $this->users->get_users_edit($this->uri->segment(4));
                /*$data['rsPractice']		= $this->practice->get_allpracticeKeyValueArray($userDetails[0]['user_allowed_practice_id']);
                $data['rsGroup']	 	= $this->group->get_group_keyvalue_bypracticeid($data['users_edit_entry']['user_allowed_practice_id'], $userDetails[0]['user_allowed_group_id']);
                $data['rsPhysician'] 		= $this->physician->get_physician_key_value_array_by_groupid($data['users_edit_entry']['user_allowed_group_id'], $userDetails[0]['user_allowed_physician_id']);*/
                //$data['rsPractice']             = array_merge(array("0"=>"All Practices"),$data['rsPractice']);
                /*if(!$userDetails[0]['user_allowed_practice_id'])
                    $data['rsPractice'] = array("0"=>"All Practices") + $data['rsPractice'];*/
                //$data['rsGroup']	= array_merge(array("0"=>"All Groups"),$data['rsGroup']);
                //$data['rsPhysician']	= array_merge(array("0"=>"All Physicians"),$data['rsPhysician']);
                /*if(!$userDetails[0]['user_allowed_group_id'])
                    $data['rsGroup']	 = array("0"=>"All Groups")+$data['rsGroup'];
                if(!$userDetails[0]['user_allowed_physician_id'])
                    $data['rsPhysician'] = array("0"=>"All Physicians")+$data['rsPhysician'];*/
                if($this->uri->segment(4) == 1)
                    $data['userclients'] = array("0"=>array("client_id"=>0,"client_company_name"=>"All Clients"))+$data['userclients'];

                $this->load->view('admin/users_addedit',$data);
            }
        }
    }

    # change active status
    function changeactivestatus($isajax=1)
    {
        //header('Content-Type: application/json');
        header('Content-Type: text/html; charset=utf-8');

        $UserId 	= $this->input->post('user_id');
        if($isajax == 1)
        {
            //echo $this->input->post('user_id'), $this->input->post('user_active'); die;
            $this->users->toggle_status($UserId, $this->input->post('user_active'));

            echo $UserId;
        }
        return;
    }
}
?>