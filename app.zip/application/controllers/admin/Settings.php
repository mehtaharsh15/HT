<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Settings extends CI_Controller {
    function Settings()
    {
        parent :: __construct();
        $this->load->library('administration');
        $this->load->model('Common_model', 'common');
        $this->load->library('upload');
    }		
    function index()
    {	
        $data['js'] = array("field_mask.js","settings.js");
        $data['title'] = "Settings";
        if($this->common->admin_permission('Settings_Edit','Settings'))
        {
            $this->load->view('admin/settings', $data);
        }
    }
    function update()
    {	
        $data['js'] = array("field_mask.js","settings.js");
        $data['title'] = "Settings";
        $str=explode('#',$this->input->post('unique_id'));
        $this->session->set_flashdata('current_tab', $str);
        if($_FILES['site_icon']['name'])
        {
            $image_file = preg_replace("/\s+/", "_", $_FILES['site_icon']['name']);
            $config['file_name'] = $image_file ;
            $config['upload_path'] = 'uploads/';
            $config['allowed_types'] = 'gif|jpg|png';
            $this->upload->initialize($config);
            if (!$this->upload->do_upload('site_icon'))
            {
                $error = array('error' => $this->upload->display_errors());
            }
            $this->db->update('web_config',array('config_value'=>$image_file),array('config_name'=>'site_icon'));
        }
        else
        {
            $this->db->update('web_config',array('config_value'=>$this->input->post('old_icon')),array('config_name'=>'site_icon'));
        }
        if($_FILES['marketing_site_icon']['name'])
        {
            $image_file = preg_replace("/\s+/", "_", $_FILES['marketing_site_icon']['name']);
            $config['file_name'] = $image_file ;
            $config['upload_path'] = 'uploads/marketing/';
            $config['allowed_types'] = 'gif|jpg|png';
            $this->upload->initialize($config);
            if (!$this->upload->do_upload('marketing_site_icon'))
            {
                $error = array('error' => $this->upload->display_errors());
            }
            $this->db->update('web_config',array('config_value'=>$image_file),array('config_name'=>'marketing_site_icon'));
        }
        else
        {
            $this->db->update('web_config',array('config_value'=>$this->input->post('old_icon')),array('config_name'=>'marketing_site_icon'));
        }
        if($this->common->admin_permission('Settings_Edit','Settings'))
        {
            if ($this->input->post('submit') == "Update")
            {
                $settings_arr = array("company_name", "company_address", "company_mobile", "company_email", "report_email", "site_name","marketing_site_name",
                                    "company_copyright", "page_size", "from_email_address","company_powerby","lock_expiration_time","force_password_changes",
                                    "admin_email_address","admin_email_signature","admin_email_footer","ga_email","ga_password","ga_profile_id","admin_gooole_analytic_code"
                                    ,"admin_gooole_map_url","admin_gooole_map_address","admin_gooole_map_key",
                                    "admin_shutdown","admin_shutdown_message","admin_meta_description","admin_meta_keyword",
                                    "admin_additional_meta_tag","admin_global_meta_tag","auth_required","auth_username","auth_password");
                for($i=0; $i < count($settings_arr); $i++)
                {
                    if($settings_arr[$i] == "admin_shutdown_message")
                        $settings_data = array('config_value' =>  $this->input->post($settings_arr[$i],FALSE));
                    else
                        $settings_data = array('config_value' =>  $this->input->post($settings_arr[$i]));
                    $this->db->where('config_name', $settings_arr[$i]);
                    if($query = $this->db->update('web_config', $settings_data))
                            $this->session->set_flashdata('notification', 'Settings has been updated successfully.');
                }
            }
            redirect('/admin/settings');
        }
    }
}
?>