<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Machine extends CI_Controller
{	
    # Constructer
    function Machine()
    {
        parent :: __construct();

        # loads required models
        $this->load->model('Common_model', 'common');
        $this->load->model('Machine_model', 'machine');
        $this->load->library('Ci_qr_code');
        $this->config->load('qr_code');
      
    }

    # default page, Module Listing page
    function index()
    {
        $data['title']	= "Machine Listing";
      //  $data['js'] 	= array("machine.js");

       
            $data['machine_count'] 	= $this->machine->get_machine_count();
            $data['machine_entry'] 	= $this->machine->get_allmachine();
           
            # prepare listing view
 
           $this->load->view('admin/machine_manage', $data);
        
    }

    # Add New entry Page
    function insert()
    {
        $data['title']	= "Add New Machine";
        $data['Action']	= "Add";
        $data['js'] 	= array("jquery/duplicate-remove/jquery.duplicate-remove.js","field_mask.js","machine.js");

      
            if ($this->input->post('submit'))
            {
                if($result = $this->machine->insert())
                {
                    $this->session->set_flashdata('notification', 'Machine information has been added successfully.');
                    redirect('admin/machine/index/');
                }
                else
                {
                    $this->session->set_flashdata('notification', 'Machine information cannot be added.');
                    $data['machine_edit_entry'] = array(
                                                        'machine_name'		=>	$this->input->post('machine_name'),
                                                        'machine_code'      =>	$this->input->post('machine_code'),
                                                        'machine_latitude' 	=>	$this->input->post('machine_latitude'),
                                                        'machine_longitude' =>	$this->input->post('machine_longitude'),
                                                        'machine_active' 	=>	$this->input->post('machine_active'),
														'machine_qrcode'    =>	'',
                                                    );


                    $data['machineMsg']	= "Code is already exist for selected Machine.";
                    $this->session->set_flashdata('machineMsg', 'Code is already exist for selected Machine.');

                    
                    $this->load->view('admin/machine_addedit', $data);
                }
            }
            elseif($this->input->post('cancel'))
            {
                redirect('admin/machine/index/');
            }
            else
            {
                $this->load->view('admin/machine_addedit', $data);
            }
        
    }

    # Edit entry Page
    function edit()
    {
        
        $data['title']	= "Edit Machine";
        $data['Action']	= "Edit";
        $data['js'] 	= array("jquery/duplicate-remove/jquery.duplicate-remove.js","field_mask.js","machine.js");

    
            if ($this->input->post('submit'))
            {
                if($result = $this->machine->update())
                {
                  
				   $this->session->set_flashdata('notification', 'Machine information has been updated successfully.');
                    redirect('admin/machine/index/');
                }
                else
                {
                    $this->session->set_flashdata('notification', 'Machine information cannot be updated.');
                    $data['machine_edit_entry'] = array(
                                                        'machine_name'		=>	$this->input->post('machine_name'),
                                                        'machine_code'      =>	$this->input->post('machine_code'),
                                                        'machine_latitude' 	=>	$this->input->post('machine_latitude'),
                                                        'machine_longitude' =>	$this->input->post('machine_longitude'),
                                                        'machine_active' 	=>	$this->input->post('machine_active'),
                                                        'machine_id'        =>	$this->input->post('machine_id'),
                                                       
                                                    );

                  
                    $data['machineMsg']		= "Machine name or code already exists.";
                 
                    $this->session->set_flashdata('machineMsg', 'Machine name or code already exists.');

                   

                    $this->load->view('admin/machine_addedit', $data);
                }
            }
            elseif ($this->input->post('cancel'))
            {
                redirect('admin/machine/index/');
            }
            else
            {
              
                $data['machine_edit_entry']	= $this->machine->get_machine_edit($this->uri->segment(4));
           
                $this->load->view('admin/machine_addedit', $data);
            }
       
    }

    # change active status
    function changeactivestatus($isajax=1)
    {
        //header('Content-Type: application/json');
        header('Content-Type: text/html; charset=utf-8');

        $MachineId 	= $this->input->post('machine_id');
		
        if($isajax == 1)
        {
            //echo $this->input->post('partner_id'), $this->input->post('partner_active'); die;
            $this->machine->toggle_status($MachineId, $this->input->post('machine_active'));
            echo $MachineId;
        }

        return;
    }
	
	//PRINT GET QR CODE
	function print_qr($machine_id)
    {
      
	    $qr_code_config = array();
        $qr_code_config['cacheable']	 = $this->config->item('cacheable');
        $qr_code_config['cachedir'] 	 = $this->config->item('cachedir');
        $qr_code_config['imagedir']  	 = $this->config->item('imagedir');
        $qr_code_config['errorlog'] 	 = $this->config->item('errorlog');
        $qr_code_config['ciqrcodelib']   = $this->config->item('ciqrcodelib');
        $qr_code_config['quality'] 		 = $this->config->item('quality');
        $qr_code_config['size']			 = $this->config->item('size');
        $qr_code_config['black'] 		 = $this->config->item('black');
        $qr_code_config['white'] 		 = $this->config->item('white');
        $this->ci_qr_code->initialize($qr_code_config);
        
        $machine_details = $this->machine->getMachineinfoById($machine_id);
        $image_name = $machine_id . ".png";
       
        // create machine content
         $codeContents = "machine_name:";
        $codeContents .= "$machine_details->machine_name";
      
      
        $codeContents .= "\n";
        $codeContents .= "machine_code :";
        $codeContents .= $machine_details->machine_code; 

        $params['data'] = $codeContents;
		
        $params['level'] = 'H';
        $params['size'] = 4;
        
        $params['savename'] = $qr_code_config['imagedir'] . $image_name;
      
  
        $this->ci_qr_code->generate($params);
        
        $this->data['qr_code_image_url'] = base_url() . $qr_code_config['imagedir'] . $image_name;
         	
        $this->machine->change_machineqr($machine_id, $image_name);
	    $file = $params['savename'];
	
        if(file_exists($file))
		{
			
		   
            header('Content-Description: File Transfer');
            header('Content-Type: text/csv');
            header('Content-Disposition: attachment; filename='.basename($file));
            header('Content-Transfer-Encoding: binary');
            header('Expires: 0');
            header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
            header('Pragma: public');
            header('Content-Length: ' . filesize($file));
            ob_clean();
            flush();
            readfile($file);
          //  unlink($file); // deletes the temporary file
        }
		
    }
	
	
	function machineprint_qr($machine_id)
    {
        $qr_code_config = array();
        $qr_code_config['cacheable'] = $this->config->item('cacheable');
        $qr_code_config['cachedir'] = $this->config->item('cachedir');
        $qr_code_config['imagedir'] = $this->config->item('imagedir');
        $qr_code_config['errorlog'] = $this->config->item('errorlog');
        $qr_code_config['ciqrcodelib'] = $this->config->item('ciqrcodelib');
        $qr_code_config['quality'] = $this->config->item('quality');
        $qr_code_config['size'] = $this->config->item('size');
        $qr_code_config['black'] = $this->config->item('black');
        $qr_code_config['white'] = $this->config->item('white');
        $this->ci_qr_code->initialize($qr_code_config);
        
        $machine_details = $this->machine->getMachineinfoById($machine_id);
        $image_name = $machine_id . ".png";
       
        
        $params['level'] = 'H';
        $params['size'] = 6;
        
        $params['savename'] = $qr_code_config['imagedir'] . $image_name;
      
  
        $this->ci_qr_code->generate($params);
        
        $this->data['qr_code_image_url'] = base_url() . $qr_code_config['imagedir'] . $image_name;
         	
       
        $this->machine->change_machineqr($machine_id, $image_name);

        $data['qr_code']	= $this->data['qr_code_image_url'];
        $data['machine_code']	=  $machine_details->machine_code;
        $data['machine_id']	=  $machine_details->machine_id;
        $file = $params['savename'];
		
		$this->load->view('admin/Getqrcode', $data);

    }

    
}
?>