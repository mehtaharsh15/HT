<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class UserGroup extends CI_Controller {

    function UserGroup() {
        parent :: __construct();
        $this->load->model('UserGroup_model', 'usergroup');
        $this->load->model('Common_model', 'common');
        $this->load->library('administration');
        $this->load->library('pagination');
    }

    function index() {
        $data['title'] = "User Group Information";
        $data['js'] = array("usergroup.js");
        //if ($this->common->admin_permission('UserGroups_View','Manage_Users','User_Groups'))
        if($this->user->id == 1)
        {
            $data['usergroup_count'] = $this->usergroup->get_usergroup_count();
            $data['usergroup_entry'] = $this->usergroup->get_usergroup(1);
            $this->load->view('admin/usergroup_manage', $data);
        }
        else
        {
            redirect('admin/noaccess/index');
        }
    }

    function insert() {
        $data['title'] = "Add New User Group";
        $data['Action'] = "Add";
        $data['js'] = array("usergroup.js");
        //if ($this->common->admin_permission('UserGroups_Add','Manage_Users','User_Groups'))
        if($this->user->id == 1)
        {
            if ($this->input->post('submit')) {
                if ($result = $this->usergroup->insert()) {
                    $this->session->set_flashdata('notification', 'Group information has been added successfully.');
                    redirect('admin/usergroup/index/');
                } else {
                    $this->session->set_flashdata('notification', 'Group information cant be added. Duplicate entry found.');
                    $data['usergroup_edit_entry'] = array(
                        'user_group_name' => $this->input->post('usergroup_name'),
                        'user_group_privileges' => json_encode($_POST)
                    );
                    $data['usergroupmsg'] = "User group already exists.";
                    $this->session->set_flashdata('usergroupmsg', 'User group already exists.');
                    $this->load->view('admin/usergroup_addedit', $data);
                }
            } elseif ($this->input->post('cancel')) {
                redirect('admin/usergroup/index/');
            } else {
                $this->load->view('admin/usergroup_addedit', $data);
            }
        }
        else
        {
            redirect('admin/noaccess/index');
        }
    }

    function edit() {
        $data['title'] = "Edit User Group Information";
        $data['Action'] = "Edit";
        $data['js'] = array("usergroup.js");
        //if($this->common->admin_permission('UserGroups_Edit','Manage_Users','User_Groups'))
        if($this->user->id == 1)
        {
            if ($this->input->post('submit')) {
                if ($result = $this->usergroup->update()) {
                    $this->session->set_flashdata('notification', 'Group information has been updated successfully.');
                    redirect('admin/usergroup/index/');
                } else {
                    $this->session->set_flashdata('notification', 'Group information cant be updated. Duplicate entry found.');
                    $data['usergroup_edit_entry'] = array(
                        'user_group_name' => $this->input->post('usergroup_name'),
                        'user_group_privileges' => json_encode($_POST),
                        'user_group_id' => $this->input->post('usergroup_id'),
                    );
                    $data['usergroupmsg'] = "User group already exists.";
                    $this->session->set_flashdata('usergroupmsg', 'User group already exists.');
                    //redirect('admin/usergroup/edit/' . $this->input->post('usergroup_id'));
                    $this->load->view('admin/usergroup_addedit', $data);
                }
            } elseif ($this->input->post('cancel')) {
                redirect('admin/usergroup/index/');
            } else {
                $data['usergroup_edit_entry'] = $this->usergroup->get_usergroup_edit($this->uri->segment(4));
                $this->load->view('admin/usergroup_addedit', $data);
            }
        }
        else
        {
            redirect('admin/noaccess/index');
        }
    }

    # change active status
    function changeactivestatus($isajax = 1) {
        //header('Content-Type: application/json');
        header('Content-Type: text/html; charset=utf-8');

        $UserGroupId = $this->input->post('user_group_id');
        if ($isajax == 1) {
            $this->usergroup->toggle_status($UserGroupId, $this->input->post('user_group_active'));

            echo $UserGroupId;
        }
        return;
    }
}
?>