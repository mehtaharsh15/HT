<?php
header('Access-Control-Allow-Origin: *');
defined('BASEPATH') OR exit('No direct script access allowed');
require APPPATH.'/libraries/REST_Controller.php';

class Webservice extends REST_Controller
{
    function Webservice()
    {
        parent :: __construct();
    }
	
    function register_get()
    {
		// load customer model to verify mobile no 
		//check requested mobile number exits or not. if not exit then register new customer other wise move to login page
		$this->load->model('customer_model', 'customer');
		
		//assign mobile no
		$mbl_no =  $this->get(mbl_no);
		
		//key value array of machine
		$customer_info = $this->customer->verify_customer_mobile($mbl_no);
		
		//define register array
		$register = array();
		
		//check customer info exits or not
		if(is_array($customer_info) && !empty($customer_info)) {
			$register['register'] = 'No';
			$register['cust_id'] = $customer_info['customer_id'];
		} else {
			//assign platform name, device uuid, device info			
			$platform = $this->get(platform);
			$device_uuid = $this->get(deviceid);
			$device_info = $this->get(deviceinfo);
			
			//register new customer 
			$inserted_id = $this->customer->Insert(trim($mbl_no), $platform, $device_uuid, $device_info);
			//check customer id exits or not
			if(!empty($inserted_id)) {
				//assign already exits value to array
				$register['register'] = 'Yes';
				$register['cust_id'] = $inserted_id;
			}
			
		}
		
		//$register = array('adsafsd');
		//check register array empty or not
        if($register)
        {
            $this->response($register, 200); // 200 being the HTTP response code
        }
        else
        {
            $this->response(array('error' => 'Couldn\'t find any $register!'), 404);
        }
    }
	
	function customerinfo_get()
	{
		//load customer model to edit profile
		$this->load->model('customer_model', 'customer');
			
		//edit customer info
		$customerinfo = $this->customer->getcustomerinfo($this->get(mbl_no));
		//$customer = array();

		if($customerinfo)
	    {
	        $this->response($customerinfo, 200); // 200 being the HTTP response code
	    }
	    else
	    {
		    $this->response(array('error' => 'Couldn\'t find any $customerinfo!'), 404);
	    }
	}

	function editprofile_get()
	{
		//assign mobile no,email, fname,lname
		$mbl_no = $this->get(mbl_no);
		$email 	= $this->get(email);
		$fname 	= $this->get(fname);
		$lname	= $this->get(lname);
		//load customer model to edit profile
		$this->load->model('customer_model', 'customer');
		
		//edit customer info
		$customer_info = $this->customer->update_profile($mbl_no, $email, $fname, $lname);
		//set succsess/error message base on info
		if($customer_info) {
			$customer['msg'] = "Profile has been updated successfully!!";
			$customer['title'] = "Success";
		} else{
			$customer['msg'] = "There was an error while updateing your profile";
			$customer['title'] = "Error";
			
		}
		
		if($customer)
        {
            $this->response($customer, 200); // 200 being the HTTP response code
        }
        else
        {
            $this->response(array('error' => 'Couldn\'t find any $customer!'), 404);
        }	
	}

	function faq_get()
	{
		//load faq model to edit profile
		$this->load->model('faq_model', 'faq');
		
		$faq_info = $this->faq->get_allfaq();
		
		if($faq_info)
		{
			$this->response($faq_info, 200); // 200 being the HTTP response code
		}
		else{
			$this->response(array('error' => 'Couldn\'t find any $faq_info!'), 404);
		}
	}
	
	function contactinfo_get()
	{
		//get conatct number from config. i.e fromm settings
		$this->load->library('system');
		 
		$contact_number = $this->system->company_mobile;
		
		//$contact_number	=	array("test");
		if($contact_number) {
			$this->response($contact_number, 200); // 200 being the HTTP response code
		} else {
			$this->response(array('error' => 'Couldn\'t find any $contact_number!'), 404);
		}
		
	}

	function sellinfo_get()
	{
		//load sell model to get sell information
		$this->load->model('sell_model', 'sell');
		
		//asign customer id
		$cust_id = 1;//$this->get(cust_id);
		$mbl_no = $this->get(mbl_no);
		$limit  = $this->get(limit);
		
		//get txn info base on customer id and mobile number
		$rsRecord = $this->sell->get_allsellinfo($cust_id);
			
		$txninfo	=	$rsRecord['sellinfo'];
		$monthyearinfo = $rsRecord['dateinfo'];
			
				
		//for dashboard wallet money
		if($limit != 0) 
		{
			//load sell model to get sell information
			$this->load->model('customer_model', 'customer');
			//get wallet amount base on customer id
			$info = $this->customer->getwalletcountbycustId($cust_id, 1);
			//print_r($info);
			$txninfo[0]['balance'] = $info[0]->balance;
		} else {
			$txninfo[0]['balance']	=	0;
			$txninfo[0]['year']	=	'';
			$txninfo[0]['month']	=	0;
		}
				
		//$contact_number	=	array("test");
		if($txninfo) {
			$this->response($txninfo, 200); // 200 being the HTTP response code
		} else {
			$this->response(array('error' => 'Couldn\'t find any $txninfo!'), 200);
		}	
	}
}
?>