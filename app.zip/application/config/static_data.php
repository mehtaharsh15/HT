<?php

#====================================================================================================
#	File Name		:	static_data.php
#====================================================================================================

global $asset;



$asset['SD_UserGroup_Permissions'] = array(
    'Dashboard' => array(
        'Title'                     		=> 'Dashboard',
        'Link'                      		=> 'home',
        'Icon'                      		=> 'icon-th-large',
        'Dashboard_Edit'            		=> 'Edit'
    ),
    'Management' => array(
        'Title'    => 'Management',
        'Icon'     => 'icon-th',
        'Submenu'  => array(
           
			  'Machine' => array(
                'Title'         => 'Machine',
                'Link'          => 'Machine',
            ),
			 'Customer' => array(
                'Title'         => 'Customer',
                'Link'          => 'Customer',
            ),
			 'Buy_Sell' => array(
                'Title'         => 'Buy/Sell',
                'Link'          => 'Buy',
            ),
			'Faq' => array(
                'Title'         => 'FAQ',
                'Link'          => 'Faq',
            )			
           
           
        ),
        
       
        
    ),
    'Manage_Users' => array(
        'Title' => 'Manage Users',
        'Icon'  => 'icon-user',
        'Submenu'  => array(
           /*  'Users' => array(
                'Title'         => 'Users',
                'Link'          => 'users',
            ), */
            'User_Groups' => array(
                'Title'         => 'User Groups',
                'Link'          => 'usergroup',
            )
        ),
        'Users' => array(
            'Title'         => 'Users',
            'Link'          => 'users',
            'Users_View'    => 'View',
            'Users_Add'     => 'Add',
            'Users_Edit'    => 'Edit',
            'Users_Delete'  => 'Delete'
        ),
        'User_Groups' => array(
            'Title'             => 'User Groups',
            'Link'              => 'usergroup',
            'UserGroups_View'   => 'View',
            'UserGroups_Add'    => 'Add',
            'UserGroups_Edit'   => 'Edit',
            'UserGroups_Delete' => 'Delete'
        )
    ),
    'Settings' => array(
        'Title'         => 'Settings',
        'Link'          => 'settings',
        'Icon'          => 'icon-wrench',
        //'Settings_Edit' => 'Edit'
        )
);

$asset['SD_PageSize'] = array(
    //'1'     => '1',	
    '5'     => '5',
    '10'    => '10',
    '20'    => '20',
    '30'    => '30',
    '50'    => '50',
    '100'   => '100'
);

$asset['SD_YesNo'] = array(
    'Yes'   => 'Yes',
    'No'    => 'No'
);

$asset['SD_YesNo_Int'] = array(
    '1' => 'Yes',
    '0' => 'No'
);

$asset['SD_Active'] = array(
    '1' => 'Active',
    '0' => 'Inactive'
);


$asset['SD_PageType'] = array(
    'SimplePage'    => 'Simple Page',
    'InternalLink'  => 'Internal Link',
    'ExternalLink'  => 'External Link',
    'HiddenLink'    => 'Hidden Page'
);

$asset['SD_Permission'] = array(
    'Add'       => '1',
    'Edit'      => '1',
    'Delete'    => '1',
    'View'      => '1',
    'Others'    => '1'
);

$asset['SD_PromiseTime'] = array(
    '1' => 'ASAP',
    '2' => 'AM',
    '3' => 'PM'
);

$asset['SD_GroupType'] = array(
    '1' => 'Cardiac',
    '2' => 'Family Practice',
    '3' => 'Orthopedics',
    '4' => 'Pediatrics',
    '5' => 'Women\'s Health'
);


?>