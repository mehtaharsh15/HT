<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['useragent']  = "hitechwallet";
$config['charset']	= "utf-8";
$config['mailtype']	= "html";
