<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Functions {
    function Functions()
    {
        $this->obj =& get_instance();
    }

    #=========================================================================================================================
    #	Function Name   :	getUniqueFilePrefix
    #	Purpose		:	Get Unique filename
    #	Return		:	Unique filename based on time
    #-------------------------------------------------------------------------------------------------------------------------
    function getUniqueFilePrefix()
    {
        list($usec, $sec)	= explode(" ",microtime());
        list($trash, $usec)	= explode(".",$usec);

        return (date("YmdHis").substr(($sec + $usec), -10).'_');
    }

    #=========================================================================================================================
    #	Function Name	:	buildSefUrl
    #	Purpose		:	Get Unique filename
    #	Return		:	Unique filename based on time
    #-------------------------------------------------------------------------------------------------------------------------
    function buildSefString($str)
    {
        $str = str_replace("'",					"",		$str); 	//replace ' with nothing
        $str = str_replace('"',					"",		$str); 	//replace " with nothing
        $str = preg_replace("/[^a-zA-Z0-9_-]/",	"-", 	$str); 	//convert non alphanumeric and non - _ to -
        $str = preg_replace ( "/-+/" , 			"-" , 	$str ); //convert multiple dashes to a single dash
        $str = preg_replace ( "/ +/" , 			" " , 	$str ); //convert multiple spaces to a single space
        $str = strtolower($str);
        return $str;
    }

    #=========================================================================================================================
    #	Function Name	:   buildURLFriendlyName
    #	Purpose		:   Build URL Friendly Name
    #	Return		:   URL Friendly String
    #-------------------------------------------------------------------------------------------------------------------------
    function buildURLFriendlyName($string)
    {
        #store the special charater into the array which is to be remove for URL Friendly name
        //$special_character_array = split('!@#$%^&*()+=[]\';,./{}|":<>?');
        //$string_array = str_split($string);
        $special_character_array = $this->str2arr('!@#$%^&*()+=[]\';,./{}|":<>?');
        $string_array = $this->str2arr($string);

        #loop through the string and remove the special character
        foreach($string_array as $char)
        {
            if ( !in_array($char,$special_character_array) )
            {
                $new_string .= $char;
            }
        }

        #remove trailing space
        $new_string = trim($new_string," ");

        #build the more safe url
        //$new_string = $this->buildSefString($new_string);
        $new_string = str_replace(' ',					"-",	$new_string); 	//replace " with nothing
        $new_string = str_replace("'",					"",		$new_string); 	//replace ' with nothing
        $new_string = str_replace('"',					"",		$new_string); 	//replace " with nothing
        //$new_string = preg_replace("/[^a-zA-Z0-9_-]/",	"-", 	$new_string); 	//convert non alphanumeric and non - _ to -
        $new_string = preg_replace ( "/-+/" , 			"-" , 	$new_string );  //convert multiple dashes to a single dash
        $new_string = preg_replace ( "/ +/" , 			" " , 	$new_string );  //convert multiple spaces to a single space

        $new_string = strtolower($new_string);

        return $new_string;
    }

    #=========================================================================================================================
    #	Function Name	:   RandomPassword
    #	Purpose		:   Generate random password
    #	Return		:   Return password
    #-------------------------------------------------------------------------------------------------------------------------
    function RandomPassword($num_letters)
    {
        $array = array(
                        "a","b","c","d","e","f","g","h","i","j","k","l",
                        "m","n","o","p","q","r","s","t","u","v","w","x","y",
                        "z","1","2","3","4","5","6","7","8","9"
                    );

        $uppercased = 3;

        mt_srand ((double)microtime()*1000000);

        for($i=0; $i<$num_letters; $i++)
            $pass .= $array[mt_rand(0, (count($array) - 1))];

        for($i=1; $i<strlen($pass); $i++)
        {
            if(substr($pass, $i, 1) == substr($pass, $i-1, 1))
                $pass = substr($pass, 0, $i) . substr($pass, $i+1);
        }

        for($i=0; $i<strlen($pass); $i++)
        {
            if(mt_rand(0, $uppercased) == 0)
                $pass = substr($pass,0,$i) . strtoupper(substr($pass, $i,1)) .
                substr($pass, $i+1);
        }

        $pass = substr($pass, 0, $num_letters);

        return($pass);
    }

    #=========================================================================================================================
    #	Function Name   :	genRandomString
    #-------------------------------------------------------------------------------------------------------------------------
    function genRandomString($length = 10)
    {
        $characters = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        $string = "";

        for ($p = 0; $p < $length; $p++) {
            $string .= $characters[mt_rand(0, strlen($characters))];
        }

        return $string;
    }

    #=========================================================================================================================
    #	Function Name	:   encrypt
    #	Purpose		:   Encrypt the string
    #	Return		:   Return cipher text of the provided plain text
    #-------------------------------------------------------------------------------------------------------------------------
    function encrypt($plaintext, $isstrtolower = 1)
    {
        $cipher = mcrypt_module_open($this->obj->config->item('encryption_algo'),'',$this->obj->config->item('encryption_mode'),'');
        mcrypt_generic_init($cipher, $this->obj->config->item('encryption_key'), $this->obj->config->item('encryption_iv'));
        /*if($isstrtolower)
            $encrypted = base64_encode(mcrypt_generic($cipher,strtolower($plaintext)));
        else
            $encrypted = base64_encode(mcrypt_generic($cipher,strtolower($plaintext)));*/
        if($isstrtolower)
                    $encrypted = base64_encode(mcrypt_generic($cipher,strtolower($plaintext)));
            else
                    $encrypted = base64_encode(mcrypt_generic($cipher,$plaintext));
        $removedPadding = rtrim($encrypted, "\0");
        mcrypt_generic_deinit($cipher);
        return $removedPadding;
    }

    #=========================================================================================================================
    #	Function Name	:   decrypt
    #	Purpose		:   Decrypt the string
    #	Return		:   Return plain text of the provided cipher text
    #-------------------------------------------------------------------------------------------------------------------------
    function decrypt($ciphertext)
    {
        $cipher = mcrypt_module_open($this->obj->config->item('encryption_algo'),'',$this->obj->config->item('encryption_mode'),'');
        mcrypt_generic_init($cipher, $this->obj->config->item('encryption_key'), $this->obj->config->item('encryption_iv'));
        $decrypted = mdecrypt_generic($cipher,base64_decode($ciphertext));
        mcrypt_generic_deinit($cipher);
        return $decrypted;
    }

    #=========================================================================================================================
    #	Function Name	:   str2arr
    #	Purpose		:   alternate of str_split
    #	Return		:   URL Friendly String
    #-------------------------------------------------------------------------------------------------------------------------
    function str2arr($str) {
        $chararray = array();
        for($i=0; $i < strlen($str); $i++){
            array_push($chararray,$str{$i});
        }
        return $chararray;
    }

    function getDistance($lat1, $lon1, $lat2, $lon2, $isajax = FALSE)
    {
        if($lat1=='' || $lon1=='' || $lat2=='' || $lon2=='')
            $distance = "Not Available";
            //return FALSE;
        else
        //echo ((ACOS(SIN( $zip1Data['lat'] * PI() / 180) * SIN( $zip2Data['lat']  * PI() / 180) + COS($zip1Data['lat'] * PI() / 180) * COS($zip2Data['lat'] * PI() / 180) * COS(( $zip1Data['lon'] - $zip2Data['lon']) * PI() / 180)) * 180 / PI()) * 60 * 1.1515)."<br/>";
        $distance = round(((ACOS(SIN( $lat1 * PI() / 180) * SIN( $lat2  * PI() / 180) + COS($lat1 * PI() / 180) * COS($lat2 * PI() / 180) * COS(( $lon1 - $lon2) * PI() / 180)) * 180 / PI()) * 60 * 1.1515));

        if($isajax)
        {
            header('Content-type: application/json');
            echo json_encode($distance);
		
        }
        else
            return $distance;
    }

    function getDistanceByZips($zip1, $zip2, $isajax = FALSE)
    {
        if($zip1=='' || $zip2=='')
            return FALSE;

        $zip1Data = $this->getInfoByZip($zip1);
        $zip2Data = $this->getInfoByZip($zip2);
        /*echo "<pre>";
        print_r($zip1Data);
        print_r($zip2Data);
        echo "</pre>";*/
        $distance = round(((ACOS(SIN( $zip1Data['lat'] * PI() / 180) * SIN( $zip2Data['lat']  * PI() / 180) + COS($zip1Data['lat'] * PI() / 180) * COS($zip2Data['lat'] * PI() / 180) * COS(( $zip1Data['lon'] - $zip2Data['lon']) * PI() / 180)) * 180 / PI()) * 60 * 1.1515));

        if($isajax)
        {
            header('Content-type: application/json');
            echo json_encode($distance);
        }
        else
            return $distance;
    }
	/*
	$interval can be:
	y - Number of full years
	q - Number of full quarters
	m - Number of full months
	d - Number of full days
	w - Number of full weeks
	h - Number of full hours
	n - Number of full minutes
	s - Number of full seconds (default)
	*/

    function datediff($interval, $datefrom, $dateto, $using_timestamps = FALSE)
    {

            if (!$using_timestamps) 
            {

                    $datefrom = strtotime($datefrom, 0);
                    $dateto = strtotime($dateto, 0);
            }

            $difference = $dateto - $datefrom; // Difference in seconds

            switch($interval) 
            {
                    case 'y': // Number of full years
                    $years_difference = floor($difference / 31536000);
                    if (mktime(date("H", $datefrom),
                                date("i", $datefrom),
                                date("s", $datefrom),
                                date("n", $datefrom),
                                date("j", $datefrom),
                                date("Y", $datefrom)+$years_difference) > $dateto) {

                    $years_difference--;
                    }
                    if (mktime(date("H", $dateto),
                                date("i", $dateto),
                                date("s", $dateto),
                                date("n", $dateto),
                                date("j", $dateto),
                                date("Y", $dateto)-($years_difference+1)) > $datefrom) {

                    $years_difference++;
                    }
                    $datediff = $years_difference;
                    break;

                    case "q": // Number of full quarters
                    $quarters_difference = floor($difference / 8035200);
                    $quarters_difference--;
                    $datediff = $quarters_difference;
                    break;

                    case "m": // Number of full months
                    $datediff = floor($difference / 2678400);
                    break;

                    case "w": // Number of full weeks
                    $datediff = floor($difference / 604800);
                    break;

                    case "d": // Number of full days
                    $datediff = floor($difference / 86400);
                    break;

                    case "h": // Number of full hours
                    $datediff = floor($difference / 3600);
                    break;

                    case "n": // Number of full minutes
                    $datediff = floor($difference / 60);
                    break;

                    default: // Number of full seconds (default)
                    $datediff = $difference;
                    break;
            }

            return $datediff;
    }
    #=========================================================================================================================
    #	Function Name	:   getTimestampOfYesterdayStart
    #	Purpose		:   get the timestamp of yesterday 12 AM
    #	Return		:   the timestamp of yesterday 12 AM
    #-------------------------------------------------------------------------------------------------------------------------
    function getTimestampOfYesterdayStart($date = '') {
        if(empty($date))
        {
            $day   = date('j');	   # Numeric representation of a day, without leading zeros
            $month = date('n'); # Numeric representation of a month, without leading zeros
            $year  = date('Y');
        }
        else
        {
            list($year, $month, $day) = split('[/.-]', $date);
        }
        #Tiestamp of the first day of the month
        //echo $firstday = date("l jS \of F Y h:i:s A", mktime(0,0,0,$month,$day-1,$year));
        $firstdaytimestamp = mktime(0,0,0,$month,$day-1,$year);
        return $firstdaytimestamp;
    }
    #=========================================================================================================================
    #	Function Name	:   getTimestampOfYesterdayEnd
    #	Purpose		:   get the timestamp of yesterday 11:59:59 PM
    #	Return		:   the timestamp of yesterday 11:59:59 PM
    #-------------------------------------------------------------------------------------------------------------------------
    function getTimestampOfYesterdayEnd($date = '') {
        if(empty($date))
        {
            $day   = date('j');	   # Numeric representation of a day, without leading zeros
            $month = date('n'); # Numeric representation of a month, without leading zeros
            $year  = date('Y');
        }
        else
        {
            list($year, $month, $day) = split('[/.-]', $date);
        }
        #Tiestamp of the first day of the month
        //echo $firstday = date("l jS \of F Y h:i:s A", mktime(23,59,59,$month,$day-1,$year));
        $firstdaytimestamp = mktime(23,59,59,$month,$day-1,$year);
        return $firstdaytimestamp;
    }
    #=========================================================================================================================
    #	Function Name	:   getTimestampOfFirstDateOfMonth
    #	Purpose		:   get the timestamp of the first date of the month
    #	Return		:   the timestamp of the first date of the month
    #-------------------------------------------------------------------------------------------------------------------------
    function getTimestampOfFirstDateOfMonth($date = '') {
        if(empty($date))
        {
            $day   = date('j');	   # Numeric representation of a day, without leading zeros
            $month = date('n'); # Numeric representation of a month, without leading zeros
            $year  = date('Y');
        }
        else
        {
            list($year, $month, $day) = split('[/.-]', $date);
        }
        #Tiestamp of the first day of the month
        //echo $firstday = date("l jS \of F Y h:i:s A", mktime(0,0,0,$month,1,$year));
        $firstdaytimestamp = mktime(0,0,0,$month,1,$year);
        return $firstdaytimestamp;
    }
    #=========================================================================================================================
    #	Function Name	:   getTimestampOfFirstDateOfYear
    #	Purpose		:   get the timestamp of the first date of the year
    #	Return		:   the timestamp of the first date of the year
    #-------------------------------------------------------------------------------------------------------------------------
    function getTimestampOfFirstDateOfYear($date = '') {
        if(empty($date))
        {
            $day   = date('j');	   # Numeric representation of a day, without leading zeros
            $month = date('n'); # Numeric representation of a month, without leading zeros
            $year  = date('Y');
        }
        else
        {
            list($year, $month, $day) = split('[/.-]', $date);
        }
        #Tiestamp of the first day of the month
        //echo $firstday = date("l jS \of F Y h:i:s A", mktime(0,0,0,1,1,$year));
        $firstdaytimestamp = mktime(0,0,0,1,1,$year);
        return $firstdaytimestamp;
    }
    function time_elapsed_string($datetime, $full = false) {
        $now = new DateTime;
        $ago = new DateTime($datetime);
        //echo $now." - ".$ago."----------";
        $diff = $now->diff($ago);

        $diff->w = floor($diff->d / 7);
        //$diff->d -= $diff->w * 7;
        /*echo $diff->w." week - day ".$diff->d." - ".$diff->h." hour - min ".$diff->i." sec ".$diff->s." - <br/>";
        echo $datetime." - <br/>";*/
        if($diff->d > 1)
            $return = $datetime;
        elseif($diff->d == 1)
            $return = "Yesterday";
        elseif($diff->h > 1)
            $return = $diff->h." hours ago.";
        elseif($diff->h == 1)
            $return = $diff->h." hour ago.";
        elseif($diff->i > 1)
            $return = $diff->i." minutes ago.";
        elseif($diff->i == 1)
            $return = $diff->i." minute ago.";
        else
            $return = "just now";
        return $return;
        /*$string = array(
            'y' => 'year',
            'm' => 'month',
            'w' => 'week',
            'd' => 'day',
            'h' => 'hour',
            'i' => 'minute',
            's' => 'second',
        );
        foreach ($string as $k => &$v) {
            //if($k == 'd')
            //{
                //if ($diff->$k && ($diff->$k > 1)) {
                    //$v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? 's' : '');
                    //$v = $ago;
                ///} //else {
                    //unset($string[$k]);
                //}
            //}
            //else
            //{
                if ($diff->$k) {
                    $v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? 's' : '');
                } else {
                    unset($string[$k]);
                }
            //}
        }

        if (!$full) $string = array_slice($string, 0, 1);
        return $string ? implode(', ', $string) . ' ago' : 'just now';*/
    /*$mins = $diff->i;
    $hrs = $diff->h;
    $days = $diff->d;
    //echo $mins." - ".$hrs." - ".$days."<br/>";
    if($mins < 1)
        $showDate = strTime;
    else if($mins == 1)
        $showDate = $mins." minute ago.";
    else if($mins < 60)
        $showDate = $mins." minutes ago.";
    else if($hrs == 1 && Math.floor($mins % 60) == 0)
        $showDate = $hrs." hour ago.";
    else if($hrs == 1 && Math.floor($mins % 60) == 1)
        $showDate = $hrs." hour and ".floor($mins % 60)." minute ago.";
    else if($hrs == 1 && Math.floor($mins % 60) > 1)
        $showDate = $hrs." hour and ".floor($mins % 60)." minutes ago.";
    else if($hrs > 1 && $hrs < 24 && Math.floor($mins % 60) == 0)
        $showDate = $hrs." hours ago.";
    else if($hrs > 1 && $hrs < 24 && Math.floor($mins % 60) == 1)
        $showDate = $hrs." hours and ".floor($mins % 60)." minute ago.";
    else if($hrs > 1 && $hrs < 24 && Math.floor($mins % 60) > 1)
        $showDate = $hrs." hours and ".floor($mins % 60)." minutes ago.";
    else if($days == 1)
        $showDate = "Yesterday";
    else
        $showDate = $ago;
    return $showDate;
    //return "";*/
    }
}
?>