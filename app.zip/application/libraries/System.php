<?php defined('BASEPATH') OR exit('No direct script access allowed');
	class System {
		
		var $web_config	= array();
		
		function System()
		{
			#get CI object
			$this->obj =& get_instance();
			
			# read web_config table data ane update
			$this->get_config();
		}

		function get_config()
		{
			$query = $this->obj->db->get('web_config');

			foreach ($query->result() as $row)
			{
				$var = $row->config_name;
				$this->$var = $row->config_value ;
				$this->web_config[$row->config_name]	= $row->config_value;
			}
		}
	}
?>