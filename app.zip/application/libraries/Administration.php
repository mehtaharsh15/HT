<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Administration {
	function Administration()
	{
		$this->obj =& get_instance();
		if ( !$this->obj->user->logged_in && $this->obj->uri->segment(2) != 'login'  && $this->obj->uri->segment(1) != 'cron' && $this->obj->uri->segment(1) != 'webservice' && $this->obj->uri->segment(1) != 'emailverify')
		{
			redirect('admin/login');
			exit;
		}
	}
}
?>