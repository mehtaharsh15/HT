<?php defined('BASEPATH') OR exit('No direct script access allowed');
class User {

    var $id = 0;
    var $logged_in = FALSE;
    var $username = '';
    var $user_group_id = '';
    var $user_unique_id = '';
    var $table = 'user_master';

    function User()
    {
        $this->obj =& get_instance();
        $this->_session_to_library();
    }

    function _prep_password($password)
    {
        // Salt up the hash pipe
        // Encryption key as suffix.
        return $this->obj->encrypt->sha1($password.$this->obj->config->item('encryption_key'));
    }

    function _session_to_library()
    {
        // Pulls session data into the library.
        $this->id               = $this->obj->session->userdata('id');
        $this->username         = $this->obj->session->userdata('username');
        $this->user_group_id    = $this->obj->session->userdata('user_group_id');
        $this->user_unique_id   = $this->obj->session->userdata('user_unique_id');
        $this->logged_in        = $this->obj->session->userdata('logged_in');
    }

    function _start_session($user)
    {
        // $user is an object sent from function login();
        // Let's build an array of data to put in the session.
        $data = array(
                        'id' 		=> $user->user_id,
                        'username' 	=> $user->user_name,
                        'user_group_id'	=> $user->user_group_id,
                        //'user_unique_id'=> $user->user_id.time(),
                        'user_unique_id'=> $user->user_id,
                        'logged_in'	=> TRUE
                    );
        /*echo "<pre>";
        print_r($data);
        echo "</pre>";die;*/
        $this->obj->session->set_userdata($data);
        $this->_session_to_library();
    }

    function _destroy_session()
    {
        $data = array(
                        'id' 		=> 0,
                        'username' 	=> '',
                        'user_group_id'	=> '',
                        'user_unique_id'=> '',
                        'logged_in'	=> FALSE
                    );

        foreach ($data as $key => $value)
        {
            $this->$key = $value;
        }

        $this->obj->session->unset_userdata($data);
        $this->obj->session->sess_destroy();
    }

    function login($username, $password)
    {
        //echo "hi";die;
        $query = $this->obj->db->get($this->table, 1);

        // First up, let's query the DB.
        // Prep the password to make sure we get a match.
        // And only allow active members.
        $this->obj->db->where('user_name', $username);
        $this->obj->db->where('user_password', md5($password));
        $this->obj->db->where('user_active', '1');
        $query = $this->obj->db->get($this->table, 1);
        //echo $query->num_rows()."-----------";
        if ( $query->num_rows() == 1 )
        {
            // We found a user!
            // Let's save some data in their session/cookie/pocket whatever.
            $user = $query->row();
//print_r($user);
            #Create object of the Functions class
            $objFuncLib = new Functions();
            $daysFromLastPasswordChange      = $objFuncLib->datediff('d',$user->user_password_last_changed,time(),TRUE);
            //echo $this->obj->system->force_password_changes;die;
            //echo $daysFromLastPasswordChange      = $objFuncLib->datediff('d',$user->user_password_last_changed,time(),FALSE);
            //echo "<pre>".date("Y-m-d",time()).date("Y-m-d",$user->user_password_last_changed).strtotime('2013-08-12');
            /*echo "<pre>";
            print_r($user = $query->row());
            echo "</pre>";die;*/
            $this->_start_session($user);
            $this->obj->session->set_flashdata('user', 'Login successful...');
            $duedays = 0;
            if($this->obj->system->force_password_changes > 0 && isset($this->obj->system->force_password_changes) && is_numeric($this->obj->system->force_password_changes) )
               $duedays = $this->obj->system->force_password_changes;
			   
			//echo $duedays?$duedays:90;
			//echo  $daysFromLastPasswordChange >= $duedays?$duedays:90 && $daysFromLastPasswordChange > 0;
            if(empty($user->user_password_last_changed) || ($daysFromLastPasswordChange >= ($duedays?$duedays:90) && $daysFromLastPasswordChange > 0) )
            {
                //echo "hi";die;
                //redirect('admin/changepassword','location');
                return 'ForcePasswordChange';
            }
            return TRUE;
        }
        else
        {
            // Login failed...
            // Couldn't find the user,
            // Let's destroy everything just to make sure.
            $this->_destroy_session();
            $this->obj->session->set_flashdata('user', 'Login failed...');

            return FALSE;
        }
    }

    function logout()
    {
        $this->_destroy_session();
        $this->obj->session->set_flashdata('user', 'You are now logged out');
    }

 }
?>