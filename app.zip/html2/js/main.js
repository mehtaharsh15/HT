$(document).ready(function(){
	
	//NAVIGATION
	$(".button-collapse").sideNav();
	
	
	//NUMBER COUNT
	$('.odometer').html(475.25);
	
	//SELECT BOX
	$('select').material_select();
	
	//Modal call
	$('.modal').modal();
	
	
	//Go to Order History Tab
	$('.ohistory').click(function() {
		$('.mywallet .tabs .tab a').removeClass('active');
		$('.mywallet .tabs .tab a.ohistorytab').addClass('active');
	});
	
	
	$( ".login-form .input-field input.mobile-number" ).focus(function() {
	  $('.login-form .input-field span').show();
	});
	$( ".login-form .input-field input.mobile-number" ).focusout(function() {
	  $('.login-form .input-field span').hide();
		
		if ($(".login-form .input-field input.mobile-number").val().length != 0){
			$('.login-form .input-field span').show();
		};
	});
	

	if ($(".login-form .input-field input.mobile-number").val().length != 0){
		alert('hi');
	};
	
	
	
	
	
	
	
});