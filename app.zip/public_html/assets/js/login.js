$(document).ready(function() {
	// validate signup form on keyup and submit
	$("#frmlogin").validate({
		rules: 
		{
			username: 
			{
				required: true
			},
			password: 
			{
				required: true,
				minlength: 6
			}
		},
		messages: 
		{
			username: 
			{
				required: "Please enter username"
			},
			password: 
			{
				required: "Please enter password",
				minlength: "Password must be at least 6 characters long"
			}
		}
	});
});