function confirmSubmit(frm)
{
	with(frm)
	{
		if(frm.company_name.value == '')
		{
			alert("Please enter company name.");
			frm.company_name.focus();
			return false;
		}
		if(frm.company_address.value == '')
		{
			alert("Please enter company address.");
			frm.company_address.focus();
			return false;
		}
		if(frm.company_mobile.value == '')
		{
			alert("Please enter company mobile.");
			frm.company_mobile.focus();
			return false;
		}
		if(frm.company_email.value == '')
		{
			alert("Please enter company email.");
			frm.company_email.focus();
			return false;
		}
		if(frm.site_name.value == '')
		{
			alert("Please enter site name.");
			frm.site_name.focus();
			return false;
		}
		if(frm.from_email_address.value == '')
		{
			alert("Please enter email address.");
			frm.from_email_address.focus();
			return false;
		}
		if (!(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(frm.from_email_address.value)))
		{
			alert("Please enter valid email address.")
			frm.from_email_address.focus();
			return (false)
		}
	}
}
