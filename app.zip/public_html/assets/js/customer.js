$(function() {
 
  $("form[name='frmcustomer']").validate({
 
    rules: {
       email: {
		 required: true,
        
        email: true
		}
	   },
	    messages: {
		email: "Please enter a valid email address "
		},
		  submitHandler: function(form) {
      form.submit();
    }
  });
});
