$(document).ready(function() {
	//$(".phone").mask("(999) 999-9999");
	$("#form" ).validate({
		/*rules: {
			client_logo: {
				required: false,
				extension: "jpg|jpeg|png"
			}
		}*/
	});

	/*if ($.fn.duplicate_remove)
	{
		$('.dupBox').duplicate_remove({
			'limit' : 100,
			'duplicate' : {
				'actDiv': 'actClass',
				'sign'	: ' ',
				'text'	: 'Add',
				'href'	: '#more',
				'speed' : 100
			},
			'remove' : {
				'actDiv': 'actClass',
				'sign'	: ' ',
				'text'	: 'Remove',
				'href'	: '#less',
				'speed' : 250
			}
		});
	}
	
	bindData();*/
});

function bindData()
{
	//bind data here for dynamically clone content
	$("[name*='groups_client_group_id']").unbind();
	$("[name*='groups_client_group_id']").change(function() {
		//$("#loaderGroup").hide();
		var groupId 	= $(this).val();
		$parent_node 	= $(this).parent().parent();
		$physician_ele 	= $parent_node.find("[name*='groups_client_physician_id']");
		//alert(groupId);

		if(groupId != 0)
		{
			var phyrequest = $.ajax({
								url: baseurl+"admin/physician/get_all_physician_by_groupid/1/",
								type: "POST",
								data: {group_id : groupId},
								dataType: 'json'
							});
							
			phyrequest.done(function(data) {
				if(data)
				{
					//$("#physician_id option").remove();
					$physician_ele.empty();
					//$('<option>').val(0).text("Please select a Physician").appendTo($physician_ele);
					$('<option>').text("Select Physician").appendTo($physician_ele);
					$.each(data, function (k, v) {
						$('<option>').val(k).text(v).appendTo($physician_ele);
					});
					
					//$physician_ele.prop("disabled",false);
					//$('#nextBtn').removeClass("btn-success");
				}
				//$("#loaderGroup").hide();
			});
			
			phyrequest.fail(function(jqXHR, textStatus) {
				alert("Request failed: " + textStatus);
				//$("#loaderGroup").hide();
			});
		}
		else
		{
			$physician_ele.empty();
			$('<option>').val(0).text("Please select a Group first").appendTo($physician_ele);
			//$physician_ele.prop("disabled",true);
			//$('#nextBtn').removeClass("btn-success");
		}
	});
}

function CheckUncheckAll()
{
	var checks = document.getElementsByName('client_list[]');
	for (i = 0; i < checks.length; i++)
	{
		if(checks[i].checked == true) 
			checks[i].checked = false;
		else
			checks[i].checked = true;
	}
}


function confirmDeleteClientlist(frm)
{
	with(frm)
	{
		var flag = false;
		str = '';
		field = document.getElementsByName('client_list[]');
		
		for (i = 0; i < field.length; i++)
		{
			if(field[i].checked == true)
			{ 
				flag = true;
				break;
			}
			else
				field[i].checked = false;
		}
		
		if(flag == false)
		{
			alert("Please select atleast one client to delete.");
			return false;
		}
	}
	
	var agree=confirm("Are you sure to delete the selected client?");
	if (agree)
	{
		//window.location="index.php?page=keyword&action=deleteselected";
		frm.action.value = "deleteselected";
		frm.submit();
		return true ;
	}
	else
		return false ;
}