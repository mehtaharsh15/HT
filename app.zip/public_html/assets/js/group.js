$(document).ready(function() {
	//$(".phone").mask("(999) 999-9999");
	$("#form").validate();
});

function CheckUncheckAll()
{
	var checks = document.getElementsByName('group_list[]');
	for (i = 0; i < checks.length; i++)
	{
		if(checks[i].checked == true) 
			checks[i].checked = false;
		else
			checks[i].checked = true;
	}
}


function confirmDeleteGrouplist(frm)
{
	with(frm)
	{
		var flag = false;
		str = '';
		field = document.getElementsByName('group_list[]');
		
		for (i = 0; i < field.length; i++)
		{
			if(field[i].checked == true)
			{ 
				flag = true;
				break;
			}
			else
				field[i].checked = false;
		}
		
		if(flag == false)
		{
			alert("Please select atleast one group to delete.");
			return false;
		}
	}
	
	var agree=confirm("Are you sure to delete the selected group?");
	if (agree)
	{
		//window.location="index.php?page=keyword&action=deleteselected";
		frm.action.value = "deleteselected";
		frm.submit();
		return true ;
	}
	else
		return false ;
}