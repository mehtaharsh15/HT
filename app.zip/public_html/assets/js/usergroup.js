$(document).ready(function() {
    $("#form").validate({
            rules: {
                user_group_name: {
                    minlength: 2,
                    required: true
                }
            },
            highlight: function(label) {
            $(label).closest('tr.control-group').addClass('error');
        },
        success: function(label) {
            label.closest('.control-group').addClass('success');
                    /*.text('OK!').addClass('valid')*/
        },
        messages: {
            user_group_name: {
                required: "Please enter User group"
            }
        }
    });
});


function confirmDeleteUserGroup(frm, usergroup_id)
{
    with(frm)
    {
        var agree =confirm("Are you sure to delete this Group ?");
        if(agree)
        {
            frm.usergroupid.value = usergroup_id;
            frm.action.value = "delete";
            frm.submit();
        }
    }
}

function Check_UncheckClick(fld , module_name , parent_module_name, parent_parent_module_name , cnt_permission)
{
    var checkboxFilter;
    if(parent_parent_module_name != null && parent_parent_module_name != '')
    {
        checkboxFilter = 'input[id^="user_group_privileges['+parent_parent_module_name+']['+parent_module_name+']['+module_name+']"]';
    }
    else if(parent_module_name != null && parent_module_name != '')
    {
        checkboxFilter = 'input[id^="user_group_privileges['+parent_module_name+']['+module_name+']"]';
    }
    else
    {
        checkboxFilter = 'input[id^="user_group_privileges['+module_name+']"]';
    }
    $(checkboxFilter).each(function(){
        $(this).prop("checked", fld.checked);
    });
}