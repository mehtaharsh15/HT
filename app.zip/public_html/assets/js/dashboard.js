//$('#socket_link').val();
var socket = io.connect($('#socket_link').val());
/*var socket = io.connect($('#socket_link').val(),{
            'connect timeout': 500,
            'reconnect': true,
            'reconnection delay': 500,
            'reopen delay': 500,
            'max reconnection attempts': 10
        });*/
var tablePatientId = '';
var msgId = '';
var timeout;
//var socket = io.connect("http://rockhopperzsg.local:2020");

// RT Chat starts here.
if ($('#operator_id').val() != "") {
    var joinid = "operator_"+$('#operator_id').val();
	//alert(joinid);
    /*socket.emit("checkOperator", { operator: joinid}, function (res) {
        alert(res);
        if(res == 0)*/
            socket.emit("join", joinid);
    //});
    ready = true;
}
// RT Chat ends here.

//Send pings for keeping the connection alive
socket.on('ping', function(data){
    //alert('ping received');
      socket.emit('pong', {beat: 1});
});

// RT chat starts here
socket.on("private", function(data) {
    //var currentMsgUser = $("#msg_user_id").val(patientId);
    //$('#operatorID').val(data.from);
    console.log('from');
    console.log(data.from);
    console.log('msg');
    console.log(data.msg);
    var date = new Date();
    var n = date.toDateString();
    //var time = date.toLocaleTimeString();
    //var time = timestampConversion(date.getTime());
    var time = timestampConversion();
    //alert(date+' '+n + ' ' + time+' '+date.getTime());
    //alert(time+' '+Date.now()+' '+date);
    var from = data.from;
    //alert($('#operator_id').val());
    if(from != "operator_"+$('#operator_id').val()){
        var res = from.substring(5);
        //alert(tablePatientId+' '+res+' '+from+' '+data.msg);
        if(tablePatientId)
            $("#tblMsgReply"+res).append('<tr class="gradeC"><td><div class="floatlft msgwidth50">'+data.msg+'<br/><small><i>'+time+'</i></small></div></td></tr>');
            //$("#tblMsgReply"+tablePatientId).append('<tr class="gradeC"><td><div class="floatlft msgwidth50">'+data.msg+'<br/><small><i>'+time+'</i></small></div></td></tr>');
        else
            $("#tblMsgReply"+res).append('<tr class="gradeC"><td><div class="floatlft msgwidth50">'+data.msg+'<br/><small><i>'+time+'</i></small></div></td></tr>');
        $(".msgdiv").animate({ scrollTop: $("#tblMsgReply"+res).height() }, "slow");
        //$(".msgdiv").animate({ scrollTop: $(".msgdiv").attr("scrollHeight") }, "slow");
    }
});

socket.on("error", function(msg) {
    console.log("There was an error sending the message. Please try again later!");
});


socket.on("sendMessageNotify", function(patientSignonID) {
	clearTimeout(timeout);    
});
// RT chat ends here

function timestampConversion()
{
    // Get hours, minutes and seconds starts here
    //var datePast = new Date(msg_created_time*1000);
    var datePast = new Date();
    var dateNow = new Date();
    var seconds = Math.floor(((dateNow) - datePast)/1000);
    var mins = Math.floor(seconds/60);
    var hrs = Math.floor(mins/60);
    var days = Math.floor(hrs/24);
    
    /*hrs = hrs-(days*24);
    mins = mins-(days*24*60)-(hrs*60);
    seconds = seconds-(days*24*60*60)-(hrs*60*60)-(mins*60);*/
    // Get hours, minutes and seconds ends here

    //var dt = new Date(msg_created_time*1000);
    var dt = new Date();
    var months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    var hours = ("0" + dt.getHours()).slice(-2);
    var minutes = ("0" + dt.getMinutes()).slice(-2);
    var ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12;
    hours = hours ? hours : 12; // the hour '0' should be '12'
    minutes = minutes < 10 ? minutes : minutes;
    var strTime = hours + ':' + minutes + ' ' + ampm;
    var showDate = months[dt.getMonth()] + " " + ("0" + dt.getDate()).slice(-2) + ", " + dt.getFullYear() + " " + strTime;

    if(mins < 1)
        showDate = strTime;
    else if(mins == 1)
        showDate = mins + " minute ago.";
    else if(mins < 60)
        showDate = mins + " minutes ago.";
    else if(hrs == 1 && Math.floor(mins % 60) == 0)
        showDate = hrs + " hour ago.";
    else if(hrs == 1 && Math.floor(mins % 60) == 1)
        showDate = hrs + " hour and " + Math.floor(mins % 60) + " minute ago.";
    else if(hrs == 1 && Math.floor(mins % 60) > 1)
        showDate = hrs + " hour and " + Math.floor(mins % 60) + " minutes ago.";
    else if(hrs > 1 && hrs < 24 && Math.floor(mins % 60) == 0)
        showDate = hrs + " hours ago.";
    else if(hrs > 1 && hrs < 24 && Math.floor(mins % 60) == 1)
        showDate = hrs + " hours and " + Math.floor(mins % 60) + " minute ago.";
    else if(hrs > 1 && hrs < 24 && Math.floor(mins % 60) > 1)
        showDate = hrs + " hours and " + Math.floor(mins % 60) + " minutes ago.";
    else if(days == 1)
        showDate = "Yesterday";
    else
        showDate = months[dt.getMonth()] + " " + ("0" + dt.getDate()).slice(-2) + ", " + dt.getFullYear() + " " + strTime;
    //alert(showDate+'fn');
    return showDate;
}
function sendMsgReply(patientSignonID,patientId, isdirectmessage, reloadframe,clientNickname)
{
    //$(this).attr('disabled','disabled');
    //alert(patientSignonID+' '+patientId);
    tablePatientId = patientId;
    if(isdirectmessage == true)
    {
        $("#send"+patientSignonID).prop("disabled",true);
        var reply   = $("#patient_msg_reply"+patientSignonID).val();
    }
    else
    {
        $("#send"+patientId).prop("disabled",true);
        var reply   = $("#patient_msg_reply"+patientId).val();
    }
    //alert(reply);
    reply=reply.replace(/(?:\r\n|\r|\n)/g, '<br />');
    if(reply == '' || typeof reply == 'undefined')
    {
        //alert($('#loggedinuser').html());
        alert("Please enter message to be sent.");
        if(isdirectmessage == true)
        {
            $("#patient_msg_reply"+patientSignonID).focus();
            $("#send"+patientSignonID).prop("disabled",false);
        }
        else
        {
            $("#patient_msg_reply"+patientSignonID).focus();
            $("#send"+patientId).prop("disabled",false);
        }
        //$(this).removeAttr('disabled');
        return false;
    }
    else
    {
        //var timeLastLoaded = $('#timeLastLoaded').val();
        /*var patientSignOnId = 0;
        var patientId = 0;
        if(isdirectmessage == true)
            patientSignOnId = patientSignonID
        else
            patientId = patientSignonID*/

            /*if(isdirectmessage == true)
            {
                if($("#msgcount"+patientSignonID).val() == 0)
                    $("#tblMsgReply"+patientSignonID).html('');
            }
            else
            {
                if($("#msgcount"+patientId).val() == 0)
                    $("#tblMsgReply"+patientId).html('');
            }*/
       

        var sendreply = $.ajax({
                                    url: baseurl+"admin/home/sendMsgReply/",
                                    type: "POST",
                                    async:false,
                                    data: {patient_msg_patient_id : patientId, patient_msg_signon_id : patientSignonID, patient_msg_reply : reply, isajax : 1},
                                    dataType: 'json'
                            });

        sendreply.done(function(data) {
                if(data)
                {
                    console.log("Data" + data);
                    msgId = data;
                    var date = new Date();
                    var n = date.toDateString();
                    //var time = date.toLocaleTimeString();
                    //var time = timestampConversion(date.getTime());
                    var time = timestampConversion();
                    //alert(date+' '+n + ' ' + time+' '+date.getTime());
                    //alert(time+' '+Date.now()+' '+date);
                    //console.log(data);
                    //alert($("#msgcount"+patientSignonID).val());
					
                    if(reloadframe == true)
					{
						location.reload(); 
					}
										
                    if(isdirectmessage == true)
                    {
                        $("#patient_msg_reply"+patientSignonID).val('');
                        if($("#msgcount"+patientSignonID).val() == 0)
                            $("#tblMsgReply"+patientSignonID).html('');
                        //$("#tblMsgReply"+patientSignonID).append('<tr class="gradeC"><td><div class="floatrght msgwidth50">'+reply+'<br/><small><i>'+$('#loggedinuser').html()+'</i></small>'+'<br/><small><i>'+n + ' ' + time+'</i></small></div></td></tr>');
                        $("#tblMsgReply"+patientSignonID).append('<tr class="gradeC"><td><div class="floatrght msgwidth50">'+reply+'<br/><small><i>'+$('#loggedinuser').val()+'</i></small>'+'<br/><small><i>'+time+'</i></small></div></td></tr>');
                        //$("#tblMsgReply"+patientSignonID).animate({ scrollTop: $(document).height() }, "slow");
                        $(".msgdiv").animate({ scrollTop: $("#tblMsgReply"+patientSignonID).height() }, "slow");
                        $("#send"+patientSignonID).prop("disabled",false);
                    }
                    else
                    {
                        $("#patient_msg_reply"+patientId).val('');
                        
                        //Comment By Meet on 12July2014
                        /*if($("#msgcount"+patientId).val() == 0)
                            $("#tblMsgReply"+patientId).html('');*/
                            
                        //$("#tblMsgReply"+patientSignonID).append('<tr class="gradeC"><td><div class="floatrght msgwidth50">'+reply+'<br/><small><i>'+$('#loggedinuser').html()+'</i></small>'+'<br/><small><i>'+n + ' ' + time+'</i></small></div></td></tr>');
                        //$("#tblMsgReply"+patientId).append('<tr class="gradeC"><td><div class="floatrght msgwidth50">'+reply+'<br/><small><i>'+$('#loggedinuser').html()+'</i></small>'+'<br/><small><i>'+time+'</i></small></div></td></tr>');
                        $("#tblMsgReply"+patientSignonID).append('<tr class="gradeC"><td><div class="floatrght msgwidth50">'+reply+'<br/><small><i>'+$('#loggedinuser').val()+'</i></small>'+'<br/><small><i>'+time+'</i></small></div></td></tr>');
                        //$("#tblMsgReply"+patientSignonID).animate({ scrollTop: $(document).height() }, "slow");
                        //alert($("#tblMsgReply"+patientSignonID).height()+' '+$('.msgdiv').height());
                        $(".msgdiv").animate({ scrollTop: $("#tblMsgReply"+patientSignonID).height() }, "slow");
                        $("#send"+patientId).prop("disabled",false);
                    }
                    /*$("#patient_msg_reply"+patientSignonID).val('');
                    if($("#msgcount"+patientSignonID).val() == 0)
                        $("#tblMsgReply"+patientSignonID).html('');
                    //$("#tblMsgReply"+patientSignonID).append('<tr class="gradeC"><td><div class="floatrght msgwidth50">'+reply+'<br/><small><i>'+$('#loggedinuser').html()+'</i></small>'+'<br/><small><i>'+n + ' ' + time+'</i></small></div></td></tr>');
                    $("#tblMsgReply"+patientSignonID).append('<tr class="gradeC"><td><div class="floatrght msgwidth50">'+reply+'<br/><small><i>'+$('#loggedinuser').html()+'</i></small>'+'<br/><small><i>'+time+'</i></small></div></td></tr>');*/
                    /*setTimeout(function(){
                        //alert("20 seconds");
                        var sendreplynotification = $.ajax({
                                                    url: baseurl+"admin/home/sendMsgReply/",
                                                    type: "POST",
                                                    data: {msg_id : data, patient_msg_patient_id : patientId, patient_msg_signon_id : patientSignonID, patient_msg_reply : reply, isajax : 1, sendnotification : 1},
                                                    dataType: 'json'
                                            });
                        sendreplynotification.done(function(data) {
                            if(data)
                            {
                                //console.log(data);
                                return true;
                            }
                        });

                        sendreplynotification.fail(function(jqXHR, textStatus) {
                            console.log("Request failed: " + textStatus);
                            alert("There was an error sending the message. Please try again later!");
                            return false;
                        });
                    },20000);*/
                    //return false;
                    //$(this).removeAttr('disabled');
                }
        });

        sendreply.fail(function(jqXHR, textStatus) {
            console.log("Request failed: " + textStatus);
            alert("There was an error sending the message. Please try again later!");
            //$(this).removeAttr('disabled');
            if(isdirectmessage == true)
            {
                $("#send"+patientSignonID).prop("disabled",false);
            }
            else
            {
                $("#send"+patientId).prop("disabled",false);
            }
            return false;
        });
       	//return true;
        
        //RT Chat starts here.
        if(patientSignonID != ""){
            console.log("msgId : " + msgId);
            socket.emit("private", { msg: reply, to: "user_"+patientSignonID, msgId: msgId }, function (res) {
            			console.log('Private for in app..');
            			timeout = setTimeout('timeout_trigger('+patientSignonID+',"'+clientNickname+'")', 10000);
                        //alert("node - "+res);
                        /*if(res == 0)
                         {
                         var sendreplynotification = $.ajax({
                         url: baseurl+"admin/home/sendMsgReply/",
                         type: "POST",
                         data: {patient_msg_patient_id : patientId, patient_msg_signon_id : patientSignonID, patient_msg_reply : reply, isajax : 1, sendnotification : 1},
                         contentType:"application/json; charset=utf-8",
                         dataType: 'json'
                         });
                         sendreplynotification.done(function(data) {
                         if(data)
                         {
                         //console.log(data);
                         return true;
                         }
                         });
                         
                         sendreplynotification.fail(function(jqXHR, textStatus) {
                         console.log("Request failed: " + textStatus);
                         alert("There was an error sending the message. Please try again later!");
                         return false;
                         });
                         }*/
                        });
        }
        //RT Chat ends here.
    }
}

function timeout_trigger(patientSignonID,clientNickname)
{
	console.log(patientSignonID);
	
	if(clientNickname=='' || clientNickname==null || typeof clientNickname=='undefined')
		clientNickname="NextDocVisit.com";
		
	var inappnotifyReply = $.ajax({
                                    url: baseurl+"admin/home/inappnotifyReply/",
                                    type: "POST",
                                    async:false,
                                    data: {patient_msg_signon_id:patientSignonID},
                                    dataType: 'json'
                            });
                            
     inappnotifyReply.done(function(data) {     	
     	
     	if(data.length > 0)
     	{
			if (typeof data[0].patient_msg_signon_platform !== 'undefined' || data[0].patient_msg_signon_platform !== '' || data[0].patient_msg_signon_platform!==null)
     		{
				socket.emit("send_"+data[0].patient_msg_signon_platform+"_notify", { notifyMsg: data[0].patient_msg_msg, notifyTitle: "Message from "+clientNickname+" for "+data[0].patient_first_name+" "+data[0].patient_last_name, notifyUID: data[0].patient_msg_signon_uid}, function (res) {
		});	
			}	
		}     	     
     });
     inappnotifyReply.fail(function(jqXHR, textStatus) {
            console.log("Request failed: " + textStatus);                                  
            return false;
        });
}

function statusValidation(patientID)
{
    var dispositionStatus   = $("#patient_score_disposition"+patientID).val();
    //alert(dispositionStatus);
    if(dispositionStatus == '' || typeof dispositionStatus == 'undefined')
    {
        return collapseRecord(patientID);
    }
    else
    {
        $("#frmDispositionStatus"+patientID).validate();
        var dispositionComments = $("#patient_score_disposition_comments"+patientID).val();
        if(dispositionStatus && typeof dispositionStatus != 'undefined' && dispositionStatus != "appointment" && dispositionStatus != "working" && dispositionStatus != "called" && (dispositionComments == '' || dispositionComments== null))
        {
            alert("Please enter comments for disposition.");
            $("#patient_score_disposition_comments"+patientID).focus();
            return false;
        }
        else
            return true;
    }
}

    setInterval(function(){
        //alert($('#viewing59').html());
        //$('#viewing59').html('change');
        var strPatietnId = $('#patientIds').val();
        if(typeof strPatietnId !== 'undefined' && strPatietnId !== null && strPatietnId !== '')
        {
            //console.log(strPatietnId);
            strPatietnId = strPatietnId.substring(0, strPatietnId.length - 1)
            var arrPatientid = strPatietnId.split(',');
            //console.log(arrPatientid);
            //console.log(JSON.stringify(arrPatientid));
            var timeLastLoaded = $('#timeLastLoaded').val();
            var isrequestab = $('#request_tab').val();
            //var idToIgnore = $('.in.patientDetails').attr('id');
            var idToIgnorePatient = $('#open_patient_id').val();
            var idToIgnoreMsg = $('#open_msg_id').val();
			//alert(idToIgnorePatient);
            /*if(isrequestab)
                idToIgnore = $(this).parents('.accordion-group').children('.accordion-body').attr('id');
            else
                idToIgnore = $(this).parents('.accordion-group').children('.accordion-body').attr('id');
            console.log($('.in.patientDetails').attr('id'));  /*/              
            //console.log(timeLastLoaded);
            var reloadRequest = $.ajax({
                                        url: baseurl+"admin/patient/getLatestPatientsAndViewers/1/",
                                        type: "POST",
                                        data: {timeLastLoaded : timeLastLoaded, patientIds : JSON.stringify(arrPatientid), isrequestab:isrequestab, idToIgnorePatient:idToIgnorePatient, idToIgnoreMsg:idToIgnoreMsg},
                                        dataType: 'json'
                                });

            reloadRequest.done(function(data) {
                    if(data)
                    {
                        //alert(data);
                        $.each(data, function (k, v) {
                            //console.log(k);
                            //console.log(v.patient_id);
                            //console.log(v.user_firstname);
                            //console.log(v.user_lastname);
                            if(v.user_firstname != null && v.user_lastname != null)
                                $('#viewing'+v.patient_id).html(v.user_firstname+' '+v.user_lastname);
                            else
                                $('#viewing'+v.patient_id).html('NONE');
                        });
                        //$.each(data['newRecordsCount'], function (k, v) {
                            //console.log(k);
                            //console.log(v);
                            //console.log(v.patient_id);
                            //console.log(v.user_firstname);
                            //console.log(v.user_lastname);
                            //console.log(data['newRecordsCount']);
							if (typeof data['newRecordsCount'] !== 'undefined' && data['newRecordsCount'] !== null && data['newRecordsCount'] !== '')
							{
								if(typeof data['newRecordsCount'][0] !== 'undefined' && data['newRecordsCount'][0] !== null && data['newRecordsCount'][0] !== '' && data['newRecordsCount'][0] != 0)
								{
									$.pnotify({title: 'ASAP Request', text: 'There is/are '+data['newRecordsCount'][0]+' patient(s) with ASAP request.', sticker: false, type: 'error',icon: false});
								}
								if(typeof data['newRecordsCount'][1] !== 'undefined' && data['newRecordsCount'][1] !== null && data['newRecordsCount'][1] !== '' && data['newRecordsCount'][1] != 0)
								{
									$.pnotify({title: 'AM Request', text: 'There is/are '+data['newRecordsCount'][1]+' patient(s) with AM request.', sticker: false, type: 'success',icon: false});
								}
								if(typeof data['newRecordsCount'][2] !== 'undefined' && data['newRecordsCount'][2] !== null && data['newRecordsCount'][2] !== '' && data['newRecordsCount'][2] != 0)
								{
									$.pnotify({title: 'PM Request', text: 'There is/are '+data['newRecordsCount'][2]+' patient(s) with PM request.', sticker: false, type: 'warning',icon: false});
								}
								if(typeof data['newRecordsCount'][3] !== 'undefined' && data['newRecordsCount'][3] !== null && data['newRecordsCount'][3] !== '' && data['newRecordsCount'][3] != 0)
								{
									$.pnotify({title: 'Direct Messages', text: 'There is/are '+data['newRecordsCount'][3]+' direct message(s).', sticker: false, type: 'container',icon: false});									
									$("#directMsgColor").addClass('adminUnreadMsg');
								}
								if(typeof data['newRecordsCount'][4] !== 'undefined' && data['newRecordsCount'][4] !== null && data['newRecordsCount'][4] !== '' && data['newRecordsCount'][4] != 0)
								{
									$.pnotify({title: 'Messages', text: 'There is/are message(s) from '+data['newRecordsCount'][4]+' with appointment request.', sticker: false, type: 'notice',icon: false});
									if(data['newRecordsCount'][5] > 0 && data['newRecordsCount'][5] != 0)
									$("#archivedPatientMsgColor").addClass('adminUnreadMsg');
									else
									$("#activePatientMsgColor").addClass('adminUnreadMsg');
								}
								$('.ui-pnotify-history-container').hide();
							}
                        //});
                        $('#timeLastLoaded').val(data.lastUpdated);
						
            			$.ajax({
								url: baseurl+"admin/home/getPatientsStack/add",
								type: "POST",
								data: {patientIds : JSON.stringify(data['StackIds'])},
               					success:function(data){
		                            $("#patientsstackDiv").html(data);
								},
								error:function(){
									//alert("There was an error. Please try again later.");
								}
						});
						
						
            			$.ajax({
								url: baseurl+"admin/home/getMessageStack/add",
								type: "POST",
								data: {patientIds : JSON.stringify(data['msgStackIds'])},
               					success:function(data){
		                            $("#msgstackDiv").html(data);
		                            /*var url=document.URL;
		                            var urlvalue = url.substring(url.lastIndexOf('/'));
		                            if(urlvalue=="/directmsgs.html")
		                            {
										if($('div#msgstackDiv > div').length > 1)
										{
											$('div#msgstackDiv > div').each(function (i) {
												if(i!=0)
												{
													$id=$(this).children().attr('id');
													if($('div#patientListing').find('div#'+$id).attr('id')!=null && $('div#patientListing').find('div#'+$id).attr('id')!='' && typeof $('div#patientListing').find('div#'+$id).attr('id')!='undefined')
													{
														if(!$('div#patientListing').find('div#'+$id).hasClass('adminUnreadMsg'))
															$('div#patientListing').find('div#'+$id).addClass('adminUnreadMsg');
													}
														
												}
											 });
										}
									}*/		                            
								},
								error:function(){
									//alert("There was an error. Please try again later.");
								}
						});
						
                    }
            });

            reloadRequest.fail(function(jqXHR, textStatus) {
                console.log("Request failed: " + textStatus);
            });
        }
    //}, 1000);
    }, 15000);
	//setInterval(function(){
    //    location = ''
    //},600000)

$(document).ready(function() {
	$(".fancyopenclick").fancybox({
		maxWidth	: 1200,
		maxHeight	: 800,
		fitToView	: false,
		width		: '90%',
		height		: '90%',
		autoSize	: false,
		closeClick	: false,
		openEffect	: 'none',
		closeEffect	: 'none'
	});

    $('.dispositionStatus').on('change', function(){
        var curId = $(this).attr('id');
        //alert(curId);
        curId = curId.replace('patient_score_disposition','')
        //alert(curId);
        if($(this).val() == 'appointment')
        {
            $('#appointmentDisposition'+curId).show();
            $('#patientCalled'+curId).hide();
        }
        else if($(this).val() == 'called')
        {
            $('#appointmentDisposition'+curId).hide();
            $('#patientCalled'+curId).show();
        }
        else
        {
            $('#appointmentDisposition'+curId).hide();
            $('#patientCalled'+curId).hide();
        }
    });

    //Open modal box onclick of the previous history links
    var $modal = $('#previousCommentsModal');
    $('.viewCommentsHistory').on('click', function (e) {
        e.preventDefault();
        var url = $(this).attr('href');
        var title = "";
        //alert(url.indexOf("showCommentHistory")+' '+url.indexOf("showCallnotesHistory"));
        if(url.indexOf("showCommentHistory") != -1)
            title = "Comments History";
        else if(url.indexOf("showCallnotesHistory") != -1)
            title = "Call History";
        else
            title = "History";
        //$modal.html('<div class="modal-header"><button type="button" class="close" data-dismiss="modal">&times;</button><h3>Previous comments</h3></div><iframe width="100%" height="100%" frameborder="0" scrolling="no" allowtransparency="true" src="' + url + '"></iframe><div class="modal-footer"><a href="#" class="btn" data-dismiss="modal">Close</a></div>');
        $modal.html('<div class="modal-header comments"><button type="button" class="close" data-dismiss="modal">&times;</button><h3>'+title+'</h3></div><iframe width="100%" height="100%" frameborder="0" allowtransparency="true" src="' + url + '"></iframe>');
        //$modal.html('<iframe width="100%" height="100%" frameborder="0" scrolling="no" allowtransparency="true" src="' + url + '"></iframe>');
        $modal.modal({
            show: true
        });
    });

    $modal.on('hide', function () {
        $modal.empty() // Clean up
    });
});





